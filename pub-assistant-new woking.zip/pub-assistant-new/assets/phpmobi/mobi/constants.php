<?php
define("NO_COMPRESSION", 1);
define("PALMDOC_COMPRESSION", 2);
define("HUFF", 17480);
define("RECORD_SIZE", 4096);

define("NO_ENCRYPTION", 0);

define("MOBIPOCKET_BOOK", 2);
define("CP1252", 1252);
define("UTF8", 65001);