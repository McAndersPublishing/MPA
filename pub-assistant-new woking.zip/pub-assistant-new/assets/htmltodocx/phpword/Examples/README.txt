To use an example, simply browse to it - e.g. mysite.local/phpword/Examples/BasicTable.php.

The example download files will appear in the tmp directory.