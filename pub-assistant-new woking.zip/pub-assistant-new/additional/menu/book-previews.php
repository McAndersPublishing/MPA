<?php
ini_set('display_errors',1);
if( !function_exists( 'website_theme_register_book_previews_menu' ) ) {
	add_action( 'admin_menu', 'website_theme_register_book_previews_menu');
	/**
	 * Registers the menu page.
	 */
	function website_theme_register_book_previews_menu() {
		add_submenu_page(null, 'Book Previews', 'Book Previews', 'manage_options', 'book-previews', 'display_added_book_preview_setting' );
	}
}
if( !function_exists( 'display_added_book_preview_setting' ) ) {

	function display_added_book_preview_setting()
	{

		global $wpdb;
		$book_preview_set_message ='';
		if(isset($_POST['Preview']) && !empty($_POST['Preview']))
		{
			$website_id = $_REQUEST[website_id];
			if(get_post_meta($website_id, 'preview_percentage', true))
				update_post_meta($website_id, 'preview_percentage' , $_POST['preview_percentage']);
			else
				add_post_meta($website_id, 'preview_percentage', $_POST['preview_percentage']);
				
			$book_preview_set_message="Book preview setting has been updated successfully.";		
			
		}

		/// Display Page Heading
		$selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
		displayHeading($selectedwebsite, 'Book preview setting'); 
		
		if ($selectedwebsite) 
		{
			$str     = '';

			$preview_percentage = get_post_meta($selectedwebsite, 'preview_percentage', true); // fetching Author related language information
			
			$str .='<form action="" method="post" id="frmLogPreview" name="frmLogPreview" onsubmit="return checkBookPreviewFormValidity()">
			<input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">';
			$str .='<table cellspacing="0" cellpadding="2" border="0" width="100%"><tbody>';

			if(!empty($book_preview_set_message))
			{
				$str .='<tr align="left"><td height="1" style="padding: 8px;color:green" class="successmsg_12" colspan="4" align="center">'.$book_preview_set_message.'</td></tr>';
			}
				
			$str .='<tr>';
			$str .='<td class="smallclassnew" valign="top" align="left" width="16%"><b>Book Preview Setting:</b></td>';
			$str .='<td class="smallclassnew" valign="top" align="left" width="7%" style="font-size:11px"><input type="text" name="preview_percentage" id="preview_percentage" value="'.$preview_percentage.'" style="width:40px;">%</td>';
			$str .='<td class="smallclassnew" valign="top" align="left" width="77%" style="font-size:11px;">';
			$str .='<input type="submit" name="Preview" value="Save" class="button button-primary save">';
			$str .='</td>';
			$str .='</tr>';

			$str .='<tr align="center">';
			$str .='<td height="1" style="padding: 8px;" colspan="3"></td>';
			$str .='</tr>';
			$str .='</tbody>';
			$str .='</table>';
			$str .='</form>';
			$str .='<script>
			function checkBookPreviewFormValidity(){
				if(document.getElementById(\'preview_percentage\').value==\'\')
				{ 
					alert(\'Percentage value can`t be null.\');
					return false; 
				}
				return true;
			}
			</script>';
			echo $str; 
		}
	} 
}
?>