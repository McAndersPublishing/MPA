<?php
ini_set('display_errors',1);
if( !function_exists( 'website_theme_register_latest_releases_menu' ) ) {
	add_action( 'admin_menu', 'website_theme_register_latest_releases_menu');
	/**
	 * Registers the menu page.
	 */
	function website_theme_register_latest_releases_menu() {
		add_submenu_page(null, 'Latest Releases', 'Latest Releases', 'manage_options', 'latest-releases', 'display_added_latest_releases_list' );
	}
}
if( !function_exists( 'display_added_latest_releases_list' ) ) {

	global $wpdb;
	$author_latest_release_table = $wpdb->prefix . "author_latest_release";
	
	function display_added_latest_releases_list(){
		global $wpdb;
		if(isset($_POST['Save']) && !empty($_POST['Save']))
		{
			extract($_POST);
			$_auth_latest_release = get_post_meta($website_id, '_auth_latest_release', true); // fetching Author related language information
			
			$dataToUpate = array();
			if(!empty($_auth_latest_release)){			
				foreach ($_auth_latest_release as $key => $latest_release){
					$dataToUpate[$key] = $latest_release;
					$dataToUpate[$key]['headline'] = $headline[$key];
					$dataToUpate[$key]['no_of_titles'] = $no_of_titles[$key];
					$dataToUpate[$key]['display'] = ($record_array[$key]) ? 1 : 0;
				}
			}
			
			update_post_meta($website_id, '_auth_latest_release', $dataToUpate); // fetching Author related language information
			$latest_release_set_message="Latest releases setting has been updated successfully.";		
		}
		/// Display Page Heading
		$selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
		$selectedAuthor = displayHeading($selectedwebsite, 'Latest Release Setting'); 
		
		if ($selectedwebsite) 
		{
			$message = '';
			$str     = '';
			$settings = get_option( 'pub-assistant' );
			$languages = $settings[ 'languages' ];			
			
			// fetching Author related language information
			$website_languages = get_post_meta($selectedwebsite, 'website_languages', true); 
			save_latest_releases_setting($website_languages,$selectedwebsite,'ebook');

			// fetching Author related language information
			$website_aud_languages = get_post_meta($selectedwebsite, 'website_aud_languages', true); 
			save_latest_releases_setting($website_aud_languages,$selectedwebsite,'audiobook');
			
			// fetching Author related language information
			$LatestReleasesSeetingRecordSets = get_post_meta($selectedwebsite, '_auth_latest_release', true); 
			
			if(is_array($LatestReleasesSeetingRecordSets) && count($LatestReleasesSeetingRecordSets)>0)
			{
					$str .='<form action="" method="post" id="frmLogVendor" name="frmLogVendor"><input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">';
					$str .='<table cellspacing="0" cellpadding="5" border="0" width="100%"><tbody>';
					if(!empty($latest_release_set_message))
					{
						$str .='<tr align="left"><td height="1" style="padding: 8px;color:green" class="successmsg_12" colspan="4" align="center">'.$latest_release_set_message.'</td></tr>';
					}
					$str .='<tr style="background:#D9D9D9;height:30px;"><td width="20%" style="font-size:11px;" valign="top"><b>Display Latest Releases</b></td><td width="30%" style="font-size:11px;"><b>Headline</b></td><td width="60%" style="font-size:11px;"><b># of Titles Displayed</b></td></tr>';
							
				   $latest_releases_record_array = array();
				   foreach($LatestReleasesSeetingRecordSets as $key => $value)
				   {	
						$latest_releases_record_array[] = $value[lang_key];
				 
						if($value['display']) {
							$checked = 'checked';
						}
						else{
							$checked = '';
						}
						if($value['book_type']=='ebook') {
							$bookType = 'Ebook';
						}
						else {
							$bookType = 'Audiobook';
						}
						$str .='<tr>';
						$str .='<td class="smallclassnew" valign="top" width="10%">
									<input type="checkbox" '.$checked.' name="record_array['.$value[lang_key].'_'.$value['book_type'].']" value="'.$value[lang_key].'" >
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$bookType.'('.$languages[$value[lang_key]].')</td>';
									
						$str .='<td class="smallclassnew" valign="top" width="30%" style="font-size:11px">
									<input type="text" name="headline['.$value[lang_key].'_'.$value['book_type'].']" id="headline_'.$value[lang_key].'_'.$value['book_type'].'" value="'.$value['headline'].'">
								</td>
								<td class="smallclassnew" valign="top" width="70%" style="font-size:11px">
									<input type="text" name="no_of_titles['.$value[lang_key].'_'.$value['book_type'].']" id="no_of_titles_'.$value[lang_key].'_'.$value['book_type'].'" value="'.$value['no_of_titles'].'" style="width:25px;text-align:center;">
								</td></tr>';
					} 
					$latest_releases_record_string = implode(',',$latest_releases_record_array);
					$str .='<tr class="smallclassnew"><td align="left" class="smallclassnew" colspan="4" style="border-top:1px solid #cfcfcf;">
								<input type="submit" name="Save" value="Save" style="margin-bottom:-3px;padding-bottom:0px;" class="button button-primary save">
								<input type="hidden" name="latest_releases_record_array" value="'.$latest_releases_record_string.'">
							</td>	</tr>';

					$str .='<tr align="center"><td height="1" style="padding: 8px;" colspan="4"></td></tr></tbody></table>
					<input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">
					</form>';
			}
		echo $str; 
		}
	} 
}

function save_latest_releases_setting($recordSets,$website_id,$book_type)
{
	// fetching Author related language information
	$_auth_latest_release = get_post_meta($website_id, '_auth_latest_release', true); 
	
	if(!empty($recordSets))
	{	
		$num = 0;
		$dataToSave = array();
		foreach($recordSets as $key => $value){
			$ebookKey = $key.'_'.$book_type;
			if(!$_auth_latest_release[$ebookKey])
			{
				$_auth_latest_release[$ebookKey] = array(
							'lang_key'=>$key,
							'headline'=> 'New Books',
							'book_type' => $book_type,
							'no_of_titles'=> 4,
							'display'=> 1,
				);
			}
		}
		if(get_post_meta($website_id, '_auth_latest_release', true))
			update_post_meta($website_id, '_auth_latest_release' , $_auth_latest_release);
		else
			add_post_meta($website_id, '_auth_latest_release', $_auth_latest_release);
	}
	return $set_message;
}

?>