<?php
ini_set('display_errors',1);
if( !function_exists( 'website_theme_register_special_offers_menu' ) ) {
	add_action( 'admin_menu', 'website_theme_register_special_offers_menu');
	/**
	 * Registers the menu page.
	 */
	function website_theme_register_special_offers_menu() {
		add_submenu_page(null, 'Special Offers', 'Special Offers', 'manage_options', 'special-offers', 'display_added_special_offers_list' );
	}
}
if( !function_exists( 'display_added_special_offers_list' ) ) {
	function display_added_special_offers_list(){
		global $wpdb;
		
		if(isset($_POST['Offer']) && !empty($_POST['Offer']))
		{
			extract($_POST);
			$_auth_special_offer = get_post_meta($website_id, '_auth_special_offer', true); // fetching Author related language information
			
			$dataToUpate = array();
			if(!empty($_auth_special_offer)){			
				foreach ($_auth_special_offer as $key => $latest_release){
					$dataToUpate[$key] = $latest_release;
					$dataToUpate[$key]['special_offers'] = $special_offers[$key];
					$dataToUpate[$key]['display'] = ($record_array[$key]) ? 1 : 0;
				}
			}
			
			update_post_meta($website_id, '_auth_special_offer', $dataToUpate); // fetching Author related language information
			$special_offers_set_message = "Special Offers has been updated successfully.";		
			//$special_offers_set_message = update_special_offers_setting($author_special_offers_table);
		}
		/// Display Page Heading
		$selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
		$selectedAuthor = displayHeading($selectedwebsite, 'Special Offers Setting'); 
		
		if ($selectedwebsite) 
		{
			$author_language_table = $wpdb->prefix . "language";
			$author_special_offers_table = $wpdb->prefix . "author_special_offers";
			$author_audiobook_setting_table = $wpdb->prefix . "author_audiobook_seeting";
			$settings = get_option( 'pub-assistant' );
			$message = '';
			$str     = '';

			$website_languages = get_post_meta($selectedwebsite, 'website_languages', true); // fetching Author related language information
			save_special_offers_setting($website_languages,$selectedwebsite,'ebook');

			$website_aud_languages = get_post_meta($selectedwebsite, 'website_aud_languages', true); // fetching Author related language information
			save_special_offers_setting($website_aud_languages,$selectedwebsite,'audiobook');
			
			$SpecialOffersSeetingRecordSets = get_post_meta($selectedwebsite, '_auth_special_offer', true);			
			
			$all_languages  = $settings['languages'];
			
			if(is_array($SpecialOffersSeetingRecordSets) && count($SpecialOffersSeetingRecordSets)>0)
			{
					$str .='<form action="" method="post" id="frmLogOffer" name="frmLogOffer">
					<input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">';
					$str .='<table cellspacing="0" cellpadding="5" border="0" width="100%"><tbody>';
					if(!empty($special_offers_set_message))
					{
						$str .='<tr align="left"><td height="1" style="padding: 8px;color:green" class="successmsg_12" colspan="4" align="center">'.$special_offers_set_message.'</td></tr>';
					}
					$str .='<tr style="background:#D9D9D9;height:30px;">';
								$str .='<td width="20%" style="font-size:11px;" valign="top"><b>On/Off</b></td>';
								$str .='<td width="30%" style="font-size:11px;"><b>Special Offers</b></td>';
								$str .='<td width="50%" style="font-size:11px;"></td>';
					$str .='</tr>';
							
				   $special_offers_record_array = array();
				   //$str .= wp_editor( $content, "special_offers" );
				   foreach($SpecialOffersSeetingRecordSets as $key => $value)
				   {	
					   $special_offers_record_array[] = $value['id'];
					 
						if($value['display']) {
							$checked = 'checked';
						}
						else{
							$checked = '';
						}
						if($value['book_type']=='ebook') {
							$bookType = 'Ebook';
						}
						else {
							$bookType = 'Audiobook';
						}
						$str .='<tr>';
						$str .='<td class="smallclassnew" valign="center" width="10%">';
						$str .='<input type="checkbox" '.$checked.' name="record_array['.$value[lang_key].'_'.$value['book_type'].']" value="'.$value[lang_key].'" > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$bookType.'('.$all_languages[$value[lang_key]].')</td>';
						$str .='<td class="smallclassnew" valign="top" width="50%" style="font-size:11px">';
						$editor_name = 'special_offers['.$value[lang_key].'_'.$value['book_type'].']';
						$settings = array( 'media_buttons' => false,'textarea_rows'=>5);
						ob_start();
						wp_editor( $value['special_offers'], $editor_name,$settings  );
						$editor_contents = ob_get_clean();
						//$str .='<textarea  name="special_offers_'.$value['id'].'" id="special_offers_'.$value['id'].'">'.$value['special_offers'].'</textarea></td>';
						$str .=stripcslashes($editor_contents);
						$str .='<td class="smallclassnew" valign="top" width="70%" style="font-size:11px">';
						$str .='<input type="hidden" name="lang_key_'.$value['id'].'" id="lang_key_'.$value['id'].'" value="'.$value['lang_key'].'">';
						$str .='</td>';
						$str .='<td></td>';
						$str .='</tr>';
					} 
					$special_offers_record_string = implode(',',$special_offers_record_array);
					$str .='<tr class="smallclassnew">';
					$str .='<td align="left" class="smallclassnew" colspan="4" style="border-top:1px solid #cfcfcf;">';
					$str .='<input type="submit" name="Offer" value="Save" style="margin-bottom:-3px;padding-bottom:0px;" class="button button-primary save">';
					$str .='<input type="hidden" name="special_offers_record_array" value="'.$special_offers_record_string.'">';
					$str .='</td>';	
					$str .='<td></td>';
					$str .='</tr>';
					$str .='<tr align="center">';
					$str .='<td height="1" style="padding: 8px;" colspan="3"></td>';
					$str .='</tr>';
					$str .='</tbody>';
					$str .='</table>';
					$str .='</form>';
			}
			echo $str; 
		} 
	}
}


function save_special_offers_setting($recordSets,$website_id,$book_type)
{
	$_auth_special_offer = get_post_meta($website_id, '_auth_special_offer', true); // fetching Author related language information
	
	if(!empty($recordSets))
	{	
		$num = 0;
		$dataToSave = array();
		foreach($recordSets as $key => $value){
			$ebookKey = $key.'_'.$book_type;
			if(!$_auth_special_offer[$ebookKey])
			{
				$_auth_special_offer[$ebookKey] = array(
							'lang_key'=>$key,
							'special_offers'=> 'Special Offers',
							'book_type' => $book_type,
							'display'=> 1,
				);
			}
		}
		if(get_post_meta($website_id, '_auth_special_offer', true))
			update_post_meta($website_id, '_auth_special_offer' , $_auth_special_offer);
		else
			add_post_meta($website_id, '_auth_special_offer', $_auth_special_offer);
	}
	return $set_message;
}


function save_special_offers_setting1($recordSets,$website_id,$book_type)
{
	
	global $wpdb;
	$author_special_offers_table = $wpdb->prefix . "author_special_offers";
	if(!empty($recordSets))
	{	
		$num = 0;
		foreach($recordSets as $key => $value){

			$query = "SELECT id FROM $author_special_offers_table WHERE lang_key='".$value['lang_key']."' AND website_id=$website_id AND book_type='$book_type'";
			$result = $wpdb->get_col( $query );
			if(count($result)==0){
				$data = array('lang_key'=>$value['lang_key'],
						'special_offers'=>'',
						'book_type' =>$book_type,
						'website_id'=>$website_id,
						'display'=>1
				);
				$format = array('%s','%s','%s','%d','%d');
				$wpdb->insert( $author_special_offers_table, $data, $format );
				$num++;
				$set_message="Special Offers setting has been updated successfully.";	
			}
		}
	}
	return $set_message;
}

function update_special_offers_setting($author_special_offers_table)
{
	global $wpdb;
	$special_offers_record_array = explode(',',$_POST['special_offers_record_array']);
	if(!empty($special_offers_record_array))
	{	
		foreach($special_offers_record_array as $key => $value){
			$lang_key       = $_POST['lang_key_'.$value];
			$special_offers = $_POST['special_offers_'.$value];
			$website_id      = $_REQUEST['website_id'];
			if(in_array($value,$_POST['record_array'])){
				$display = 1;
			}
			else{
				$display = 0;
			}
			$data = array('lang_key' => $lang_key,
				'special_offers' => $special_offers,
				'website_id' => $website_id,
				'display' => $display
			);
			$format = array('%s','%s','%d','%d','%d');
			$where  = array('id'=>$value,'website_id'=>$website_id);
			$where_format = array('%d','%d');
			$wpdb->update( $author_special_offers_table, $data, $where, $format , $where_format );
			$set_message="Special Offers setting has been updated successfully.";		
		}
	}
	return $set_message;
}
?>