<?php
ini_set('display_errors',1);
if( !function_exists( 'website_theme_register_google_analytics_menu' ) ) {
	add_action( 'admin_menu', 'website_theme_register_google_analytics_menu');
	/**
	 * Registers the menu page.
	 */
	function website_theme_register_google_analytics_menu() {
		add_submenu_page(null, 'Google Analytics', 'Google Analytics', 'manage_options', 'google-analytics', 'display_added_google_analytics_list' );
	}
}
if( !function_exists( 'display_added_google_analytics_list' ) ) {

	function display_added_google_analytics_list()
	{
		global $wpdb;
		
		if(isset($_POST['googleAnalytics']) && !empty($_POST['googleAnalytics']))
		{
			$website_id = $_REQUEST[website_id];
			
			$datatoSave = array(
										'display' => $_POST['display'],
										'google_analytics_code' => $_POST['google_analytics_code']
									);
			$a = get_post_meta($website_id, '_auth_google_analytics', true);
			
			if(get_post_meta($website_id, '_auth_google_analytics', true))
				update_post_meta($website_id, '_auth_google_analytics' , $datatoSave);
			else
				add_post_meta($website_id, '_auth_google_analytics', $datatoSave);
				
			$google_analytics_set_message ="Google analytics code setting has been updated successfully.";

		}
		/// Display Page Heading
		$selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
		displayHeading($selectedwebsite, 'Google Analytics setting'); 
		
		if ($selectedwebsite) 
		{
			$message = '';
			$str     = '';
			
			$googleAnalyticsSettingRecordSet = get_post_meta($selectedwebsite, '_auth_google_analytics', true);
			
			$str .='<form action="" method="post" id="frmLogGoogle" name="frmLogGoogle">
			<input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">';
			$str .='<table cellspacing="0" cellpadding="5" border="0" width="100%"><tbody>';
			if(!empty($google_analytics_set_message))
			{
				$str .='<tr align="left"><td height="1" style="padding: 8px;color:green" class="successmsg_12" colspan="4" align="center">'.$google_analytics_set_message.'</td></tr>';
			}
			$str .='<tr style="background:#D9D9D9;height:30px;">
					<td width="20%" style="font-size:11px;" valign="top"><b>On/Off</b></td>
					<td width="80%" style="font-size:11px;"><b>Google Analytics Code</b></td>
			</tr>';
			$checked = 'checked';
			
			if($googleAnalyticsSettingRecordSet['display'])
				$checked = 'checked';
			else
				$checked = '';

			$str .='<tr>
				<td class="smallclassnew" valign="center">
					<input type="checkbox" '.$checked.' name="display" value="1" >
				</td>
				<td class="smallclassnew" valign="top" style="font-size:11px">
					<textarea name="google_analytics_code" id="google_analytics_code" rows="6" cols="40">'.stripslashes($googleAnalyticsSettingRecordSet['google_analytics_code']).'</textarea>
				</td>
			</tr>';
			$str .='<tr class="smallclassnew"><td align="left" class="smallclassnew" colspan="4" style="border-top:1px solid #cfcfcf;"><input type="submit" name="googleAnalytics" value="Save" style="margin-bottom:-3px;padding-bottom:0px;" class="button button-primary save"></td></tr>';
			$str .='<tr align="center"><td height="1" style="padding: 8px;" colspan="4"></td></tr></tbody></table></form>';
			echo $str; 
		}
	} 
}
?>