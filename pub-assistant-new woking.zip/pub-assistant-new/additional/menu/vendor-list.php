<?php

if( !function_exists( 'website_theme_register_vendor_menu' ) ) {
	add_action( 'admin_menu', 'website_theme_register_vendor_menu');
	/**
	 * Registers the menu page.
	 */
	function website_theme_register_vendor_menu() {
		add_submenu_page(null, 'Choose an Vendor', 'Choose an Vendor', 'manage_options', 'vendor-list', 'display_added_vendor_list' );
	}
}


function save_vendor_audio($id,$lang,$slug)
{
	global $wpdb;
	$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
	
	$image_path = wp_upload_dir();
	
	if(!empty($id))
	{	
			$vendor_name = $slug;
			$display_text_button = $_POST['pba_audio']['new_link'][$slug];
			$btnstatus=1;
			
			if(!empty($_FILES['vendor_audioimage_'.$slug]["name"]))
			{
				if(!file_exists($image_path['basedir'].'/pub_upload')){
					$old = umask(0);
					mkdir($image_path['basedir'].'/pub_upload',0777);
					mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
					mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
					umask($old);
				}
				$filupTot1= array();
				$pic_f =$_FILES['vendor_audioimage_'.$slug]["name"];
				$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
				$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
				$filupTot1 = move_uploaded_file ($_FILES['vendor_audioimage_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/audio/'.$pic_f);
				$vendor_img='audio/'.$pic_f;
				$btnstatus=2;
				
			}	
			
			
			$website_id = $_REQUEST['website_id'];
			
			if(isset($_POST['vendor_audiodisplay_'.$slug]) && $_POST['vendor_audiodisplay_'.$slug]==1){
			$display=1;
			}else{
			$display=0;
			}				
			
			$data = array('vendor_name'=>$vendor_name,'display_text_button'=>$display_text_button,'image'=>$vendor_img,'lang'=>$lang,'author_id'=>$id,'display'=>$display,'order'=>$num,'btnstatus'=>$btnstatus);
			$format = array('%s','%s','%s','%s','%d','%d','%d','%d');
			
			
			$wpdb->insert($author_vendor_audiobook_setting_table, $data, $format );
			
			$set_message="Vendor setting has been updated successfully.";		
		
	}
	return $set_message;
}
function update_vendor_audio($id,$lang,$slug)
{
	
	global $wpdb;
	$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
	$image_path = wp_upload_dir();
	
		
	if(!empty($id))
	{	
		
			$vendor_name = $slug;
			
			if($_POST['vendor_audioimageup_'.$lang.'_'.$slug]!='' && empty($_FILES['vendor_audioimage_'.$lang.'_'.$slug]['name'])){
			$vendor_img=$_POST['vendor_audioimageup_'.$lang.'_'.$slug];
			}else{
			$vendor_img='';
			}
			
			
			if(!empty($_FILES['vendor_audioimage_'.$lang.'_'.$slug]["name"])){
			
			if(!file_exists($image_path['basedir'].'/pub_upload')){
			$old = umask(0);
			mkdir($image_path['basedir'].'/pub_upload',0777);
			mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
			mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
			umask($old);
			}
			
			$filupTot1= array();
			
			$pic_f =$_FILES['vendor_audioimage_'.$lang.'_'.$slug]["name"];
			$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
			$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
			$filupTot1 = move_uploaded_file ($_FILES['vendor_audioimage_'.$lang.'_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/audio/'.$pic_f);
			$vendor_img='audio/'.$pic_f;
			}	
			
			
			$display_text_button = $_POST['pba_audio']['links'][$slug][$lang];
						
			$website_id = $_REQUEST['website_id'];
			$btnbookstatus=0;
			
			if(isset($_POST['buttonselect_'.$lang.'_'.$slug])){
				if($_POST['buttonselect_'.$lang.'_'.$slug]=='btext_'.$lang.'_'.$slug){
				$btnbookstatus = 1;
				}elseif($_POST['buttonselect_'.$lang.'_'.$slug]=='bimage_'.$lang.'_'.$slug){
				$btnbookstatus = 2;
				}
			}
			
			if(isset($_POST['vendor_audiodisplay_'.$lang.'_'.$slug]) && $_POST['vendor_audiodisplay_'.$lang.'_'.$slug]==1){
			$display=1;
			}else{
			$display=0;
			}
			$data = array('vendor_name'=>$vendor_name,'image'=>$vendor_img,'display_text_button'=>$display_text_button,
				'author_id'=>$website_id,'display'=>$display,'btnstatus'=>$btnbookstatus);
						
			$format = array('%s','%s','%s','%d','%d','%d');
			$where  = array('vendor_name'=>$vendor_name,'lang'=>$lang,'author_id'=>$website_id);
			$where_format = array('%s','%s','%d');
			
			$wpdb->update( $author_vendor_audiobook_setting_table, $data, $where, $format , $where_format );
			
			$set_message="Vendor setting has been updated successfully.";		
		
	}
	return $set_message;
}
function update_vendor_setting($id,$lang,$slug)
{
	global $wpdb;
	$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
	$vendor_record_array = explode(',',$_POST['vendor_record_array']);
	$image_path = wp_upload_dir();
	
	
	if(!empty($id))
	{	
		
			$vendor_name = $slug;
			
			if($_POST['vendor_imageup_'.$lang.'_'.$slug]!='' && empty($_FILES['vendor_image_'.$lang.'_'.$slug]['name'])){
			$vendor_img=$_POST['vendor_imageup_'.$lang.'_'.$slug];
			}else{
			$vendor_img='';
			}
			
			
			if(!empty($_FILES['vendor_image_'.$lang.'_'.$slug]["name"])){
			if(!file_exists($image_path['basedir'].'/pub_upload')){
			$old = umask(0);
			mkdir($image_path['basedir'].'/pub_upload',0777);
			mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
			mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
			umask($old);
			}
			
			$filupTot1= array();
			
			$pic_f =$_FILES['vendor_image_'.$lang.'_'.$slug]["name"];
			$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
			$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
			$filupTot1 = move_uploaded_file ($_FILES['vendor_image_'.$lang.'_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/ebook/'.$pic_f);
			$vendor_img='ebook/'.$pic_f;
			}	
			
			
			$display_text_button = $_POST['pba']['links'][$slug][$lang];
			
			
			
			$website_id = $_REQUEST['website_id'];
			$btnbookstatus=0;
			
			if(isset($_POST['buttonselectbook_'.$lang.'_'.$slug])){
				if($_POST['buttonselectbook_'.$lang.'_'.$slug]=='bookbtext_'.$lang.'_'.$slug){
				$btnbookstatus = 1;
				}elseif($_POST['buttonselectbook_'.$lang.'_'.$slug]=='bookbimage_'.$lang.'_'.$slug){
				$btnbookstatus = 2;
				}
			}
			
			if(isset($_POST['vendor_display_'.$lang.'_'.$slug]) && $_POST['vendor_display_'.$lang.'_'.$slug]==1){
			$display=1;
			}else{
			$display=0;
			}
						
			$data = array('vendor_name'=>$vendor_name,'image'=>$vendor_img,'display_text_button'=>$display_text_button,
				'author_id'=>$website_id,'display'=>$display,'btnstatus'=>$btnbookstatus);
			
						
			$format = array('%s','%s','%s','%d','%d','%d');
			$where  = array('vendor_name'=>$vendor_name,'lang'=>$lang,'author_id'=>$website_id);
			$where_format = array('%s','%s','%d');
			
			$wpdb->update( $author_vendor_setting_table, $data, $where, $format , $where_format );
			
			$set_message="Vendor setting has been updated successfully.";		
		
	}
	return $set_message;
}
function save_vendor($id,$lang,$slug)
{
	global $wpdb;
	$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
	$vendor_record_array = explode(',',$_POST['vendor_record_array']);
	$image_path = wp_upload_dir();
	
	
	if(!empty($id))
	{	
		
			$vendor_name = $slug;
			$display_text_button = $_POST['pba']['new_link'][$slug];
			$btnstatus=1;
			
			if(!empty($_FILES['vendor_image_'.$slug]["name"])){
			
			if(!file_exists($image_path['basedir'].'/pub_upload')){
			$old = umask(0);
			mkdir($image_path['basedir'].'/pub_upload',0777);
			mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
			mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
			umask($old);
			}
			
			$filupTot1= array();
			
			$pic_f =$_FILES['vendor_image_'.$slug]["name"];
			$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
			$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
			$filupTot1 = move_uploaded_file ($_FILES['vendor_image_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/ebook/'.$pic_f);
			$vendor_img='ebook/'.$pic_f;
			$btnstatus=2;
			}	
			
			
			
			$website_id = $_REQUEST['website_id'];
			
			if(isset($_POST['vendor_display_'.$slug]) && $_POST['vendor_display_'.$slug]==1){
			$display=1;
			}else{
			$display=0;
			}
				
			
			$data = array('vendor_name'=>$vendor_name,'display_text_button'=>$display_text_button,'image'=>$vendor_img,'lang'=>$lang,'author_id'=>$id,'display'=>$display,'order'=>$num,'btnstatus'=>$btnstatus);
			$format = array('%s','%s','%s','%s','%d','%d','%d','%d');
			
						
			$wpdb->insert( $author_vendor_setting_table, $data, $format );
			
			$set_message="Vendor setting has been updated successfully.";		
		
	}
	return $set_message;
}

if(isset($_POST['savebook']) || isset($_POST['pba']['add_link']) || isset($_POST['pba']['remove_link'])){
if( !function_exists( 'save_author_meta' ) ) {
	add_action( 'save_post_audio', 'save_author_meta', 10, 1 );
	/**
	 * Saves post meta.
	 *
	 * @param int $website_id Post ID.
	 */
	function save_author_meta( $website_id ) {
	
		if( !array_key_exists( 'pba', $_POST ) ) {
			return;
		}
		
		$input = $_POST[ 'pba' ];
		
				
		if( !array_key_exists( 'links', $input ) ) {
			$input[ 'links' ] = array();
		}	
		
		$settings = get_option( 'pub-assistant' );
		$vendors = $settings[ 'vendors' ];
		$links = $input[ 'links' ];
		$languages = array_keys( $settings[ 'languages' ] );
		
		foreach( $vendors as $vendor ) {
			$slug = $vendor[ 'slug' ];
			
			if( !array_key_exists( $slug, $links ) ) {
				continue;
			}
			
			$sites = $links[ $slug ];
			
			foreach( $languages as $language ) {
				if( array_key_exists( $language, $sites ) ) {
					$vendor_set_message = update_vendor_setting($website_id,$language,$slug,'');
					
					
					
				}
			}
		}
		
		$new_links = $input[ 'new_link' ];
		$new_languages = $input[ 'new_language' ];
						
		foreach( $new_links as $slug => $new_link ) {
			$new_link = trim( $new_link );
			$language = $new_languages[ $slug ];
			
			
			if( ($new_link && $language) || ($_FILES['vendor_image_'.$slug]['name']!='' && $language) ) {
				$vendor_set_message = save_vendor($website_id,$language,$slug);
				
				
			}
		}
		
		if( array_key_exists( 'remove_link', $input ) ) {
			$slug = key( $input[ 'remove_link' ] );
			$language = key( $input[ 'remove_link' ][ $slug ] );
			
			
			$vendor_set_message = delete_vendor_book($website_id,$language,$slug);
			
		}
	}
}
save_author_meta($_REQUEST['website_id']);
}

if(isset($_POST['saveaudio']) || isset($_POST['pba_audio']['add_link']) || isset($_POST['pba_audio']['remove_link'])){
if( !function_exists( 'save_author_meta_audio' ) ) {
	add_action( 'save_post_audio', 'save_author_meta_audio', 10, 1 );
	/**
	 * Saves post meta.
	 *
	 * @param int $website_id Post ID.
	 */
	function save_author_meta_audio( $website_id ) {
	
	
		if( !array_key_exists( 'pba_audio', $_POST ) ) {
			return;
		}
		
		$input = $_POST[ 'pba_audio' ];
						
		if( !array_key_exists( 'links', $input ) ) {
			$input[ 'links' ] = array();
		}
		
		if( array_key_exists( 'first_name', $input ) ) {
			$first_name = $input[ 'first_name' ];
		} else {
			$first_name = '';
		}
		update_post_meta( $website_id, '_pba_first_name', $first_name );
		
		
		if( array_key_exists( 'last_name', $input ) ) {
			$last_name = $input[ 'last_name' ];
		} else {
			$last_name = '';
		}
		
		update_post_meta( $website_id, '_pba_last_name', $last_name );
		
			
		
		$settings = get_option( 'pub-assistant' );
		$vendors = $settings[ 'vendors' ];
		$links = $input[ 'links' ];
		$languages = array_keys( $settings[ 'languages' ] );
		
		foreach( $vendors as $vendor ) {
			$slug = $vendor[ 'slug' ];
					
			if( !array_key_exists( $slug, $links ) ) {
				continue;
			}
			
			
			$sites = $links[ $slug ];
			
			foreach( $languages as $language ) {
				if( array_key_exists( $language, $sites ) ) {
					
					$vendor_set_message = update_vendor_audio($website_id,$language,$slug,'');		
					
				}
			}
		}
		
		$new_links = $input[ 'new_link' ];
		
		
		
		$new_languages = $input[ 'new_language' ];
		
		
		foreach( $new_links as $slug => $new_link ) {
			$new_link = trim( $new_link );
			$language = $new_languages[ $slug ];
			
			
			if( ($new_link && $language) || ($_FILES['vendor_audioimage_'.$slug]['name']!='' && $language) ) {
			
				
				$vendor_set_message = save_vendor_audio($website_id,$language,$slug);
				
			}
		}
		
		
		if( array_key_exists( 'remove_link', $input ) ) {
			$slug = key( $input[ 'remove_link' ] );
			$language = key( $input[ 'remove_link' ][ $slug ] );
			
			//delete_post_meta( $website_id, '_pba_links_' . $slug . '_' . $language );
			$vendor_set_message = delete_vendor_audio($website_id,$language,$slug);
			
		}
	}
}
save_author_meta_audio($_REQUEST['website_id']);
}

if(isset($_REQUEST['action'] ) && $_REQUEST['action']=='deleteimgaudio'){
	$image_path = wp_upload_dir();
	$website_ids = $_REQUEST['id'];
	if($website_ids!='')
	{
		global $wpdb;
		$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
		$query = "SELECT image FROM $author_vendor_audiobook_setting_table WHERE id='".$website_ids."'";
		$result = $wpdb->get_col( $query );
		@unlink($image_path['basedir'].'/pub_upload/'.$result[0]);
		$data = array('image'=>'');
				$format = array('%s');
				$where  = array('id'=>$website_ids);
				$where_format = array('%d');			
				$wpdb->update($author_vendor_audiobook_setting_table, $data, $where, $format , $where_format );
	}
}

if(isset($_REQUEST['action'] )&& $_REQUEST['action']=='deleteimgebook')
{
	$image_path = wp_upload_dir();
	$website_ids = $_REQUEST['id'];
	if($website_ids!=''){
		global $wpdb;
		$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
		$query = "SELECT image FROM $author_vendor_setting_table WHERE id='".$website_ids."'";
		$result = $wpdb->get_col( $query );
		
		@unlink($image_path['basedir'].'/pub_upload/'.$result[0]);
		$data = array('image'=>'');
				$format = array('%s');
				$where  = array('id'=>$website_ids);
				$where_format = array('%d');			
				$wpdb->update($author_vendor_setting_table, $data, $where, $format , $where_format );
	}
}

function delete_vendor_audio($website_id,$language,$slug)
{
	if($website_id!=''){
		global $wpdb;
		$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
		
				$where  = array('author_id'=>$website_id,'lang'=>$language,'vendor_name'=>$slug);
				$author_vendor_audiobook_setting_table;
				$wpdb->delete($author_vendor_audiobook_setting_table,$where);
				
	}
}
function delete_vendor_book($website_id,$language,$slug)
{
	if($website_id!=''){
		global $wpdb;
		$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
		
				$where  = array('author_id'=>$website_id,'lang'=>$language,'vendor_name'=>$slug);
				$author_vendor_audiobook_setting_table;
				$wpdb->delete($author_vendor_setting_table,$where);
				
	}
}


if( !function_exists( 'display_added_vendor_list' ) ) {
	global $wpdb;
	if(isset($_POST['btn_update']) && $_POST['btn_update']=='1')
	{
		$languageTable = $wpdb->prefix . "language";
		//$set_message = update_language($languageTable);
		$url= 'admin.php?page=language-list&sucuss='.$set_message.'&website_id='.$_REQUEST['website_id'];
		echo '<script type="text/javascript">
				window.location = "'.$url.'"
			 </script>';
	}
	
	function display_added_vendor_list(){
		global $wpdb;
		$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
		$default_vendor_table = $wpdb->prefix . "default_vendor_setting";
		$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
		$settings = get_option( 'pub-assistant' );
		$vendors = $settings[ 'vendors' ];
		$media = $settings[ 'media' ];
		$media_defaults = $settings[ 'media-defaults' ];
		$image_path = wp_upload_dir();
		
		$message = '';
		
		
		// save audiobook setting for a particular author
		if(isset($_POST['Vendor']) && !empty($_POST['Vendor']))
		{
			$vendor_set_message = update_vendor_setting($author_vendor_setting_table);
			$url= 'admin.php?page=vendor-list&vendorsucuss='.$vendor_set_message.'&website_id='.$_REQUEST['website_id'];
			echo '<script type="text/javascript">
				window.location = "'.$url.'"
			 </script>';
		}
		if(isset($_POST['VendorAudiobook']) && !empty($_POST['VendorAudiobook']))
		{
			$vendor_audiobook_set_message = update_vendor_audiobook_setting($author_vendor_audiobook_setting_table);
			$url= 'admin.php?page=vendor-list&vendoraudiobooksucuss='.$vendor_audiobook_set_message.'&website_id='.$_REQUEST['website_id'];
			echo '<script type="text/javascript">
				window.location = "'.$url.'"
			 </script>';
		}
		/// Display Page Heading
		$selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
		$selectedAuthor = displayHeading($selectedwebsite, 'Vendors related Setting'); 
		
		if ($selectedwebsite) 
		{
			save_vendor_setting($vendors,$selectedwebsite);
			save_vendor_setting_for_audiobook($vendors,$selectedwebsite);
			
			include_once(dirname(__FILE__).'/includes/author.inc.php');
		}
	}	
}
function save_vendor_setting($vendors,$website_id)
{
	global $wpdb;
	$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
	if(!empty($vendors))
	{	
		$num = 0;
		
		foreach($vendors as $key => $value){
		
			$query = "SELECT id FROM $author_vendor_setting_table WHERE vendor_name='".$value['slug']."' AND author_id=$website_id";
			$result = $wpdb->get_col( $query );
			
			
			if(count($result)==0){
				if(in_array('e-book',$value['media'])){
					$data = array('vendor_name'=>$value['slug'],'display_text_button'=>$value['slug'],
						'author_id'=>$website_id,'display'=>1,'order'=>$num, 'lang' => 'en'
					);
					$format = array('%s','%s','%d','%d','%d', '%s');
					$wpdb->insert( $author_vendor_setting_table, $data, $format );
					$num++;
					$set_message="Vendor setting has been updated successfully.";	
				}
			}else{
				if(in_array('e-book',$value['media'])){
				
				}else{
					$where=array('id'=>$result[0]);
					$wpdb->delete($author_vendor_setting_table,$where);
				}
			}
		}
	}
	return $set_message;
}

function save_vendor_setting_for_audiobook($vendors,$website_id)
{
	global $wpdb;
	$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
	if(!empty($vendors))
	{
		$num = 0;
		foreach($vendors as $key => $value){
			
			$query = "SELECT id FROM $author_vendor_audiobook_setting_table WHERE vendor_name='".$value['slug']."' AND author_id=$website_id";
			$result = $wpdb->get_col( $query );
			if(count($result)==0){
				if(in_array('audiobook',$value['media'])){
					$data = array('vendor_name'=>$value['slug'], 'display_text_button'=>$value['slug'], 'lang' => 'en', 'author_id'=>$website_id,'display'=>1,'order'=>$num);
					$format = array('%s', '%s', '%s','%d','%d','%d');
					$wpdb->insert( $author_vendor_audiobook_setting_table, $data, $format );
					$set_message="Vendors that display for audiobooks setting has been updated successfully.";	
					$num++;
				}
			}else{
				if(in_array('audiobook',$value['media'])){
				}else{
				$where=array('id'=>$result[0]);
				$wpdb->delete($author_vendor_audiobook_setting_table,$where);
				}			
			}
		}
	}
	return $set_message;
}
function update_vendor_audiobook_setting($author_vendor_audiobook_setting_table)
{
	global $wpdb;
	$vendor_audio_record_array = explode(',',$_POST['vendor_audio_record_array']);
	
	if(!empty($vendor_audio_record_array))
	{	
		$website_id = $_REQUEST['website_id'];
		foreach($vendor_audio_record_array as $key => $value)
		{
			$display_text_button = $_POST['display_text_'.$value];
			
			if($_POST['vendor_audioimageup_'.$value] && empty($_FILES['vendor_audioimage_'.$value]['name'])){
				$vendor_img=$_POST['vendor_audioimageup_'.$value];
			}else{
				$vendor_img='';
			}
			
			if(!empty($_FILES['vendor_audioimage_'.$value]['name'])){
				$filupTot1= array();
				$pic_f = $_FILES['vendor_audioimage_'.$value]["name"];
				$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
				$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
				$filupTot1 = move_uploaded_file ($_FILES['vendor_audioimage_'.$value]['tmp_name'], dirname(__FILE__).'/audio/'.$pic_f);
				$vendor_img='audio/'.$pic_f;
			}
			
			if(isset($_POST['record_array']) && !empty($_POST['record_array'])){
				if(in_array($value,$_POST['record_array'])){
					$display = 1;
				}
				else{
					$display = 0;
				}
			}
			else {
				$display = 0;
			}
			$btnstatus=0;
			if(isset($_POST['buttonselect_'.$value]) && !empty($_POST['buttonselect_'.$value])){
				if($_POST['buttonselect_'.$value]=='btext_'.$value){
				$btnstatus=1;
				}elseif($_POST['buttonselect_'.$value]=='bimage_'.$value){
				$btnstatus=2;
				}
			}
			$data = array('display_text_button'=>$display_text_button,'image'=>$vendor_img,'display'=>$display,'btnstatus'=>$btnstatus);
			$format = array('%s','%s','%d','%d');
			$where  = array('id'=>$value,'author_id'=>$website_id);
			$where_format = array('%d','%d');
			$wpdb->update( $author_vendor_audiobook_setting_table, $data, $where, $format , $where_format );
			$set_message="Choose the vendors that display for audiobooks setting has been updated successfully.";		
		}
	}
	return $set_message;
}
?>