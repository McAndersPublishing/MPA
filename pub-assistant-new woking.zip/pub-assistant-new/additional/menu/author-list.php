<?php
ini_set('display_errors',1);
if( !function_exists( 'pba_register_author_list_menu' ) ) {
	add_action( 'admin_menu', 'pba_register_author_list_menu' );
	/**
	 * Registers the menu page.
	 */
	function pba_register_author_list_menu() {
		add_submenu_page( null, 'Choose an Author', 
			'Choose an Author', 'manage_options', 'author-list', 
			'display_added_author_list', PBA_PLUGIN_URL . 'images/logo-9-16.jpg', 3.01 );
	}
}
if( !function_exists( 'display_added_author_list' ) ) {
	global $wpdb;
	function display_added_author_list()
	{
	    global $wpdb;
		$author_theme_table = $wpdb->prefix . "author_theme";
		if( array_key_exists( 'action', $_POST ) ) {
			$action = $_POST[ 'action' ];
			
			$wpdb->update( $author_theme_table, 
				array( 
					'author_id' => implode (',',$_POST['author_id'])	 
				), 
				array( 'id' => $_GET['website_id']), 
				array( 
					'%s',	
				), 
				array( '%s' ) 
            );	
			$message = 'Selected Authors has been saved.';
		}
		$webisteAuthorQuery = $wpdb->prepare ("
													SELECT author_id FROM 
													$author_theme_table 
													WHERE id = %d
													", 
													$_GET['website_id']
												);
		$selectedAuthor = $wpdb->get_col( $webisteAuthorQuery );
		$str='
		<div class="wpbody">
			<h1 style="line-height:32px; ">Choose the author or authors to display on your new website: </h1> <br />';
			
		if(isset($message) && !empty($message)){
		
			$str .='<div style=""><p style="color:green;text-align:left;">'.$message.'</p></div>';
		}
		$authorHtml = AuthorSelectBox($selectedAuthor[0]);
		$str .='
			<form action="" method="post" id="frmLog" name="frmLog" onsubmit="return checkFormValidity()">
				<div style="padding-bottom:20px;">
					'.$authorHtml.'
					<input type="submit" name="action" id="theme_author" value="Save" class="button button-primary save">
					<a href="?page=pba_website_theme_set_up_'.$_GET['website_id'].'"><input type="button" name="back" id="back" value="Back" class="button button-primary save"></a>
					</p>
				</div>
			</form>
		</div>';
		echo $str; 
	} 
}
?>