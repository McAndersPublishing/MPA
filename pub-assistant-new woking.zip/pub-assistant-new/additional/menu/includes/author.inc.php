<?php

if( !function_exists( 'display_author_links_meta_box' ) ) {
	/**
	 * Displays meta boxes.
	 *
	 * @param WP_Post $post Post object.
	 */
	function display_author_links_meta_box( $website_id ) {
		global $wpdb;
		$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
		$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
		//$website_id = $post->ID;
		
		if( array_key_exists( 'pba', $_POST ) ) {
			$input = $_POST[ 'pba' ];
		} else {
			$input = array();
		}
		$image_path = wp_upload_dir();
		$settings = get_option( 'pub-assistant' );
		$languages = $settings[ 'languages' ];
		asort($languages);
		$vendors = $settings[ 'vendors' ];
		if(isset($_POST['pba']['show_translations'])){
		$show_trans='checked';
		}
		
		echo '<form id="vendorpost" method="post" action="" name="vendorpost" enctype="multipart/form-data"><div id="poststuff"><div class="postbox " id="pba-meta-author"><div title="Click to toggle" class="handlediv"><br></div><h3 class="hndle"><span style="font-size:20px">Translation settings option</span></h3><div class="inside">';
		echo '
			<div class="pba-header">
				<input
					id="pba_show_translations"
					name="pba[show_translations]"
					type="checkbox"
					class="pba pba-input"
					title="', __( 'Show translation options?', 'pub-assistant' ), '" 
					value="1"'.$show_trans.'
					/>
				<label for="pba_show_translations">', __( 'Show Translations', 'pub-assistant' ),
					'</label>
			</div>
			';
		echo '</div></div></div>';
		echo '<div id="poststuff"><div class="postbox" id="pba-meta-author-links">
		<div title="Click to toggle" class="handlediv"><br></div>
		<h3 class="hndle"><span style="font-size:20px">Vendors settings for ebook</span></h3><div class="inside">';
		
		if( 0 < count( $vendors ) ) {
			foreach( $vendors as $vendor ) {
				$slug = $vendor[ 'slug' ];
				$name = $vendor[ 'name' ];
				$used_languages = array();
				
				if(in_array('e-book',$vendor['media'])==''){
				continue;
				}				
				
				echo '
					<div class="pba-section">
						<label>', $name, '</label>
					';
				
				
				
				foreach( $languages as $language => $language_name ) {
					$author_vendor_seeting_query = "SELECT * FROM $author_vendor_setting_table WHERE author_id = $website_id AND lang='".$language."' AND vendor_name='".$slug."' ORDER BY `order` ASC";
					$authorVendor = $wpdb->get_results($author_vendor_seeting_query,ARRAY_A);
					
					
					if( !$authorVendor ) {
						continue;
					}
					
					$booktextcheck=0; $bookimgcheck=0;
					
					if($authorVendor[0]['btnstatus']==1) {
						$booktextcheck = 'checked';
					}elseif($authorVendor[0]['btnstatus']==2){
						$bookimgcheck = 'checked';
					}
					
					$displaysta='';
					if($authorVendor[0]['display']==1) {
						$displaysta = 'checked';
					}
					
					$used_languages[] = $language;
					
					echo '
						<div class="pba-item" style="border: 1px solid rgba(37, 37, 37, 0.75);border-radius: 5px;margin-bottom: 0.5em;padding: 1em;">
							<input type="checkbox" value="1" name="vendor_display_'.$language.'_'.$slug.'"'.$displaysta.'>ON/OFF<div style="width: 210px; display: inline-block;padding:0 20px;"><label for="pba_links_', $slug, '_', $language, '">', $language_name, '</label><input type="hidden" name="vendor_record_array" value="'.$vendor_record_string.'">
							<input
								id="pba_links_', $slug, '_', $language, '"
								name="pba[links][', $slug, '][', $language, ']"
								type="text"
								size="23"
								title="', __( 'Text on button for', 'pub-assistant' ), ' ', $name, '."
								placeholder="Enter text for default button"
								value="', esc_attr($authorVendor[0]['display_text_button']), '"
								/>
								
							</div><div style="width: 368px; display: inline-block;"><input type="file" name="vendor_image_'.$language.'_'.$slug.'" id="vendor_image_'.$language.'_'.$slug.'"><div style="display: inline-block;">';
								if($authorVendor[0]['image']!=''){
								echo '<div style="margin-top:-20px"><a href="admin.php?page=vendor-list&amp;action=deleteimgebook&amp;id='.$authorVendor[0]['id'].'&website_id='.$website_id.'" onclick="return showNotice.warn();" class="submitdelete" style="vertical-align:middle;"><img src="'.plugins_url().'/pub-assistant/images/cross_image.jpg" style="float: right;margin: 5px -25px 0 0;width: 17px;" /></a></div><img src="'.$image_path['baseurl'].'/pub_upload/'.$authorVendor[0]['image'].'" style="margin-left: 10px;vertical-align: middle;">';
								}
								echo '</div>
								<input type="hidden" name="vendor_imageup_'.$language.'_'.$slug.'" id="vendor_name_'.$language.'_'.$slug.'" value="'.$authorVendor[0]['image'].'"></div>';
						
						
							echo '<div style="width: 185px; display: inline-block;padding: 0 10px;float: right;margin: 1px 105px 0 0;"><input type="radio" name="buttonselectbook_'.$language.'_'.$slug.'" value="bookbtext_'.$language.'_'.$slug.'" '.$booktextcheck.' >Display text on default button<br><input type="radio" name="buttonselectbook_'.$language.'_'.$slug.'" value="bookbimage_'.$language.'_'.$slug.'" '.$bookimgcheck.'>Display uploaded button image</div><div style="display:inline-block;padding:0 10px;margin:5px -300px 0 0;float: right;"><input onclick="return showNotice.warn();" id="pba_remove_link_', $slug, '_', $language, '" name="pba[remove_link][', $slug, '][', $language, ']" type="submit" class="button pba-button" title="', __( 'Remove this Name.', 'pub-assistant' ), '" value="', __( 'Remove', 'pub-assistant' ), '"/></div></div>';
						
						
				}
			
				if( count( $used_languages ) !== count( $languages ) ) {
					echo '<div class="pba-item" style="border: 1px solid rgba(37, 37, 37, 0.75);border-radius: 5px;margin-bottom: 0.5em;padding: 1em;"><input type="checkbox" value="1" name="vendor_display_'.$slug.'"'.$displaysta.'>ON/OFF<div style="display:inline-block;padding-left: 20px;">';
						
					pba_language_selector( null, 'pba_links_' . $slug . '_new_language', 
						'pba[new_language][' . $slug . ']', $used_languages );
							
					echo '
							<input
								id="pba_new_link_', $slug, '"
								name="pba[new_link][', $slug, ']"
								type="text"
								size="23"
								title="', __( 'Enter text for the button', 'pub-assistant' ), '"
								placeholder="Enter text for default button"
								/>
							
							<input type="file" name="vendor_image_'.$slug.'" id="vendor_image_'.$slug.'"></div><div style="display: inline-block;    padding-left: 20px;"><input
								id="pba_add_link_', $slug, '"
								name="pba[add_link][', $slug, ']"
								type="submit"
								class="button pba-button"
								title="', __( 'Add a name for button for this vendor.', 'pub-assistant' ), '"
								value="', __( 'Save', 'pub-assistant' ), '"
								/></div>
						</div>
						';
				}
				
				echo '</div>';
			}
		}
		
		echo '
			<div class="pba-item pba-options">
				<input
					id="save"
					name="savebook"
					type="submit"
					class="button button-primary button-large"
					value="', __( 'Save', 'pub-assistant' ), '"
					/>
			</div>
				';
				
				echo'</div></div></div></form>';
				
				
		echo '<form id="vendorpostaudio" method="post" action="" name="vendorpostaudio" enctype="multipart/form-data">
		<div id="poststuff"><div class="postbox" id="pba-meta-author-links"><div title="Click to toggle" class="handlediv"><br></div><h3 class="hndle"><span style="font-size:20px">Vendors settings for audio book</span></h3><div class="inside">';
		
		if( 0 < count( $vendors ) ) {
		
			   
			foreach( $vendors as $vendor ) {
				$slug = $vendor[ 'slug' ];
				$name = $vendor[ 'name' ];
				$used_languages = array();
				
				if(in_array('audiobook',$vendor['media'])==''){
				continue;
				}				
				
				echo '
					<div class="pba-section">
						<label>', $name, '</label>
					';
				
				foreach( $languages as $language => $language_name ) {
					$author_vendor_seeting_query = "SELECT * FROM $author_vendor_audiobook_setting_table WHERE author_id = $website_id AND lang='".$language."' AND vendor_name='".$slug."' ORDER BY `order` ASC";
			$authorVendor = $wpdb->get_results($author_vendor_seeting_query,ARRAY_A);			
					
					if( !$authorVendor ) {
						continue;
					}
									
					$textbtnchecked=0;
					$imgbtnchecked=0;
					if($authorVendor[0]['btnstatus']==1) {
						$textbtnchecked = 'checked';
					}elseif($authorVendor[0]['btnstatus']==2){
						$imgbtnchecked = 'checked';
					}
					
					$used_languages[] = $language;
					
					$displayaudi='';
					if($authorVendor[0]['display']==1) {
						$displayaudi = 'checked';
					}
					
					echo '
						<div class="pba-item" style="border: 1px solid rgba(37, 37, 37, 0.75);border-radius: 5px;margin-bottom: 0.5em;padding: 1em;">
							<input type="checkbox" value="1" name="vendor_audiodisplay_'.$language.'_'.$slug.'"'.$displayaudi.'>ON/OFF<div style="width: 210px; display: inline-block;padding:0 20px;"><label for="pba_links_', $slug, '_', $language, '">', $language_name, '</label><input type="hidden" name="vendor_record_array" value="'.$vendor_record_string.'">
							<input
								id="pba_links_', $slug, '_', $language, '"
								name="pba_audio[links][', $slug, '][', $language, ']"
								type="text"
								size="23"
								title="', __( 'Text on button for', 'pub-assistant' ), ' ', $name, '."
								placeholder="Enter text for default button"
								value="', esc_attr($authorVendor[0]['display_text_button']), '"
								/>
								</div>
								<div style="width: 368px; display: inline-block;">
								<input type="file" name="vendor_audioimage_'.$language.'_'.$slug.'" id="vendor_audioimage_'.$language.'_'.$slug.'">
								<div style="display: inline-block;">';
								if($authorVendor[0]['image']!=''){
								echo '<div style="margin-top:-20px"><a href="admin.php?page=vendor-list&amp;action=deleteimgaudio&amp;id='.$authorVendor[0]['id'].'&website_id='.$website_id.'" onclick="return showNotice.warn();" class="submitdelete" style="vertical-align:middle;"><img src="'.plugins_url().'/pub-assistant/images/cross_image.jpg" style="float: right;margin: 5px -25px 0 0;width: 17px;" /></a></div><img src="'.$image_path['baseurl'].'/pub_upload/'.$authorVendor[0]['image'].'" style="margin-left: 10px;vertical-align: middle;">';

								}
								echo '</div>
								<input type="hidden" name="vendor_audioimageup_'.$language.'_'.$slug.'" id="vendor_audioimageup_'.$language.'_'.$slug.'" value="'.$authorVendor[0]['image'].'"></div>';
						
						
									echo '<div style="width: 185px; display: inline-block;padding: 0 10px;float: right;margin: 1px 105px 0 0;"><input type="radio" name="buttonselect_'.$language.'_'.$slug.'" value="btext_'.$language.'_'.$slug.'" '.$textbtnchecked.' >Display text on default button<br><input type="radio" name="buttonselect_'.$language.'_'.$slug.'" value="bimage_'.$language.'_'.$slug.'" '.$imgbtnchecked.'>Display uploaded button image</div><div style="display:inline-block;padding:0 10px;margin:5px -300px 0 0;float: right;"><input onclick="return showNotice.warn();" id="pba_remove_link_', $slug, '_', $language, '" 				name="pba_audio[remove_link][', $slug, '][', $language, ']" 						type="submit" class="button pba-button" title="', __( 'Remove this Name.', 'pub-assistant' ), '" value="', __( 'Remove', 'pub-assistant' ), '" /></div></div>';
									
				}
			
				
				
				if( count( $used_languages ) !== count( $languages ) ) {
					echo '<div class="pba-item" style="border: 1px solid rgba(37, 37, 37, 0.75);border-radius: 5px;margin-bottom: 0.5em;padding: 1em;"><input type="checkbox" value="1" name="vendor_audiodisplay_'.$slug.'"'.$displayaudi.'>ON/OFF<div style="display:inline-block;padding-left: 20px;">';
						
					pba_language_selector( null, 'pba_links_' . $slug . '_new_language', 
						'pba_audio[new_language][' . $slug . ']', $used_languages );
							
					echo '
							<input
								id="pba_new_link_', $slug, '"
								name="pba_audio[new_link][', $slug, ']"
								type="text"
								size="23"
								title="', __( 'Enter text for the button', 'pub-assistant' ), '"
								placeholder="Enter text for default button"
								/>
							
							<input type="file" name="vendor_audioimage_'.$slug.'" id="vendor_audioimage_'.$slug.'"></div><div style="display: inline-block;    padding-left: 20px;"><input
								id="pba_add_link_', $slug, '"
								name="pba[add_link][', $slug, ']"
								type="submit"
								class="button pba-button"
								title="', __( 'Add a name for button for this vendor.', 'pub-assistant' ), '"
								value="', __( 'Save', 'pub-assistant' ), '"
								/></div>
						</div>
						';
				}
				
				echo '</div>';
			}
		}
		
		echo '
			<div class="pba-item pba-options">
				<input
					id="save"
					name="saveaudio"
					type="submit"
					class="button button-primary button-large"
					value="', __( 'Save', 'pub-assistant' ), '"
					/>
			</div>
				';
				
				echo'</div></div></div></form>';
					
	}	
}
/**
 * Meta boxes for author posts.
 */  
if( !function_exists( 'add_author_meta_box') ) {
	add_action('add_meta_box_pba_author','add_author_meta_box');
	/**
	 * Registers meta boxes.
	 */
	function add_author_meta_box() {
		
		$website_id = (isset($_REQUEST[website_id])) ? (int)$_REQUEST[website_id] : 0;  // selected Author ID
			
		$post = $post_type = $post_type_object = null;
		
		if ( $website_id )
			$post = get_post( $website_id );
		if ( $post ) {
			$post_type = $post->post_type;
			$post_type_object = get_post_type_object( $post_type );
		}
		
		display_author_links_meta_box($website_id);	
		
		wp_enqueue_style( 'menu', PBA_PLUGIN_URL.'additional/menu/includes/styles/menu.css' );
		wp_enqueue_style( 'author-edit',PBA_PLUGIN_URL.'additional/menu/includes/styles/author-edit.css' );
		wp_enqueue_script( 'translation-author',PBA_PLUGIN_URL.'additional/menu/includes/scripts/translation-author.js' );
		$language = substr( get_locale(), 0, 2 );
		wp_localize_script( 'translation-author', 'pba', array( 'language' => $language ) );
	}
}
do_action('add_meta_box_pba_author');
if( !function_exists( 'pba_generate_author_title' ) ) {
	add_filter( 'wp_update_post_data', 'pba_generate_author_title', 99, 2 );
	/**
	 * Sets the title of author posts to first name and last name.
	 *
	 * @param array $data Sanitized post data.
	 * @param array $postarr Raw post data.
	 */
	function pba_generate_author_title( $data , $postarr ) {
  	if( !( 'pba_author' === $data[ 'post_type' ] ) ) {
    	return $data;
		}
		$website_id = $postarr[ 'ID' ];
		$first_name = get_post_meta( $website_id, '_pba_first_name', true );
		$last_name = get_post_meta( $website_id, '_pba_last_name', true );
		
		$data[ 'post_title' ] = $first_name . ' ' . $last_name;
				
		return $data;
	}
}
if( !function_exists( 'pba_author_remove_publish_box' ) ) {
	add_action( 'admin_init', 'pba_author_remove_publish_box' );
	/**
	 * Removes the publish box from author posts.
	 */
	function pba_author_remove_publish_box() {
		remove_meta_box( 'submitdiv', 'pba_author', 'side' );
	}
}
?>