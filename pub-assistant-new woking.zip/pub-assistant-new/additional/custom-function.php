<?php
function pagenation($numrows,$limit,$currenthit,$offset,$lnkScr,$lnkParam)
{
		global $action,$cr,$lnkscr;
		$pages=intval($numrows/$limit);

	
		if ($numrows % $limit) { $pages++; }
        $str="";
		$str.= "<table width=100% border=0 cellpadding=1 cellspacing=5>";

		$str.= "<tr><td width=60% valign=top align=center style='color:#1495C4;'><B>Page:</B> ";

		if ($offset == 1) { $currenthit = $offset; }
		else { $currenthit = $offset + 1; }

		if (($numrows - $currenthit) >= $limit ) { $lasthit = $currenthit + ($limit - 1); }
		else { $lasthit = $numrows; }

		$selectedPg = sprintf("%.0f", (($currenthit/$limit) + 1));
		
		for ($i=1; $i<=$pages; $i++)
		{
			if($i <=5 )
            {	
				$newoffset = $limit * ($i - 1);
					
				if($selectedPg == $i) { $str.= "<FONT  class='white_txt' color='red'><b>$i</b></FONT>"; }
				else { $str.= "<a href=".$lnkScr."&offset=$newoffset".$lnkParam." style='color:#1495C4;'>$i</a>"; }
			}
			
			if($i <= 5 && $pages > $i)
			{
				$str.= "&nbsp;|&nbsp;";
			}
		}
		if($pages > 5)
		{
			$str.= "<span><select name='pageing' id='pageing' onchange='return SubmitPage(this.value);'>";
			for($i=6; $i<=$pages; $i++)
			{
				$newoffset = $limit * ($i - 1);
				
				if($_REQUEST['offset'] == $newoffset)
					$select="selected";
				else
					$select="";

				$str.= "<option value='".$newoffset."' ".$select.">".$i."</option>";
				
			}
			$str.= '</select></span>';
		}


		$str.= "&nbsp;</td><td class=normalblack_12 width=10% align=right>";

		if($offset!=0)
		{   if($offset < $limit)
			{
			$cr=0;

			}
			else
			{
			$cr=$offset-$limit;
			}
		   $str.="<a href=".$lnkscr."&offset=$cr".$lnkParam." style='color:#1495C4;'>Previous</a>";

           if ($offset+($limit) >= $numrows)
           {
           		$str.= "&nbsp;&nbsp;";
           }
           else
           {
           		$str.= "&nbsp;|&nbsp;";
           }
		}

		if($offset<$numrows && (($numrows-$offset)>$limit) || (($numrows-$offset)<$limit))
		{	
			if(($numrows-$offset) > $limit)
			{
				$str.= "<a href=".$lnkscr."&offset=$lasthit".$lnkParam." style='color:#1495C4;'>Next</a>";
			}
			else
			{
				$str.= "<span style='color:#666666;text-decoration:none'>Next</span>";
			}

		}


		$str.= "</td></tr>";
		
		 $str.= '<tr><td style="color:#1495C4;" align="right" colspan="2">';
	
	 	$str.="Showing ";
        if(($offset+1) > $numrows)
		{
			$str.=$offset;
		}
		else
		{
			$str.=$offset+1;
		}
	  	$str.=" - ";
	  	$last=$offset+$limit;
	  	if($last <= $numrows)
	  	{
	  		$last=$last;
	  	}
	  	else 
	  	{
	  		$last=$numrows;
	  	}
	  	$str.=$last;
	  	$str.=" (Total ".$numrows." )";
		

		$str.= "</td></tr></table>";
	 return $str;
}



if( !function_exists( 'allAuthorSelectBox' ) ) {
	function allAuthorSelectBox()
	{
		global $wpdb;
		
		$selected = (isset($_REQUEST[author_id])) ? $_REQUEST[author_id] : 0;
		$Author = get_post($selected);
		?>
		<p><h1>Author : <?php echo $Author->post_title; ?></h1></p>
		<?php
	}
}

if( !function_exists( 'pr' ) ) {
	function pr($arr){
		echo "<pre>";print_r($arr);echo "</pre>";
	}
}


if( !function_exists( 'AuthorSelectBox' ) ) {
	function AuthorSelectBox($selected)
	{
		global $wpdb;
		
		$args = array(
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'post_type'        => 'pba_author',
			'post_status'      => 'publish',
		);
		
		$AllAuthors = get_posts($args);	
		
		$str .='
			<p>
				<h2>Author List: </h2>
				<select name="author_id[]" id="select_author_id" multiple>';

					$authorId = (is_int($selected))? $selected : explode(',', $selected);
					foreach ( $AllAuthors as $recordSet ) 
					{	
					
						if(in_array($recordSet->ID, $authorId))
							$str .='<option value="'.$recordSet->ID.'" selected="selected">'.$recordSet->post_title.'</option>';
						else
							$str .='<option value="'.$recordSet->ID.'">'.$recordSet->post_title.'</option>';
					}
				$str .='</select>
			</p>
		';
		$str .='<script>
			function checkFormValidity(){
				if(document.getElementById(\'author_id\').value==\'\')
				{ 
					alert(\'Choose an Author.\');
					return false; 
				}
				return true;
			}
		</script>';
		return $str;
	}
}

if( !function_exists( 'displayHeading' ) ) {
	/**
	 * Displays the heading on setting page based on selected website 
	 */
	function displayHeading($website_id = 0, $mergeWith){
		echo '<div class="wrap">';
		global $wpdb;
		$query = $wpdb->prepare ("SELECT author_id FROM ".$wpdb->prefix ."author_theme where id = %d", $website_id);
		$author_ids = $wpdb->get_col( $query );
		$aids = $author_id = $author_ids[0];
		
		$AuthorNameArr = array();
		if (is_int($author_id)){
			$authorInfo = get_post($author_id);
			$AuthorName = $authorInfo->post_title;
		}else{
			$aids = explode(',',$author_id);
			if (is_array ($aids)){
				foreach ($aids as $aid){
					$authorInfo = get_post($aid);
					$AuthorNameArr[] = $authorInfo->post_title;	
				}
				$AuthorName = implode (' ,', $AuthorNameArr);
			}
		}
		
		if ($AuthorName == '') {
			echo '<h2>'.$mergeWith.'</h2>';
		}else
			echo '<h2>'.$mergeWith.' for '.$AuthorName.'</h2>';
		
		return $aids;     /// returning Author IDs against the 
	}
}
?>