<?php 
require_once('../../../../wp-config.php');

if(isset($_POST['audiobook']) && !empty($_POST['audiobook'])){
	parse_str($_POST['pages'], $pageOrder);
	echo $website_id = $_POST['website_id'];
	$updated_author_audBookSetting = array();
	$website_aud_languages = get_post_meta($website_id, 'website_aud_languages', true);
	
	foreach ($pageOrder['page'] as $key => $value) {
		$website_aud_languages[$value]['order'] = $key;
		$updated_author_audBookSetting[$value] = $website_aud_languages[$value];
	}	
	
	update_post_meta($website_id, 'website_aud_languages' , $updated_author_audBookSetting);
	
}
else if(isset($_POST['vendor']) && !empty($_POST['vendor'])){
	$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
	parse_str($_POST['pages'], $pageOrder);
	$author_id = $_POST['author_id'];
	foreach ($pageOrder['page'] as $key => $value) {
		$data   = array('order'=>$key);
		$where  = array('id'=>$value,'author_id'=>$author_id);
		$format = array('%d');
		$where_format = array('%d','%d');
		$wpdb->update( $author_vendor_setting_table, $data, $where, $format , $where_format );
	}
	
}
else if(isset($_POST['vendorAudiobook']) && !empty($_POST['vendorAudiobook'])){
	$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
	parse_str($_POST['pages'], $pageOrder);
	$author_id = $_POST['author_id'];
	foreach ($pageOrder['page'] as $key => $value) {
		$data   = array('order'=>$key);
		$where  = array('id'=>$value,'author_id'=>$author_id);
		$format = array('%d');
		$where_format = array('%d','%d');
		$wpdb->update( $author_vendor_audiobook_setting_table, $data, $where, $format , $where_format );
	}
}
else {
	parse_str($_POST['pages'], $pageOrder);
	$website_id = $_POST['website_id'];
	$website_languages = get_post_meta($website_id, 'website_languages', true); // fetching Author related language information
	
	$updated_website_languages = array();
	foreach ($pageOrder['page'] as $key => $value) {
		$website_languages[$value]['order'] = $key;
		$updated_website_languages[$value] = $website_languages[$value];
	}
	update_post_meta($website_id, 'website_languages' , $updated_website_languages);
}
?>