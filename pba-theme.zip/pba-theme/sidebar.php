<?php
/**
 * The sidebar containing the main widget area
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package PBA Theme
 * @subpackage pha_theme
 * @since Twenty Twelve 1.0
 */
?>
<?php //if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div id="secondary" class="widget-area" role="complementary">
		<?php    
			do_action ('pba_sidebar_langlist');			
//			dynamic_sidebar( 'sidebar-1' ); 
		?>
	</div><!-- #secondary -->
<?php //endif; ?>