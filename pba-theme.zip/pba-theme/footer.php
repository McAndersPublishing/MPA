<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
	<div class="cleaner_with_height">&nbsp;</div>
	</div><!-- end of content -->

	<!-- <footer id="colophon" role="contentinfo">
		<div class="site-info">
			<?php do_action( 'twentytwelve_credits' ); ?>
			<a href="<?php echo esc_url( __( 'http://wordpress.org/', 'twentytwelve' ) ); ?>" title="<?php esc_attr_e( 'Semantic Personal Publishing Platform', 'twentytwelve' ); ?>"><?php printf( __( 'Proudly powered by %s', 'twentytwelve' ), 'WordPress' ); ?></a>
		</div><!-- .site-info -->
	<!--</footer> --><!-- #colophon -->

	<div id="templatemo_footer">
		<?php get_sidebar('footer'); ?>   
	</div>

</div><!-- end of container -->

<?php wp_footer(); 
global $global_settings;

$ga = get_post_meta($global_settings['themeAuthorID'], '_auth_google_analytics', true);

if (is_array($ga))  {
    if ($ga['display'] == '1'){
	    echo $ga['google_analytics_code'];
    }
}
?>
<script type="text/javascript">
/* <![CDATA[ */
var commonL10n = {
    warnDelete: "You are about to permanently delete the selected items.\n  \'Cancel\' to stop, \'OK\' to delete."
};
try{convertEntities(commonL10n);}catch(e){};
var thickboxL10n = {
    next: "Next &gt;",
    prev: "&lt; Prev",
    image: "Image",
    of: "of",
    close: "Close",
    noiframes: "This feature requires inline frames. You have iframes disabled or your browser does not support them.",
    loadingAnimation: "<?php bloginfo('template_url')?>/js/thickbox/loadingAnimation.gif",
    closeImage: "<?php bloginfo('template_url')?>/js/thickbox/tb-close.png"
};
try{convertEntities(thickboxL10n);}catch(e){};
/* ]]> */
</script>
<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/thickbox/thickbox.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/thickbox/preview.js"></script> 
</body>
</html>