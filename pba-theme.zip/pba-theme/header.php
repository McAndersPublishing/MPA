<?php
/**
 * The Header template for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link href="<?php bloginfo('template_url')?>/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_url')?>/js/thickbox/thickbox.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/jquery.min.js"></script>
<?php //wp_head(); ?>
<?php 
if(isset($google_analytics_js_code) && !empty($google_analytics_js_code))
	echo stripslashes($google_analytics_js_code);
?>
</head>
<body <?php body_class(); ?>>
<div id="templatemo_container">
	<div id="templatemo_menu">
		<?php wp_nav_menu( array( 'theme_location' => '', 'menu_class' => 'nav-menu' , 'menu' => 'pbamenu' ) ); ?>
	</div> <!-- end of menu -->
  <div id="templatemo_header">
      <div id="templatemo_blog">
          <div id="templatemo_title"><?php pba_site_title();?></div>
          <div id="templatemo_tagline"><?php pba_site_tagline();?></div>
      </div>
      <div id="templatemo_special_offers">
<?php
    pba_html_specialOffers();
?>      
	  </div>
      <div id="templatemo_new_books">
<?php
    pba_html_latestBooks();
?>			
	</div>
  </div> <!-- end of header -->
	<div id="templatemo_content" style="min-height:600px;">