<?php
/**
 * The sidebar containing the main widget area
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>

	<?php //if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
		<div id="secondary" class="widget-area" role="complementary">
		<?php 
			$settings = get_option( 'pub-assistant' );
			$languages = $settings[ 'languages' ];
			//echo '<pre>';
			//print_r($languages);
			//echo '</pre>';
			$url = site_url();
			$language_table = $wpdb->prefix . "language";
			$author_theme_table = $wpdb->prefix . "author_theme";
			$author_sql    = "SELECT author_id FROM $author_theme_table WHERE 1=1";
		    $author_result = $wpdb->get_col( $author_sql );
			$author_id = $author_result[0];
			if(isset($languages) && !empty($languages)) {
		?>
		 <div class="templatemo_content_left_section">
            <h1>Categories</h1>
			<?php 
				
				echo '<ul>';
					foreach( $languages as $slug => $language ) {
						if($wpdb->get_var("show tables like '$language_table'") == $language_table) {
							echo "SELECT lang_real_value FROM $language_table WHERE lang_key='$slug' AND author_id=$author_id";
							$language = $wpdb->get_row("SELECT lang_real_value,display FROM $language_table WHERE lang_key='$slug' AND author_id=$author_id",ARRAY_N);
							
						}	
						$args = array(
							'post_type' => 'pba_book',
							'meta_query' => array(
								array(
									'key' => '_pba_language',
									'value' => $slug

								)
							)
						);
						$the_query = new WP_Query( $args );
						if ( $the_query->have_posts() ) {
							if($language[1]){
								echo '<li><a href="'.$url.'?page_id=1484&lang='.$slug.'">'.$language[0].'</a></li>';
							}
						}
					}
				echo '</ul>';
		    ?>
          </div>
        <?php }?>
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div><!-- #secondary -->
	<?php //endif; ?>