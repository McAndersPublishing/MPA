<?php
/*
Template Name: My Home Page
*/
 get_header(); 
$authorThemeTable = $wpdb->prefix . "author_theme";
$authorSql    = "SELECT author_id FROM $authorThemeTable WHERE 1=1";
$authorResultSet = $wpdb->get_col( $authorSql );
$authorId =  $authorResultSet[0];
 ?>
<div id="templatemo_content_left">
<?php get_sidebar(); ?>
</div> <!-- end of content left -->
	<!-- <div id="primary" class="site-content"> -->
	<?php 
	    if(!isset($_GET['lang']) || empty($_GET['lang'])) {
			$lang = 'en';
		}
		else{
			$lang = $_GET['lang'];
		}
		if(!isset($_GET['book_type']) || empty($_GET['book_type'])) {
			$book_type = 'ebook';
		}
		else{
			$book_type = $_GET['book_type'];
		}
		$settings = get_option( 'pub-assistant' );
		$series_names = $settings['look-ups']['series_names']['values'];
		$genres = $settings['look-ups'][ 'genres' ]['values'];
		$vendor_setting = $settings['vendors'];
	?>
	<div class="templatemo-tabmain">
		<div class="tab-link">
		<!--tabs li -->
		<ul id="tabs">
		<?php 
			if($book_type=='audiobook' && count($vendor_setting)>0) {

				foreach($vendor_setting as $keyarray =>$value){
					if($keyarray==0){
						$slug = $value['slug'];
						$query_cond .=" (mt4.meta_key = '_pba_link_".$slug."_audiobook' AND mt4.meta_value != '')";
					}
					else {
						$slug = $value['slug'];
						$query_cond .=" OR (mt4.meta_key = '_pba_link_".$slug."_audiobook' AND mt4.meta_value != '') ";
					}
				}
		    }
			//echo $query_cond;exit;
			$k = 0;
			foreach( $genres as $slug => $genre ) {

				if($book_type!='audiobook'){

					echo $tabQueryStr ="SELECT ".$wpdb->prefix."posts.ID,".$wpdb->prefix."posts.post_modified FROM ".$wpdb->prefix."posts INNER JOIN ".$wpdb->prefix."postmeta AS mt ON (".$wpdb->prefix."posts.ID = mt.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt1 ON (".$wpdb->prefix."posts.ID = mt1.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt2 ON (".$wpdb->prefix."posts.ID = mt2.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt3 ON (".$wpdb->prefix."posts.ID = mt3.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt4 ON (".$wpdb->prefix."posts.ID = mt4.post_id) 
					WHERE 1=1  
					AND ".$wpdb->prefix."posts.post_type = 'pba_book' 
					AND (mt.meta_key = '_pba_language' AND CAST(mt.meta_value AS CHAR) = '$lang')
					AND (mt1.meta_key = '_pba_genre' AND CAST(mt1.meta_value AS CHAR) = '$slug')
					AND ((mt2.meta_key = '_pba_author_1' AND CAST(mt2.meta_value AS CHAR) = '$authorId') OR (mt3.meta_key = '_pba_author_2' AND CAST(mt3.meta_value AS CHAR) = '$authorId')) 
					AND (mt4.meta_key = 'book_publish' AND CAST(mt4.meta_value AS CHAR) = 'on' OR mt4.meta_key = 'book_publish' AND CAST(mt4.meta_value AS CHAR) = '')
					GROUP BY ".$wpdb->prefix."posts.ID 
					ORDER BY ".$wpdb->prefix."posts.post_modified DESC";
				}
				else {

					$tabQueryStr ="SELECT ".$wpdb->prefix."posts.ID,".$wpdb->prefix."posts.post_modified FROM ".$wpdb->prefix."posts INNER JOIN ".$wpdb->prefix."postmeta AS mt ON (".$wpdb->prefix."posts.ID = mt.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt1 ON (".$wpdb->prefix."posts.ID = mt1.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt2 ON (".$wpdb->prefix."posts.ID = mt2.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt3 ON (".$wpdb->prefix."posts.ID = mt3.post_id)";
					if(isset($query_cond) && !empty($query_cond)) {
						$tabQueryStr .=" INNER JOIN ".$wpdb->prefix."postmeta AS mt4 ON (".$wpdb->prefix."posts.ID = mt4.post_id) ";
					}
					$tabQueryStr .="WHERE 1=1  
					AND ".$wpdb->prefix."posts.post_type = 'pba_book' 
					AND ".$wpdb->prefix."posts.post_status = 'publish'
					AND (mt.meta_key = '_pba_language' AND CAST(mt.meta_value AS CHAR) = '$lang')
					AND (mt1.meta_key = '_pba_genre' AND CAST(mt1.meta_value AS CHAR) = '$slug')
					AND ((mt2.meta_key = '_pba_author_1' AND CAST(mt2.meta_value AS CHAR) = '$authorId') OR (mt3.meta_key = '_pba_author_2' AND CAST(mt3.meta_value AS CHAR) = '$authorId')) ";
					if(isset($query_cond) && !empty($query_cond)) {
						$tabQueryStr .=" AND ( $query_cond ) ";
					}
					$tabQueryStr .="GROUP BY ".$wpdb->prefix."posts.ID 
					ORDER BY ".$wpdb->prefix."posts.post_modified DESC";
				
				}
				//echo $tabQueryStr.'<br/>';
				
				$postsResults = $wpdb->get_results($tabQueryStr, ARRAY_N);
				if(isset($genre[$lang]) && !empty($genre[$lang])){
					if(count($postsResults)>0){
						$k++;
						if(isset($_REQUEST['genre'])) {
							if($_REQUEST['genre']==$slug) {
								echo '<li class="active"><a href="#tab'.$slug.'">'.$genre[$lang].'</a></li>';
							}
							else {
								echo '<li><a href="#tab'.$slug.'">'.$genre[$lang].'</a></li>';
							}
						}else {
							if($k==1){
								echo '<li class="active"><a href="#tab'.$slug.'">'.$genre[$lang].'</a></li>';
							}
							else {
									echo '<li><a href="#tab'.$slug.'">'.$genre[$lang].'</a></li>';
							}
						}
					 }
				}	
			}
		?>
		</ul>
		<!--close tabs-->
		</div>
	<div class="tab-content">
		<?php 
		$j = 0;
		foreach( $genres as $slug => $genre ) {
			$QueryStr = '';
			if($book_type!='audiobook'){

				$QueryStr ="SELECT ".$wpdb->prefix."posts.ID,".$wpdb->prefix."posts.post_modified FROM ".$wpdb->prefix."posts INNER JOIN ".$wpdb->prefix."postmeta AS mt ON (".$wpdb->prefix."posts.ID = mt.post_id)
				INNER JOIN ".$wpdb->prefix."postmeta AS mt1 ON (".$wpdb->prefix."posts.ID = mt1.post_id)
				INNER JOIN ".$wpdb->prefix."postmeta AS mt2 ON (".$wpdb->prefix."posts.ID = mt2.post_id)
				INNER JOIN ".$wpdb->prefix."postmeta AS mt3 ON (".$wpdb->prefix."posts.ID = mt3.post_id) 
				INNER JOIN ".$wpdb->prefix."postmeta AS mt4 ON (".$wpdb->prefix."posts.ID = mt4.post_id)
				WHERE 1=1  
				AND ".$wpdb->prefix."posts.post_type = 'pba_book'
				AND (mt.meta_key = '_pba_language' AND CAST(mt.meta_value AS CHAR) = '$lang')
				AND (mt1.meta_key = '_pba_genre' AND CAST(mt1.meta_value AS CHAR) = '$slug')
				AND ((mt2.meta_key = '_pba_author_1' AND CAST(mt2.meta_value AS CHAR) = '$authorId') OR (mt3.meta_key = '_pba_author_2' AND CAST(mt3.meta_value AS CHAR) = '$authorId')) 
				AND (mt4.meta_key = 'book_publish' AND CAST(mt4.meta_value AS CHAR) = 'on' OR mt4.meta_key = 'book_publish' AND CAST(mt4.meta_value AS CHAR) = '')
				GROUP BY ".$wpdb->prefix."posts.ID 
				ORDER BY ".$wpdb->prefix."posts.post_modified DESC";
			}
			else {

				$QueryStr ="SELECT ".$wpdb->prefix."posts.ID,".$wpdb->prefix."posts.post_modified FROM ".$wpdb->prefix."posts INNER JOIN ".$wpdb->prefix."postmeta AS mt ON (".$wpdb->prefix."posts.ID = mt.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt1 ON (".$wpdb->prefix."posts.ID = mt1.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt2 ON (".$wpdb->prefix."posts.ID = mt2.post_id)
					INNER JOIN ".$wpdb->prefix."postmeta AS mt3 ON (".$wpdb->prefix."posts.ID = mt3.post_id)";
					if(isset($query_cond) && !empty($query_cond)) {
						$QueryStr .=" INNER JOIN ".$wpdb->prefix."postmeta AS mt4 ON (".$wpdb->prefix."posts.ID = mt4.post_id) ";
					}
					$QueryStr .="WHERE 1=1  
					AND ".$wpdb->prefix."posts.post_type = 'pba_book' 
					AND ".$wpdb->prefix."posts.post_status = 'publish'
					AND (mt.meta_key = '_pba_language' AND CAST(mt.meta_value AS CHAR) = '$lang')
					AND (mt1.meta_key = '_pba_genre' AND CAST(mt1.meta_value AS CHAR) = '$slug')
					AND ((mt2.meta_key = '_pba_author_1' AND CAST(mt2.meta_value AS CHAR) = '$authorId') OR (mt3.meta_key = '_pba_author_2' AND CAST(mt3.meta_value AS CHAR) = '$authorId')) ";
					if(isset($query_cond) && !empty($query_cond)) {
						$QueryStr .=" AND ( $query_cond ) ";
					}
					$QueryStr .="GROUP BY ".$wpdb->prefix."posts.ID 
					ORDER BY ".$wpdb->prefix."posts.post_modified DESC";
					
			}
			
           $booksResults = $wpdb->get_results($QueryStr, ARRAY_N);
			if(count($booksResults)>0){
				$j++;
				if(isset($_REQUEST['genre'])) {
						if($_REQUEST['genre']==$slug) { ?>
							<div id="tab<?php echo $slug;?>" class="contab" style="display:block;">
						<?php }
						else { ?>
							<div id="tab<?php echo $slug;?>" class="contab">
						<?php }
				}else {
					if($j==1){ ?>
						<div id="tab<?php echo $slug;?>" class="contab" style="display:block;">
					<?php }
					else { ?>
							<div id="tab<?php echo $slug;?>" class="contab">
					<?php }
				}?>

				
			 <div id="templatemo_content_right">
				<div id="content" role="main">
				<?php 
				 $postArray = array();
				 $arraywithseries = array();
				 foreach ( $booksResults as $postkey =>$postIDArray ) {
					$postArray[] = $postIDArray[0];
				 }
				
				$postString = implode(',',$postArray);

				$seriesNameQuery = "SELECT meta_value 
									FROM ".$wpdb->prefix."posts 
									INNER JOIN ".$wpdb->prefix."postmeta as pm
									ON (".$wpdb->prefix."posts.ID = pm.post_id)
									WHERE 1 = 1
									AND pm.`meta_key` = '_pba_series_name'
									AND pm.`post_id` 
									IN ( ".$postString." )  GROUP BY meta_value
									ORDER BY ".$wpdb->prefix."posts.post_modified DESC";
				$seriesResults = $wpdb->get_results($seriesNameQuery, ARRAY_N);
				
				$seriesPostNameQuery = "SELECT meta_value 
									as seriesValue,".$wpdb->prefix."posts.post_modified,post_id 
									FROM ".$wpdb->prefix."posts 
									INNER JOIN ".$wpdb->prefix."postmeta as pm
									ON (".$wpdb->prefix."posts.ID = pm.post_id)
									WHERE 1 = 1
									AND pm.`meta_key` = '_pba_series_name'
									AND pm.`post_id` 
									IN ( ".$postString." )  
									ORDER BY ".$wpdb->prefix."posts.post_modified DESC";
				$seriesPostResults = $wpdb->get_results($seriesPostNameQuery, ARRAY_N);
				$seriesArray = array();
				 foreach ( $seriesPostResults as $key =>$value ) {
					$seriesArray[$value[2]] = $value[0];
				 }
				
				foreach ( $seriesArray as $postidkey =>$postidvalue ) {
					$pidarray = array_keys($seriesArray,$postidvalue);
					$arraywithseries[$postidvalue] = $pidarray;
				}
				
				foreach($arraywithseries as $key=>$postidvaluearray){
					if(count($postidvaluearray)>1){ ?>
						<div class="inner-for-group">
						<h1><?php echo $series_names[$key][$lang];?></h1>
					<?php foreach($postidvaluearray as $key=>$value){?>
							<div class="templatemo_product_box"><?php $meta_values = get_post_meta( $value); ?>
							<div class="product_info">
							  <p>
							   <?php 
								$url = wp_get_attachment_url( get_post_thumbnail_id($postidvaluearray[0]));?>
							   <img src="<?php echo $url;?>" width="144" height="216" />
							   <?php 
									$description = preg_replace("/style=\"[^\"]*\"/", " ", $meta_values['_pba_description'][0]);
									$strlen = strlen($description);
								if(strlen($description)>500){
									echo substr($description,0,500).'<br/><a href="javascript:voild();" id="showtext'.$postidvaluearray[0].'">See more...</a>';
									echo '<span id="seetext'.$postidvaluearray[0].'" style="display:none;">'.substr($description,501,$strlen).'<br/><a href="javascript:voild();" id="hidetext'.$postidvaluearray[0].'">Hide...</a></span>';
								}
								else {
									echo $description;
								}
							
							   ?>
							  </p>
							  <div class="buy_now_button"><a href="<?php echo $meta_values['_pba_link_amazon_e-book'][0];?>">Buy Now Amazon</a></div>
							  <div class="buy_now_button"><a href="http://bit.ly/Y3xwAz">Buy Now  for Nook</a></div>
							  <div class="buy_now_button"><a href="http://bit.ly/VJDRl5">Buy All Formats</a></div>
							</div>
						</div>
						<?php 
						}?>
						</div>	
					<?php }
					else { ?>
						<div class="templatemo_product_box"><?php $meta_values = get_post_meta( $postidvaluearray[0] ); ?>
							<h1><span id="btAsinTitle3"><strong><?php //echo $series_names[$meta_values['_pba_series_name'][0]][$lang].'----'?><?php echo get_the_title($postidvaluearray[0]); ?> </strong></span></h1>
							<div class="product_info">
							  <p>
							  <?php $url = wp_get_attachment_url( get_post_thumbnail_id($postidvaluearray[0]));?>
							   <img src="<?php echo $url;?>" width="144" height="216" />
							  <?php 
									$description = preg_replace("/style=\"[^\"]*\"/", " ", $meta_values['_pba_description'][0]);
								$strlen = strlen($description);
								if(strlen($description)>500){
									echo substr($description,0,500).'<br/><a href="javascript:voild();" id="showtext'.$postidvaluearray[0].'">See more...</a>';
									echo '<span id="seetext'.$postidvaluearray[0].'" style="display:none;">'.substr($description,501,$strlen).'<br/><a href="javascript:voild();" id="hidetext'.$postidvaluearray[0].'">Hide...</a></span>';
								}
								else {
									echo $description;
								}
							
							   ?> </p>
							  <div class="buy_now_button"><a href="<?php echo $meta_values['_pba_link_amazon_e-book'][0];?>">Buy Now Amazon</a></div>
							  <div class="buy_now_button"><a href="http://bit.ly/Y3xwAz">Buy Now  for Nook</a></div>
							  <div class="buy_now_button"><a href="http://bit.ly/VJDRl5">Buy All Formats</a></div>
							</div>
						</div>
					<?php
					}

				}
				
				?>
				</div><!-- #content -->
				
			<div class="cleaner_with_height">&nbsp;</div> 

		</div>
		<div class="clrdiv"></div>
		</div> <!-- end of content right -->
		<?php }?>
		<?php }?>
		</div> <!-- tab-content -->
  </div><!--close start the tab section -->	
  <script>
  function showhide(divid){
	$("#showtext").click(function() {
		$("#seetext").slideToggle();
		$("#showtext").hide();
		$("#hidetext").show(700);
	});		
	$("#hidetext").click(function() {
		$("#seetext").slideToggle();
		$("#showtext").show(800);
		$("#hidetext").hide(0);			
	});
  }
  </script>
<?php get_footer(); ?>