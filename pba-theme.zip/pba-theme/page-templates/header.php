<?php
/**
 * The Header template for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link href="<?php bloginfo('template_url')?>/css/style.css" rel="stylesheet" type="text/css" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php // Loads HTML5 JavaScript file to add support for HTML5 elements in older IE versions. ?>
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/jquery.min.js"></script>
<?php wp_head(); ?>
<script>
   jQuery(document).ready(function () {
       //  When user clicks on tab, this code will be executed
       jQuery("#tabs li").click(function () {
           //  First remove class "active" from currently active tab
           jQuery("#tabs li").removeClass('active');
           //  Now add class "active" to the selected/clicked tab
           jQuery(this).addClass("active");
           //  Hide all tab content
           jQuery(".contab").hide();
           //  Here we get the href value of the selected tab
           var selected_tab = jQuery(this).find("a").attr("href");
           //  Show the selected tab content
           jQuery(selected_tab).show();
           //  At the end, we add return false so that the click on the link is not executed
           return false;
       });
   });

   function changetab(){
		  //  First remove class "active" from currently active tab
           jQuery("#tabs li").removeClass('active');
           //  Now add class "active" to the selected/clicked tab
           jQuery('#tab1').addClass("active");
           //  Hide all tab content
           jQuery(".contab").hide();
           //  Here we get the href value of the selected tab
           var selected_tab = jQuery(this).find("a").attr("href");
           //  Show the selected tab content
           jQuery(selected_tab).show();
           //  At the end, we add return false so that the click on the link is not executed
           return false;
   }
</script>
</head>

<body <?php body_class(); ?>>
<!-- <div id="page" class="hfeed site"> -->
<?php $settings = get_option( 'pub-assistant' );?>
<div id="templatemo_container">
	<div id="templatemo_menu">
	<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
  </div> <!-- end of menu -->
  <?php 
	global $wpdb;
	if(!isset($_GET['lang']) || empty($_GET['lang'])) {
		$lang = 'en';
	}
	else{
		$lang = $_GET['lang'];
	}
	$authorSpecialOffersTable = $wpdb->prefix . "author_special_offers";
	$authorThemeTable = $wpdb->prefix . "author_theme";
	$authorLatestReleaseTable = $wpdb->prefix . "author_latest_release";
	$authorSql    = "SELECT author_id FROM $authorThemeTable WHERE 1=1";
	$authorResultSet = $wpdb->get_col( $authorSql );
	$authorId =  $authorResultSet[0];
	$specialOffers = $wpdb->get_row("SELECT * FROM $authorSpecialOffersTable WHERE author_id =$authorId AND lang_key='$lang'");
	$newBooks = $wpdb->get_row("SELECT * FROM $authorLatestReleaseTable WHERE author_id =$authorId AND lang_key='$lang'");
  ?>
  <div id="templatemo_header">
      <div id="templatemo_special_offers">
		<?php 
		if(isset($specialOffers->special_offers) && !empty($specialOffers->special_offers)){
			echo $specialOffers->special_offers;
		}
		?>
	  </div>
      <div id="templatemo_new_books">
	  <?php if(isset($newBooks) && !empty($newBooks)){
		 echo '<h3>'.$newBooks->headline.'</h3>'; 
	  }?>
	  <?php 
	  $limit = 4;
	  if(isset( $newBooks->no_of_titles ) && !empty( $newBooks->no_of_titles )) {
		$limit = $newBooks->no_of_titles;
	  }
	  $latestReleaseQueryStr = "SELECT ".$wpdb->prefix."posts.ID FROM ".$wpdb->prefix."posts 
								INNER JOIN ".$wpdb->prefix."postmeta AS mt ON (".$wpdb->prefix."posts.ID = mt.post_id)
								INNER JOIN ".$wpdb->prefix."postmeta AS mt1 ON (".$wpdb->prefix."posts.ID = mt1.post_id)
								INNER JOIN ".$wpdb->prefix."postmeta AS mt2 ON (".$wpdb->prefix."posts.ID = mt2.post_id) WHERE 1=1  
								AND ".$wpdb->prefix."posts.post_type = 'pba_book' 
								AND ".$wpdb->prefix."posts.post_status = 'publish'
								AND (mt.meta_key = '_pba_language' AND CAST(mt.meta_value AS CHAR) = '$lang')
								AND ((mt1.meta_key = '_pba_author_1' AND CAST(mt1.meta_value AS CHAR) = '$authorId') OR (mt2.meta_key = '_pba_author_2' AND CAST(mt2.meta_value AS CHAR) = '219')) GROUP BY ".$wpdb->prefix."posts.ID ORDER BY ".$wpdb->prefix."posts.post_date DESC LIMIT 0 , $limit";
	$latestReleaseResults = $wpdb->get_results($latestReleaseQueryStr, ARRAY_N);

	$vendor_setting = $settings['vendors'];
	foreach($vendor_setting as $key =>$value){
		if($key==0){
			$slug = $value['slug'];
			$query_cond .=" (meta_key = '_pba_link_".$slug."_audiobook' AND meta_value != '')";
		}
		else {
			$slug = $value['slug'];
			$query_cond .=" OR (meta_key = '_pba_link_".$slug."_audiobook' AND meta_value != '')";
		}
	}
	$audiobook_query = "SELECT * 
					FROM ".$wpdb->prefix."postmeta 
					WHERE `meta_key` LIKE '%_pba_language%'
					AND post_id
					IN (
						SELECT DISTINCT (post_id)
						FROM ".$wpdb->prefix."postmeta
						WHERE $query_cond
						AND post_id IN (
							SELECT DISTINCT (post_id)
							FROM ".$wpdb->prefix."postmeta 
							WHERE (
							`meta_key` = '_pba_author_1'
							 AND `meta_value` = '$author_result[0]'
							)
							OR (
							`meta_key` = '_pba_author_2'
							 AND `meta_value` = '$author_result[0]'
						)
						)
					) AND meta_value IN ('".$lang."') GROUP BY post_id ORDER BY  ".$wpdb->prefix."postmeta.meta_id DESC LIMIT 0,2
					";

	  //$audiobookRecordSets = $wpdb->get_results($audiobook_query,ARRAY_A);
	  //$audiobooklinks = $wpdb->get_results("SELECT * FROM $author_audiobook_setting_table WHERE author_id=$author_result[0] AND audiobook_key ='".$language['lang_key']."' ORDER BY `order` ASC" ,ARRAY_A);
	  //echo "<pre>";
	  //print_r($audiobookRecordSets);
	  //echo '</pre>';
	  if(count($latestReleaseResults)>0){
			?>
			<ul>
			<?php foreach($latestReleaseResults as $key=>$value) {
				if(strlen(get_the_title($value[0]))<=25)
					echo '<li><a href="javascript:changetab();">'.get_the_title($value[0]).'</a></li>';
				else
					echo '<li>'.substr(get_the_title($value[0]),0,23).'...</li>';
		    }?>
			</ul>
	  <?php }?>
      </div>
  </div> <!-- end of header -->

	<div id="templatemo_content">
	<!-- <div id="main" class="wrapper"> -->