<?php
/**
 * pba theme functions and definitions
 * @package Book Management
 * @subpackage pba-theme
 * 
 */

// Set up the content width value based on the theme's design and stylesheet.

if ( ! isset( $content_width ) )
	$content_width = 625;
  
function twentytwelve_widgets_init() {
	register_sidebar( array(
		'name' => __( 'Main Sidebar', 'twentytwelve' ),
		'id' => 'sidebar-1',
		'description' => __( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'twentytwelve' ),
		'before_widget' => '<div class="templatemo_content_left_section">',
		'after_widget' => '</div>',
		'before_title' => '<h1 class="widget-title">',
		'after_title' => '</h1>',
	) );

	register_sidebar( array(
		'name' => __( 'First Front Page Widget Area', 'twentytwelve' ),
		'id' => 'sidebar-2',
		'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'twentytwelve' ),
		'before_widget' => '<div class="templatemo_content_left_section">',
		'after_widget' => '</div>',
		'before_title' => '<h1 class="widget-title">',
		'after_title' => '</h1>',
	) );

	register_sidebar( array(
		'name' => __( 'Second Front Page Widget Area', 'twentytwelve' ),
		'id' => 'sidebar-3',
		'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'twentytwelve' ),
		'before_widget' => '<div class="templatemo_content_left_section">',
		'after_widget' => '</div>',
		'before_title' => '<h1 class="widget-title">',
		'after_title' => '</h1>',
	) );

	register_sidebar( array(
		'name' => __( 'Footer Section Bar', 'twentytwelve' ),
		'id' => 'footer-sidebar',
		'description' => __( 'Appears on the footer of the theme', 'twentytwelve' ),
		'before_widget' => '<div class="templatemo_content_bottom_section">',
		'after_widget' => '</div>',
		'before_title' => '<h1 class="widget-title">',
		'after_title' => '</h1>',
	) );
}
add_action( 'widgets_init', 'twentytwelve_widgets_init' );

if( !function_exists( 'pub-assistant' ) )
{                
	$settings = get_option( 'pub-assistant' );
	if($settings)
	{	
		$vendor=array();
        if(isset($settings['vendors'][0]['media']))
        {
            foreach($settings['vendors'][0]['media'] as $value )
            {
                $vendor[] = $value;
            }
        }
        $settings = get_option( 'pub-assistant' );
        
        global $allvendors;
        
        foreach ($settings['vendors']  as $v){
            if (in_array('e-book', $v['media'] )) $allvendors['e-book'][$v['slug']] = $v['name'];
            if (in_array('paperback', $v['media'])) $allvendors['paperback'][$v['slug']] = $v['name'];
            if (in_array('hardcover', $v['media'])) $allvendors['hardcover'][$v['slug']] = $v['name'];
            if (in_array('audiobook', $v['media'])) $allvendors['audiobook'][$v['slug']] = $v['name'];
        }
        
        $preview=array();
		if(isset($settings['previews'][0]['media']))
		{
			foreach($settings['previews'][0]['media'] as $value )
			{
				$preview[] = $value;
			}
		}
		$settings = get_option( 'pub-assistant' );
		
		global $allpreviews;

        if (!array_key_exists('previews', $settings)) {
            $settings['previews'] = array(
                                        array (
                                            'name' => 'Preview',
                                            'slug' => 'preview',
                                            'media' => array (
                                                'e-book',
                                                'paperback',
                                                'hardcover'
                                            ),
                                        ),
                                        array (
                                            'name' => 'Preview',
                                            'slug' => 'prelisten',
                                            'media' => array (
                                                'audiobook'
                                            ),
                                        ),
                                        
                                    );
            update_option('pub-assistant', $settings);
        }
		
	}
	
	function add_ebook_metaboxes() {
			add_meta_box('wpt_ebooks_uploads', 'Display  eBook on Website', 'wpt_ebooks_uploads', 'pba_book', 'side', 'default');
	}

	add_action( 'add_meta_boxes', 'add_ebook_metaboxes' );

	function wpt_ebooks_uploads($post_id)
	{
		global $post;
		global $allvendors, $allpreviews;
		
		$ebook_check = get_post_meta($post->ID, 'ebook_publish', true);
		if($ebook_check)
		{
			if($ebook_check == 'on')
				$str1 ='checked="checked"';
			if($ebook_check == 'off')
				$str1='';	
		}
		else if($post->post_type == 'pba_book' && $post->post_status == 'auto-draft')
		{
			$str1='';
		}
        
        $base_check = '';
        $settings = get_option( 'pub-assistant' );
        $settings[ 'look-ups' ][ 'series_names'];
        $series_key = get_post_meta($post->ID, '_pba_series_name', true);
//        $series_lang = get_post_meta($post->ID, '_pba_language', true);
                                        
        if ($series_key && $settings[ 'look-ups' ][ 'series_names']['base_ebook_publish'][(int)$series_key] == '1') {
            $base_check = 'checked="checked"';                                                                                                 
        }
	?>
		<div style="padding:10px 0;">
				<input type="checkbox" name="base_ebook_publish" id="base_ebook_publish" value="on" <?php echo $base_check;?>/>&nbsp;&nbsp;Base Display Order on Publish Date<br/>
				<input type="checkbox" name="ebook_publish" id="ebook_publish" value="on" <?php echo $str1;?>/>&nbsp;&nbsp;Display on Website
				<input type="submit" name="publish_ebook" value="Update" id="publish_ebook" class="button button-primary button-large" style="float: right;margin-top: 1px;"/>				
		</div>
		<?php
        /// display vendors for check
        display_vendor_metabox ('e-book', true);    
        display_vendor_metabox ('paperback');    
        display_vendor_metabox ('hardcover');    
        
	}
	
	add_action( 'edit_post', 'save_display_meta');  	
	function save_display_meta($post_id ){
		save_display_allvendors ($post_id, 'e-book');
		save_display_allvendors ($post_id, 'paperback');
		save_display_allvendors ($post_id, 'hardcover');
		save_display_allvendors ($post_id, 'audiobook');
		
	}
	function save_display_allvendors ($post_id, $book_type){
		
		if (array_key_exists($book_type.'_publishV', $_POST) ){
			$metaval = 'pba_'. $book_type .'_metavendors_display';
			update_post_meta($post_id, $metaval, $_POST[$book_type.'_publishV']);			
		}
	}
	function display_vendor_metabox ($book_type, $checkedBydefault = false){
		global $post, $allvendors;
		$metaval = 'pba_'. $book_type .'_metavendors_display';
		$checkedVal = get_post_meta($post->ID, $metaval, true);	
		
		$vlist = $allvendors[$book_type];
		
		$heading = "Ebook Vendors";
		if ($book_type == 'e-book') $heading = "Ebook Vendors";
		if ($book_type == 'paperback') $heading = "Paperback Vendors";
		if ($book_type == 'hardcover') $heading = "Hardcover Vendors";
		if ($book_type == 'audiobook') $heading = "Audiobook Vendors";
		
		echo '<div style="padding:10px 0;">
					<b>'.$heading.'</b><br/>
		';
		foreach ($vlist as $slug=>$v){
		
			if(is_array($checkedVal)){
				if (array_key_exists($slug, $checkedVal))
					$checkstr ='checked="checked"';
				else
					$checkstr='';	
			} elseif($checkedBydefault)			
				$checkstr ='checked="checked"';
			else
				$checkstr='';	
			
			echo '<input 
					type="checkbox" 
					name="'.$book_type.'_publishV['.$slug.']" 
					id="'.$book_type.'_publish_'.$slug.'" 
					value="on" 
					'.$checkstr.'
					/>&nbsp;&nbsp;'.$v.'<br />';
		}
		echo '</div >';
	}

	function add_ebook_promotional_metaboxes() {
			add_meta_box('wpt_ebooks_promotional', 'eBook Promotional Links', 'wpt_ebooks_promotional', 'pba_book', 'side', 'default');
	}

	add_action( 'add_meta_boxes', 'add_ebook_promotional_metaboxes' );

	function wpt_ebooks_promotional($post_id)
	{
		global $post;
		$ebook_check = get_post_meta($post->ID, 'ebook_promotional', true);	
		$ebook_display_check = get_post_meta($post->ID, 'ebook_promotional_display', true);	

		if($ebook_display_check == 'on')
			$str_pro ='checked="checked"';
		if($ebook_display_check == 'off')
			$str_pro='';	

		if($ebook_check)
			$val = count($ebook_check['promotional_ebook']);
		else
			$val =0;		
		?>
		<div style="padding:10px 0;">
				<div id="promotional" style="padding-bottom:0px;">
					<?php if($ebook_check) { ?>
					<?php for($j=0;$j<count($ebook_check['promotional_ebook']); $j++){	?>
						
						<?php if($j > 0)
						{
							$ptext = '<div style="text-align:right;margin: 0 5px 0 0;float:right"><a href="javascript:void(0);" onclick="removeDiv(\'promotional_child'.$j.'\');"><img src="'.get_bloginfo('template_url').'/images/Remove.png" alt="remove" title="remove" border="0" style="vertical-align:middle;margin-top: 16px;"/></a></div>';
						}
						else
						{
							$ptext='';
						}
					
						?>
						<div id="promotional_child<?php echo $j;?>" style="padding-bottom:5px;">
							<div style="float:left;width:230px;">
								<input type="text" name="ebook_promotional_title[]" id="ebook_promotional_title[]" value="<?php echo $ebook_check['promotional_ebook'][$j]['title'];?>" style="width:220px"/>
								<input type="text" name="ebook_promotional_link[]" id="ebook_promotional_link[]" value="<?php echo $ebook_check['promotional_ebook'][$j]['link'];?>" style="width:220px"/>
							</div>
							<?php echo $ptext;?>
							<div style="clear:both;"></div>
						</div>
							
					 <?php } ?>
					<?php } else { ?>
					<div id="promotional_child0" style="padding-bottom:5px;">
						<div style="float:left;width:230px">
							<input type="text" name="ebook_promotional_title[]" id="ebook_promotional_title[]" value="enter promotional text" onblur="if(this.value == '') { this.value='enter promotional text'}" onfocus="if (this.value == 'enter promotional text') {this.value=''}" style="width:220px"/>
							<input type="text" name="ebook_promotional_link[]" id="ebook_promotional_link[]" value="enter promotional link" onblur="if(this.value == '') { this.value='enter promotional link'}" onfocus="if (this.value == 'enter promotional link') {this.value=''}" style="width:220px"/>
						</div>
					</div>
					<div style="clear:both;"></div>
					<?php } ?>
				</div>
				<div style="padding-bottom:5px;text-align: right;"><a href="javascript:void(0);" onClick="addmorediv()">Add More</a></div>
				<div style="clear:both;"></div>
				<div>
					<div style="width:100px;float:left;">
						<input type="checkbox" name="ebook_promotional_display" id="ebook_promotional_display" value="on" <?php echo $str_pro;?>/>&nbsp;&nbsp;Display
					</div>
					<div style="float:right;">
						<input type="submit" name="publish_ebook_promotional" value="Update" id="publish_ebook_promotional" class="button button-primary button-large" style="margin-top: -5px;"/>	
						<input type="hidden" name="promotional_count" id="promotional_count" value="<?php echo $val;?>">
					</div>
					<div style="clear:both;"></div>
				</div>
		</div>
		<script>
		 function addmorediv()
		 {
			var imgsrc = "<?php echo get_bloginfo('template_url');?>/images/Remove.png";
			
			var cnt = jQuery('#promotional_count').val();
			cnt = parseInt(cnt)+1;
			jQuery('#promotional').append('<div id="promotional_child'+cnt+'" style="padding-bottom:10px;"><div style="float:left;width:230px;"><input type="text" name="ebook_promotional_title[]" id="ebook_promotional_title[]" value="enter promotional text" onblur="if(this.value == \'\') { this.value=\'enter promotional text\'}" onfocus="if (this.value == \'enter promotional text\') {this.value=\'\'}" style="width:220px"/><input type="text" name="ebook_promotional_link[]" id="ebook_promotional_link[]" value="enter promotional link" onblur="if(this.value == \'\') { this.value=\'enter promotional link\'}" onfocus="if (this.value == \'enter promotional link\') {this.value=\'\'}" style="width:220px"/></div><div style="text-align:right;margin: 0 5px 0 0;float:right"><a href="javascript:void(0);" onclick="removeDiv(\'promotional_child'+cnt+'\');"><img src="'+imgsrc+'" alt="remove" title="remove" border="0" style="vertical-align:middle;margin-top: 16px;"/></a></div><div style="clear:both;"></div></div>');
			jQuery('#promotional_count').val(cnt);
		 }
		 function removeDiv(divId)
		 {
			jQuery('#'+divId).remove();
		 }
	   	</script>
	<?php
	}

	if(is_array($vendor) && in_array('audiobook',$vendor))
	{
		function add_books_metaboxes() {
			add_meta_box('wpt_books_location', 'Display Audiobook on Website', 'wpt_books_location', 'pba_book', 'side', 'default');
		}

		add_action( 'add_meta_boxes', 'add_books_metaboxes' );

		function wpt_books_location($post_id)
		{
			global $post, $allvendors ;
			$check_publish = get_post_meta($post->ID, 'book_publish', true);

			if($check_publish)
			{
				if($check_publish == 'on')
					$str ='checked="checked"';
				if($check_publish == 'off')
					$str='';	
			}
			else if($post->post_type == 'pba_book' && $post->post_status == 'auto-draft')
			{
				$str='';
			}                                                                                   
            
			$base_check = '';
            $settings = get_option( 'pub-assistant' );
            $settings[ 'look-ups' ][ 'series_names'];
            $series_key = get_post_meta($post->ID, '_pba_series_name', true);
//            $series_lang = get_post_meta($post->ID, '_pba_language', true);
            
            if ($series_key && $settings[ 'look-ups' ][ 'series_names']['base_audiobook_publish'][(int)$series_key] == '1') {
                $base_check = 'checked="checked"';                                                                   
            }
			?>
			<div style="padding:10px 0;">
				<input type="checkbox" name="base_audiobook_publish" id="base_audiobook_publish" value="on" <?php echo $base_check;?>/>&nbsp;&nbsp;Base Display Order on Audiobook Publish Date<br/>
				<input type="checkbox" name="book_publish" id="book_publish" value="on" <?php echo $str;?>/>&nbsp;&nbsp;Display on Website
				<input type="submit" name="publish_book" value="Update" id="publish_book" class="button button-primary button-large" style="float: right;margin-top: 1px;"/>
					
			</div>
			<?php
			display_vendor_metabox ('audiobook', true);	
		}

		function add_audiobook_promotional_metaboxes() {
			add_meta_box('wpt_audiobookbooks_promotional', 'Audiobook Promotional Links', 'wpt_audiobookbooks_promotional', 'pba_book', 'side', 'default');
		}

		add_action( 'add_meta_boxes', 'add_audiobook_promotional_metaboxes' );

		function wpt_audiobookbooks_promotional($post_id)
		{
			global $post;
			$audiobook_recordset = get_post_meta($post->ID, 'audiobook_promotional_link', true);	
			$audiobook_display_check = get_post_meta($post->ID, 'display_audiobook_promotional', true);	

			if($audiobook_display_check == 'on')
				$check_audiobook ='checked="checked"';
			if($audiobook_display_check == 'off')
				$check_audiobook='';	

			if($audiobook_recordset)
				$val = count($audiobook_recordset['promotional_audiobook']);
			else
				$val =0;
		?>
		<div style="padding:10px 0;">
			<div id="promotional_audiobook" style="padding-bottom:0px;">
			<?php if($audiobook_recordset) { ?>
			<?php for($k=0;$k<count($audiobook_recordset['promotional_audiobook']); $k++){	?>
			<?php if($k > 0)
			{
				$atext = '<div style="text-align:right;margin: 0 5px 0 0;float:right"><a href="javascript:void(0);" onclick="remove_audiobook(\'promotional_child'.$k.'\');"><img src="'.get_bloginfo('template_url').'/images/Remove.png" alt="remove" title="remove" border="0" style="vertical-align:middle;margin-top: 16px;"/></a></div>';
			}
			else
			{
				$atext='';
			}
		?>
			<div id="promotional_child<?php echo $k;?>" style="padding-bottom:5px;">
				<div style="float:left;width:230px;">
					<input type="text" name="audiobook_promotional_title[]" id="audiobook_promotional_title[]" value="<?php echo $audiobook_recordset['promotional_audiobook'][$k]['title'];?>" style="width:220px"/>
					<input type="text" name="audiobook_promotional_link[]" id="audiobook_promotional_link[]" value="<?php echo $audiobook_recordset['promotional_audiobook'][$k]['link'];?>" style="width:220px"/>
				</div>
				<?php echo $atext;?>
				<div style="clear:both;"></div>
			</div>
		<?php } ?>
		<?php } else { ?>
			<div id="promotional_child0" style="padding-bottom:5px;">
				<div style="float:left;width:230px">
					<input type="text" name="audiobook_promotional_title[]" id="audiobook_promotional_title[]" value="enter promotional text" onblur="if(this.value == '') { this.value='enter promotional text'}" onfocus="if (this.value == 'enter promotional text') {this.value=''}" style="width:220px"/>
					<input type="text" name="audiobook_promotional_link[]" id="audiobook_promotional_link[]" value="enter promotional link" onblur="if(this.value == '') { this.value='enter promotional link'}" onfocus="if (this.value == 'enter promotional link') {this.value=''}" style="width:220px"/>
				</div>
			</div>
			<div style="clear:both;"></div>
		<?php } ?>
		</div>
		<div style="padding-bottom:5px;text-align: right;"><a href="javascript:void(0);" onClick="addmore_audiobook()">Add More</a></div>
		<div style="clear:both;"></div>
		<div>
			<div style="width:100px;float:left;">
				<input type="checkbox" name="audiobook_promotional_display" id="audiobook_promotional_display" value="on" <?php echo $check_audiobook;?>/>&nbsp;&nbsp;Display
			</div>
			<div style="float:right;">
				<input type="submit" name="publish_audiobook_promotional" value="Update" id="publish_audiobook_promotional" class="button button-primary button-large" style="margin-top: -5px;"/>	
				<input type="hidden" name="audiobook_promotional_count" id="audiobook_promotional_count" value="<?php echo $val;?>">
			</div>
			<div style="clear:both;"></div>
		</div>
	</div>
	<script>
	function addmore_audiobook()
	{
		var imgsrc = "<?php echo get_bloginfo('template_url');?>/images/Remove.png";
			
		var cnt = jQuery('#audiobook_promotional_count').val();
		cnt = parseInt(cnt)+1;
		jQuery('#promotional_audiobook').append('<div id="promotional_child'+cnt+'" style="padding-bottom:10px;"><div style="float:left;width:230px;"><input type="text" name="audiobook_promotional_title[]" id="audiobook_promotional_title[]" value="enter promotional text" onblur="if(this.value == \'\') { this.value=\'enter promotional text\'}" onfocus="if (this.value == \'enter promotional text\') {this.value=\'\'}" style="width:220px"/><input type="text" name="audiobook_promotional_link[]" id="audiobook_promotional_link[]" value="enter promotional link" onblur="if(this.value == \'\') { this.value=\'enter promotional link\'}" onfocus="if (this.value == \'enter promotional link\') {this.value=\'\'}" style="width:220px"/></div><div style="text-align:right;margin: 0 5px 0 0;float:right"><a href="javascript:void(0);" onclick="remove_audiobook(\'promotional_child'+cnt+'\');"><img src="'+imgsrc+'" alt="remove" title="remove" border="0" style="vertical-align:middle;margin-top: 16px;"/></a></div><div style="clear:both;"></div></div>');
		jQuery('#audiobook').val(cnt);
	 }
	 function remove_audiobook(divId)
	 {
		jQuery('#'+divId).remove();
	 }
	</script>
	<?php
	}
	function add_upload_metaboxes() {
		add_meta_box('wpt_books_uploads', 'Upload Audiobook Sample', 'wpt_books_uploads', 'pba_book', 'side', 'default');
	}
	add_action( 'add_meta_boxes', 'add_upload_metaboxes' );

	function wpt_books_uploads($post_id)
	{
		global $post;
		if(isset($_REQUEST['audio']) && $_REQUEST['audio'] == 'delete')
		{                     
			$audio_sample_file = get_post_meta($post->ID, 'audiobook_sample', true);

			if ($audio_sample_file)
				$delete_file = unlink(dirname(dirname(dirname(__FILE__))).'/uploads/'.$audio_sample_file);

//			if($delete_file)
//			{
			update_post_meta($post->ID, 'audiobook_sample', '');
			update_post_meta($post->ID, 'audio_sample_publish', '');
//			}
		}
		$audio_sample = get_post_meta($post->ID, 'audiobook_sample', true);
		$check_audio_sample_publish = get_post_meta($post->ID, 'audio_sample_publish', true);

		if($check_audio_sample_publish)
		{
			if($check_audio_sample_publish == 'on')
				$str2 ='checked="checked"';
			if($check_publish == 'off')
				$str2='';	
		}
		else
		{
			$str2 ='';
		}	
	?>
	<script>
		jQuery( "form#post" ).attr( "enctype", "multipart/form-data" );
	</script>
	<div style="padding:10px 0;">
		<input type="file" name="audio_sample_file" id="audio_sample_file" value ="" style="width:168px;"/><br/>
		<input type="submit" name="upload_book" value="Upload" id="upload_book" class="button button-primary button-large" style="float: right;margin-top: 1px;" />
		<?php
			if($audio_sample)
				echo '<div style="margin-top:10px;"><a href="'.home_url('/audiosample/').$audio_sample.'" target="_blank">'.$audio_sample.'</a>&nbsp;&nbsp;<a href="'.home_url('wp-admin/post.php?post='.$post->ID.'&action=edit&audio=delete').'"><img src="'.get_bloginfo('template_url').'/images/Remove.png" alt="remove" title="remove" border="0" style="vertical-align:middle;"/></a></div>';
		?><br/>
		<?php if($audio_sample) { ?>
		<input type="checkbox" name="audio_sample_publish" id="audio_sample_publish" value="on" <?php echo $str2;?>/>&nbsp;&nbsp;Display Preview Button&nbsp;&nbsp;<input type="submit" name="preview_upload" value="Update" id="preview_upload" class="button button-primary button-large" style="float: right;margin-top: -5px;"/>
		<?php } ?>
	</div>
	<?php }
	add_action( 'edit_post', 'content_book_save' );  
	function content_book_save( $post_id )  
	{  
		global $wpdb;
		@ini_set('post_max_size', '64M');
		@ini_set('upload_max_filesize', '64M');

		// Bail if we're doing an auto save  
		if ( ! wp_is_post_revision( $post_id ) )
		{
			if(isset($_POST['publish_book']) && $_POST['publish_book'] == 'Update')
			{
				$table_name = $wpdb->prefix . "posts";
				if(isset($_POST['book_publish']))
				{
					$publish = $_POST['book_publish'];	
					update_post_meta($post_id, 'book_publish', $publish);
					$audiobook_publish_date = get_post_meta($post->ID, 'audiobook_publish_date', true);
					if(!$audiobook_publish_date)
						update_post_meta($post_id, 'audiobook_publish_date', date('Y-m-d'));
				}
				else
				{
					$publish = 'off';
					update_post_meta($post_id, 'book_publish', $publish);
                    delete_post_meta($post_id, 'audiobook_publish_date');
				}
				if(isset($_POST['base_audiobook_publish']))
				{
					$ebook_base_publish = $_POST['base_audiobook_publish'];
					update_post_meta($post_id, 'base_audiobook_publish', $ebook_base_publish);
				}
				else
				{
					$ebook_base_publish = 'off';
					update_post_meta($post_id, 'base_audiobook_publish', $ebook_base_publish);
				}
				
			}
			if(isset($_POST['upload_book']) && $_POST['upload_book'] == 'Upload')
			{                           
                $image_path = wp_upload_dir(); 
                if(!file_exists($image_path['basedir'].'/audiosample')){
                    $old = umask(0);
				    mkdir($image_path['basedir'].'/audiosample', 0777, true);
                    umask($old);
				}
				if(!empty($_FILES['audio_sample_file']['name']))
				{
					move_uploaded_file($_FILES['audio_sample_file']['tmp_name'],$image_path['basedir'].'/audiosample/'.$_FILES['audio_sample_file']['name']);
					update_post_meta($post_id, 'audiobook_sample', 'audiosample/'.$_FILES['audio_sample_file']['name']);
					update_post_meta($post_id, 'audio_sample_publish', 'on');
				}					
			}
			if(isset($_POST['preview_upload']) && $_POST['preview_upload']=='Update')
			{
				if(isset($_POST['audio_sample_publish']))
				{
					$audio_publish = $_POST['audio_sample_publish'];	
					update_post_meta($post_id, 'audio_sample_publish', $audio_publish);
				}
				else
				{
					$audio_publish = 'off';	
					update_post_meta($post_id, 'audio_sample_publish', $audio_publish);
				}
			}

			if(isset($_POST['publish_audiobook_promotional']) && $_POST['publish_audiobook_promotional'] == 'Update')
			{
				$audiobook_promotional = array();
				if(isset($_POST['audiobook_promotional_title']) && isset($_POST['audiobook_promotional_link']))
				{
					for($m=0; $m < count($_POST['audiobook_promotional_title']); $m++)
					{
						if($_POST['audiobook_promotional_title'][$m] !='enter promotional text')
							$title =$_POST['audiobook_promotional_title'][$m];
						if($_POST['audiobook_promotional_link'][$m] !='enter promotional link')
							$link = $_POST['audiobook_promotional_link'][$m];

							$audiobook_promotional['promotional_audiobook'][] = array(
								'title'=>$title,
								'link'=>$link
							);
						
					}
					if($audiobook_promotional)
					{
						update_post_meta($post_id, 'audiobook_promotional_link', $audiobook_promotional);
					}
					if(isset($_POST['audiobook_promotional_display']))
					{
						$audiobook_promotional_display = $_POST['audiobook_promotional_display'];
						update_post_meta($post_id, 'display_audiobook_promotional', $audiobook_promotional_display);
					} else {
                        update_post_meta($post_id, 'display_audiobook_promotional', 'off');
                    }					
				}				
			}
		}
	  }	
	}
    
	add_action( 'edit_post', 'content_ebook_save' );  
	function content_ebook_save( $post_id )  
	{
		global $wpdb;
		// Bail if we're doing an auto save  
		if ( ! wp_is_post_revision( $post_id ) )
		{   
            // insert luo's code
            if($_POST['publish_ebook'] == 'Update') {
                if (get_post_time('U', true, $post_id)> get_option(PBA_THEME_SETUP_DATE)) {
                    if ($_POST['ebook_publish'] == 'on') {
                        if (!get_post_meta($post_id, 'Date1')) {
                            add_post_meta($post_id, 'Date1', date_timestamp_get(new DateTime('now')));   
                        }    
                    } else {
//                        delete_post_meta($post_id, 'Date1');
                    }
                }
                $settings = get_option( 'pub-assistant' );
//                print_r($settings[ 'look-ups' ][ 'series_names']);
                $series_key = get_post_meta($post_id, '_pba_series_name', true);
//                $series_lang = get_post_meta($post_id, '_pba_language', true);
                if ($series_key) {
                    if ($_POST['base_ebook_publish']) {
                        $settings[ 'look-ups' ][ 'series_names']['base_ebook_publish'][(int)$series_key] = "1"; 
                    } else {
                        $settings[ 'look-ups' ][ 'series_names']['base_ebook_publish'][(int)$series_key] = "0"; 
                    }
                    
                    update_option('pub-assistant', $settings);              
                }
            }
            
            if($_POST['publish_book'] == 'Update') {
//                if (get_post_time('U', true, $post_id)> get_option(PBA_THEME_SETUP_DATE)) {
                    if ($_POST['book_publish'] == 'on') {
                        if (!get_post_meta($post_id, 'Date2')) {
                            add_post_meta($post_id, 'Date2', date_timestamp_get(new DateTime('now')));   
                        }    
                    } else {
//                        delete_post_meta($post_id, 'Date2');
                    }
//                }
                $settings = get_option( 'pub-assistant' );
//                print_r($settings[ 'look-ups' ][ 'series_names']);
                $series_key = get_post_meta($post_id, '_pba_series_name', true);
//                $series_lang = get_post_meta($post_id, '_pba_language', true);
                if ($series_key) {        
                    if ($_POST['base_audiobook_publish']) {
                        $settings[ 'look-ups' ][ 'series_names']['base_audiobook_publish'][(int)$series_key] = "1"; 
                    } else {
                        $settings[ 'look-ups' ][ 'series_names']['base_audiobook_publish'][(int)$series_key] = "0"; 
                    }
                    
                    update_option('pub-assistant', $settings);              
                }
            }
            
            // end luo            

			if(isset($_POST['publish_ebook']) && $_POST['publish_ebook'] == 'Update')
			{
				$table_name = $wpdb->prefix . "posts";
				if(isset($_POST['ebook_publish']))
				{
					$publish = $_POST['ebook_publish'];	
					update_post_meta($post_id, 'ebook_publish', $publish);

					$ebook_publish_date = get_post_meta($post->ID, 'ebook_publish_date', true);
					if(!$ebook_publish_date)
						update_post_meta($post_id, 'ebook_publish_date', date('Y-m-d'));
					
				}
				else
				{
					$publish = 'off';
					update_post_meta($post_id, 'ebook_publish', $publish);
				}
				if(isset($_POST['base_ebook_publish']))
				{
					$ebook_base_publish = $_POST['base_ebook_publish'];
					update_post_meta($post_id, 'base_ebook_publish', $ebook_base_publish);
				}
				else
				{
					$ebook_base_publish = 'off';
					update_post_meta($post_id, 'base_ebook_publish', $ebook_base_publish);
				}
				
			}
			if(isset($_POST['publish_ebook_promotional']) && $_POST['publish_ebook_promotional'] == 'Update')
			{
				$ebook_promotional = array();
				if(isset($_POST['ebook_promotional_title']) && isset($_POST['ebook_promotional_link']))
				{
					for($i=0; $i < count($_POST['ebook_promotional_title']); $i++)
					{
						if($_POST['ebook_promotional_title'][$i] !='enter promotional text')
							$title =$_POST['ebook_promotional_title'][$i];
						if($_POST['ebook_promotional_link'][$i] !='enter promotional link')
							$link = $_POST['ebook_promotional_link'][$i];

							$ebook_promotional['promotional_ebook'][] = array(
								'title'		  =>$title,
								'link'	  =>$link
							);
						
					}
					
				}
				if($ebook_promotional)
				{
					update_post_meta($post_id, 'ebook_promotional', $ebook_promotional);
				}
				if(isset($_POST['ebook_promotional_display']))
				{
					$promotional_display = $_POST['ebook_promotional_display'];
					update_post_meta($post_id, 'ebook_promotional_display', $promotional_display);
				}
			}
		}   
	}

	function tr_insert_post($post_id)
	{
		global $wpdb;
		if ( ! wp_is_post_revision( $post_id ) )
		{
			$table_name = $wpdb->prefix . "posts";
			if(isset($_POST['original_post_status']) && $_POST['original_post_status']=='auto-draft')
			{
				if(isset($_POST['ebook_publish']))
				{
					/*$sql ="UPDATE $table_name SET post_status='publish' WHERE ID='".$post_id."'";
					$wpdb->query($sql);*/

					$publish = $_POST['ebook_publish'];	
					update_post_meta($post_id, 'ebook_publish', $publish);
				}
				else
				{
					$publish = 'off';	
					update_post_meta($post_id, 'ebook_publish', $publish);
				}
				if(isset($_POST['book_publish']))
				{						
					/*$sql ="UPDATE $table_name SET post_status='publish' WHERE ID='".$post_id."'";
					$wpdb->query($sql);*/

					$publish = $_POST['book_publish'];
					update_post_meta($post_id, 'book_publish', $publish);
				}
				else
				{
					/*$sql ="UPDATE $table_name SET post_status='private' WHERE ID='".$post_id."'";
					$wpdb->query($sql);*/

					$publish = 'off';	
					update_post_meta($post_id, 'book_publish', $publish);
				}
							
			}			
		}
	}
	//add_action('wp_insert_post', '      ',1,1); 	
}

function update_custom_book_publish_status()
{
		global $wpdb;
		$post_table = $wpdb->prefix . "posts";
		$postmeta_table = $wpdb->prefix . "postmeta";

		$sql = 'SELECT p.ID,mt.meta_value FROM '.$post_table.' AS p INNER JOIN '.$postmeta_table.' AS mt ON ( p.ID = mt.post_id ) WHERE p.post_type = "pba_book" AND mt.meta_key = "_pba_publish_date" AND p.post_status = "publish" GROUP BY p.ID';

		$recordSet = $wpdb->get_results($sql,ARRAY_A);

		if(is_array($recordSet))
		{
			foreach($recordSet as $key => $value)
			{
				$audiobook_publish = get_post_meta($value['ID'], 'book_publish', true);	
                if (!$audiobook_publish)
				    update_post_meta($value['ID'], 'book_publish', 'off');

				$ebook_publish = get_post_meta($value['ID'], 'ebook_publish', true);
                if (!$ebook_publish)
				    update_post_meta($value['ID'], 'ebook_publish', 'on');

				$ebook_publish_date = get_post_meta($value['ID'], 'ebook_publish_date', true);
                if (!$ebook_publish_date)
				    update_post_meta($value['ID'], 'ebook_publish_date', $value['meta_value']);

				$audiobook_publish_date = get_post_meta($value['ID'], 'audiobook_publish_date', true);
                if (!$audiobook_publish_date)
				    update_post_meta($value['ID'], 'audiobook_publish_date', $value['meta_value']);
			}
		}
}

function get_book_date1( $post_id, $is_ebook = true ) {
    
    $theme_install_date = get_option('PBA_THEME_SETUP_DATE');
    $insert_time = get_post_time('U', true, $post_id);
         
    if ($is_ebook) {            
        if ( $insert_time< $theme_install_date) {
            return $insert_time;
        } else {                                       
            $publish_date = get_post_meta($post_id, 'Date1', true);
            if ($publish_date) {
                return $publish_date;
            } else {       
                return 0;
            }    
        }           
    } else {
        $publish_date = get_post_meta($post_id, 'Date2', true);
        if ($publish_date) {
            return $publish_date;
        } else {       
            return $insert_time;
        }
    }                             
}
    
function get_book_order_publish_date( $series_key, $genre_slug, $series_lang = 'en', $is_ebook = true ) {
    global $wpdb;                                                              
    
    $settings = get_option( 'pub-assistant' );
//    $settings[ 'look-ups' ][ 'series_names'];
   
    $query = "SELECT * FROM {$wpdb->postmeta} WHERE meta_key = '_pba_series_name' AND meta_value = '$series_key'";
    $q_results = $wpdb->get_results($query);
    $q_result = array();
    
    foreach($q_results as $result) {
        if (get_post_meta( $result->post_id, '_pba_language', true) == $series_lang && (int)get_post_meta( $result->post_id, '_pba_genre', true) == $genre_slug) {
            $q_result[] = $result;
//            echo get_post_meta( $result->post_id, '_pba_language', true);
        }
    }
    
    $max = 0;                                                                                               
    
    if ($is_ebook) {
        $check_item = $settings[ 'look-ups' ][ 'series_names']['base_ebook_publish'][(int)$series_key];
    } else {
        $check_item = $settings[ 'look-ups' ][ 'series_names']['base_audiobook_publish'][(int)$series_key];
    }

    if ($series_key && ($check_item == '0' || !$check_item)) {
        foreach ( $q_result as $result) {
             $r_post_id = $result->post_id;    
             $r_date1 = get_book_date1($r_post_id, $is_ebook);
             if ($r_date1 > $max) $max = $r_date1;
         }
         
         return $max;
    } else {  
                                                                                                  
        foreach ( $q_result as $result) {
             $r_post_id = $result->post_id;
             
             $item_name = '_pba_publish_date';
             if (!$is_ebook) $item_name = '_pba_audiobook_publish_date';
             $r_date1 = get_post_meta($r_post_id, $item_name, true);
             if(!$r_date1) continue;
             $date = new DateTime($r_date1);
             $r_date1 = $date->getTimestamp();
             if ($r_date1 > $max) $max = $r_date1;
         }
         
         return $max;
    }    
}
        
add_action('after_switch_theme', 'update_custom_book_publish_status');

include_once( get_template_directory() . '/inc/class-pba_book.php' );
include_once( get_template_directory() . '/inc/pba_init.php' );
include_once( get_template_directory() . '/inc/functions.php' );                        

include_once( get_template_directory() . '/additional/custom-function.php' );
include_once( get_template_directory() . '/additional/menu/website-theme-set-up.inc.php' );
include_once( get_template_directory() . '/additional/menu/languagelist.php' );
include_once( get_template_directory() . '/additional/menu/vendor-list.php' );
include_once( get_template_directory() . '/additional/menu/latest-releases.php' );
include_once( get_template_directory() . '/additional/menu/special-offers.php' );
include_once( get_template_directory() . '/additional/menu/book-previews.php' );
include_once( get_template_directory() . '/additional/menu/google-analytics.php' );
include_once( get_template_directory() . '/additional/menu/author-list.php' );
include_once( get_template_directory() . '/additional/menu/website-theme.php' );
