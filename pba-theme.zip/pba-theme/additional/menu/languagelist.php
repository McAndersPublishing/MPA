<?php
if( !function_exists( 'website_theme_register_languages_menu_new' ) ) {
	add_action( 'admin_menu', 'website_theme_register_languages_menu_new');
	/**
	 * Registers the menu page.
	 */
	function website_theme_register_languages_menu_new() {
		add_submenu_page( null, 'Categories', 'Categories', 'manage_options', 'languagelist','func_display_added_language_list');
	}
}


if( !function_exists( 'func_display_added_language_list' ) ) {
	function func_display_added_language_list()
	{
		global $wpdb;
		if(isset($_POST['savelanguage']) && !empty($_POST['savelanguage']))
		{
			$set_message = update_language();
		}
		
		// save audiobook setting for a particular author
		if(isset($_POST['saveAudio']) && !empty($_POST['saveAudio']))
		{
			$audiobbok_set_message = save_audiobook_setting();
		}
		
		// defining table names
		$postmeta_table = $wpdb->prefix . "postmeta";
		$author_audiobook_setting_table = $wpdb->prefix . "author_audiobook_seeting";
		
		/// Display Page Heading
		$selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
		$selectedAuthor = displayHeading($selectedwebsite, 'Category / Language Setting'); 
		
		// fetching website related language information
		$website_languages = get_post_meta($selectedwebsite, 'website_languages', true); 
		
		/// globally selected languages
		$settings = get_option( 'pub-assistant' );
		$languages = $settings[ 'languages' ];  
		//print_r($settings);exit;
		// find author's book specific language
		if (is_int($selectedAuthor)){
			$strQry =  "`meta_value` =  ".$selectedAuthor;
		}else{
			if (is_array ($selectedAuthor)){
				foreach ($selectedAuthor as $aid){
					$strQryArr[] =  "`meta_value` =  ".$aid;
				}
				$strQry = implode (' or ', $strQryArr);
			}
		}
		$quyFindBooks = "select distinct (post_id) 
								from $postmeta_table 
								where `meta_key` 
								IN( '_pba_author_1','_pba_author_2')  /* for primary and secondary Author*/
								AND ($strQry) 
								";
		$book_results = $wpdb->get_col($quyFindBooks);
											
		$book_id_string = array();
		$BookIds = array();
		
		if($book_results) 
			foreach ($book_results as $bookID) 
				$BookIds[] = '`post_id` = '.$bookID;
		
		$book_id_string = implode (' Or ', $BookIds);
		
		$authLangQuery = "SELECT distinct (meta_value )
										FROM $postmeta_table 
										WHERE `meta_key` = '_pba_language' 
										AND ( $book_id_string )";
										
		$auth_lang_array = $wpdb->get_col($authLangQuery);
		
		/// fetching default text for the languages
		$main_language_array = array();
		$auth_lang = array();
		if (!empty($auth_lang_array)) {
			foreach($auth_lang_array as $key =>$value) {
				$auth_lang['lang_key'] 				= $value;
				$auth_lang['lang_value'] 			= $languages[$value];
				$auth_lang['lang_real_value'] 	= (isset($website_languages[$value])) ? $website_languages[$value]['real_value'] :$languages[$value];
				$auth_lang['display'] 				= (isset($website_languages[$value])) ? $website_languages[$value]['display'] : 1;
				$order[$key] = $auth_lang['order'] 	= (isset($website_languages[$value])) ? $website_languages[$value]['order'] : 999;
				$main_language_array[$key] 			= $auth_lang;
			}
		}				
		if (count($main_language_array) > 1 )
			@array_multisort($order, SORT_ASC, $main_language_array);
		
		$ajaxFileUrl = get_template_directory_uri().'/additional/ajax.php'	;
		$str='';
		$str .='
		<script type="text/javascript">
            var $ = jQuery.noConflict();
			$(document).ready(function(){			
				$("#menu-pages_sort").sortable({
					update: function(event, ui) {
						$.post("'.$ajaxFileUrl.'", { type: "orderPages", pages: $(\'#menu-pages_sort\').sortable(\'serialize\'),website_id:'.$selectedwebsite.' } );
					}
				});
				$("#menu-pages_sort_audio").sortable({
					update: function(event, ui) {
						$.post("'.$ajaxFileUrl.'", { type: "reorderaudiobook", pages: $(\'#menu-pages_sort_audio\').sortable(\'serialize\'),website_id:'.$selectedwebsite.',audiobook:true } );
					}
				});
			});
		</script>';

		if(!empty($main_language_array)) 
		{

			$str .='<div style="color:red;padding:0px 0px 2px 0px;">Drag and drop the categories into the order that you would like them to appear on the website.</div>';
			$str .='<form action="" method="post" id="frmLog" name="frmLog">
					<input type="hidden" name="action" id="action" value="true">
					<input type="hidden" name="lang_array" id="lang_array" value="'.$lang_array.'">
					<input type="hidden" name="author_id" id="author_id" value="'.$selectedAuthor.'">
					<input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">';

			$str .='<table cellspacing="0" cellpadding="5" border="0" width="100%" id="test-list">
					<tbody>';

			
			if(!empty($set_message))
			{
				$str .='<tr align="left">
							<td height="1" style="padding: 8px;color:green" class="successmsg_12" colspan="4" align="center">'.$set_message.'</td>
						</tr>';
			}
		
			$str .='<tr style="background:#D9D9D9;height:30px;">
					<td width="10%" style="font-size:11px;" valign="top"><b>On/Off</b></td>
					<td width="30%" style="font-size:11px;" valign="top"><b>Language</b></td>
					<td width="70%" style="font-size:11px;" valign="top"><b>Display Text</b></td>
				</tr>';
			$str .='<tr><td colspan="3"><ul class="menu_sort1" id="menu-pages_sort">';
		   foreach($main_language_array as $key => $recordSet)
		   {	
				$u++;
				if($recordSet['display']==1) {
					$checked = "checked";
				}
				else {
					$checked = '';
				}
				$str .='<li  id="page_'.$recordSet['lang_key'].'">
								<table cellspacing="0" cellpadding="5" border="0" width="100%">
								<tr class="smallclassnew">
									<td class="smallclassnew" valign="top" width="10%"><input type="checkbox" '.$checked.' name="record_array['.$recordSet['lang_key'].']" value="'.$recordSet['lang_key'].'" ></td>
									<td class="smallclassnew" valign="top" width="30%" style="font-size:11px">'.$recordSet['lang_value'].'</td>
									<td class="smallclassnew" valign="top" width="70%" align="left" style="font-size:11px">
										<input type="hidden" name="lang_value['.$recordSet['lang_key'].']" id="value_'.$recordSet['lang_key'].'" value="'.$recordSet['lang_value'].'">
										<input type="text" name="real_value['.$recordSet['lang_key'].']" id="real_value_'.$recordSet['lang_key'].'" value="'.$recordSet['lang_real_value'].'">
									</td>
								</tr>
							</table>
							</li>';
			} 
				$str .='</ul></td></tr>';
				$str .='<tr class="smallclassnew">
							<td align="left" class="smallclassnew" colspan="4" style="border-top:1px solid #cfcfcf;">
								<input type="submit" name="savelanguage" value="Save" style="margin-bottom:-3px;padding-bottom:0px;" class="button button-primary save"></td>	
						</tr>';
				$str .='<tr align="center">
							<td height="1" style="padding: 8px;" colspan="4"></td>
						</tr>
					</tbody>
				</table>
				</form>';

		}

			$str .='<script>
			function SubmitPage(val)
			{
				window.location.href="admin.php?page=list-search-log&offset="+val;
				return true;
			}
			</script>';
			$langArray = array();
			foreach($main_language_array as $key =>$lang_array){
				if($lang_array['display']){
					$langArray[]="'".$lang_array['lang_key']."'";
				}
			}

			$langString = implode(',',$langArray);
			$vendor_setting = $settings['vendors'];

			foreach($vendor_setting as $key =>$value){
				if($key==0){
					$slug = $value['slug'];
					$query_cond .=" (meta_key = '_pba_link_".$slug."_audiobook' AND meta_value != '')";
				}
				else {
					$slug = $value['slug'];
					$query_cond .=" OR (meta_key = '_pba_link_".$slug."_audiobook' AND meta_value != '')";
				}
			}
			$audiobook_query = "SELECT meta_value
					FROM $postmeta_table 
					WHERE `meta_key` LIKE '%_pba_language%'
					AND post_id
					IN (
						SELECT DISTINCT (post_id)
						FROM $postmeta_table
						WHERE $query_cond".
						//AND post_id IN (
//							SELECT DISTINCT (post_id)
//							FROM $postmeta_table 
//							WHERE (
//								`meta_key` = '_pba_author_1'
//								AND `meta_value` = '$selectedAuthor'
//							)
//							OR (
//								`meta_key` = '_pba_author_2'
//								AND `meta_value` = '$selectedAuthor'
//							)
//						)
					") AND meta_value IN ($langString) GROUP BY meta_value
					";
//            echo $audiobook_query;
			$audiobookRecordSets = $wpdb->get_col($audiobook_query);
			
			
			
			$authorAaudiobookSeetingRecordSets = array();
			$auth_lang = array();
			$website_aud_languages = get_post_meta($selectedAuthor, 'website_aud_languages', true); // fetching Author related language information
			
			if (!empty($audiobookRecordSets)) {
				
				foreach($audiobookRecordSets as $key =>$value) {
					$auth_lang['lang_key'] 				= $value;
					$auth_lang['lang_value'] 			= 'Audiobook - '.$languages[$value];
					$auth_lang['real_value'] 	= (is_array($website_aud_languages[$value])) ? $website_aud_languages[$value]['real_value'] : 'Audiobook - '.$languages[$value];
					$auth_lang['display'] 				= (is_array($website_aud_languages[$value])) ? $website_aud_languages[$value]['display'] : 1;
					$order[$key] = $auth_lang['order'] 	= (isset($website_aud_languages[$value]['order'])) ? $website_aud_languages[$value]['order'] : 999;
					$authorAaudiobookSeetingRecordSets[$key] 			= $auth_lang;
				}
			}				
			if (count($authorAaudiobookSeetingRecordSets) > 1 )
				@array_multisort($order, SORT_ASC, $authorAaudiobookSeetingRecordSets);
			
			if(is_array($authorAaudiobookSeetingRecordSets) && count($authorAaudiobookSeetingRecordSets)>0)
			{
				$str .='<div style="color:red;padding:0px 0px 2px 0px;">Drag and drop the audiobook into the order that you would like them to appear on the website.</div>';
				$str .='<form action="" method="post" id="frmLogAudio" name="frmLogAudio">
						<input type="hidden" name="author_id" id="author_id" value="'.$selectedAuthor.'">
						<input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">';

					$str .='<table cellspacing="0" cellpadding="5" border="0" width="100%">
							<tbody>';
					if(!empty($audiobbok_set_message))
					{
						$str .='<tr align="left">
									<td height="1" style="padding: 8px;color:green" class="successmsg_12" colspan="4" align="center">'.$audiobbok_set_message.'</td>
								</tr>';
					}
					$str .='<tr style="background:#D9D9D9;height:30px;">
								<td width="10%" style="font-size:11px;" valign="top"><b>On/Off</b></td>
								<td width="30%" style="font-size:11px;"><b>Audiobook</b></td>
								<td width="70%" style="font-size:11px;"><b>Display Text</b></td>
							</tr>';
						
					$str .='<tr><td colspan="3"><ul  id="menu-pages_sort_audio">';
					   $audio_record_array = array();
					   
					   foreach($authorAaudiobookSeetingRecordSets as $key => $value)
					   {	
							
						   if($languages[$value['lang_key']]!='English'){
								$langrealstr = 'Audiobook - '.$languages[$value['lang_key']];
								$langstr     ='Audiobook - '.$languages[$value['lang_key']];
						   }
						   else {
								$langrealstr = 'Audiobook - '.$languages[$value['lang_key']];
								$langstr = 'Audiobook - English';
						   }
						   $audio_record_array[]=$value['lang_key'];
						$str .='<li  id="page_'.$value['lang_key'].'">
										<table cellspacing="0" cellpadding="5" border="0" width="100%">
										<tr class="smallclassnew">';
											if($value['display']) {
												$checked = 'checked';
											}
											else{
												$checked = '';
											}
											$str .='<td class="smallclassnew" valign="top" width="10%">
											<input type="checkbox" '.$checked.' name="record_array['.$value['lang_key'].']" value='.$value['lang_key'].' ></td>';
											$str .='<td class="smallclassnew" valign="top" width="30%" style="font-size:11px"> '.$langrealstr.'</td>
											<td class="smallclassnew" valign="top" width="70%" style="font-size:11px">
												<input type="text" name="real_value['.$value['lang_key'].']" id="real_value_'.$value['lang_key'].'" value="'.$value['real_value'].'">
											</td>
										</tr>
									</table>
								</li>';
						} 
					$str .='</ul></td></tr>';
					$audio_record_string = implode(',',$audio_record_array);
					$str .='<tr class="smallclassnew">
								<td align="left" class="smallclassnew" colspan="4" style="border-top:1px solid #cfcfcf;">
									<input type="submit" name="saveAudio" value="Save" style="margin-bottom:-3px;padding-bottom:0px;" class="button button-primary save">
									<input type="hidden" name="audio_record_array" value="'.$audio_record_string.'">
									</td>	
							</tr>';

					$str .='<tr align="center">
						<td height="1" style="padding: 8px;" colspan="4"></td>
						</tr>
						</tbody>
					</table>
					</form>';
				}
			echo $str; 
	}
}


if( !function_exists( 'save_audiobook_setting' ) ) {
	function save_audiobook_setting()
	{
		global $wpdb;
		$settings = get_option( 'pub-assistant' );
		$languages  = $settings['languages'];
		
		if(!empty($languages))
		{	
			$num = 0;
			extract($_POST);
			foreach($languages as $key => $value)
			{
				if (isset($real_value[$key])) {
					$data['lang_key'] = $key;
					$data['real_value'] = $real_value[$key];
					$data['display'] = (isset($record_array[$key]))? 1 : 0; 
					$data['order'] = $order[$key]; 
					$dataToSave[$key] = $data;
				}
			}
			if(get_post_meta($website_id, 'website_aud_languages', true))
				update_post_meta($website_id, 'website_aud_languages' , $dataToSave);
			else
				add_post_meta($website_id, 'website_aud_languages', $dataToSave);
			$set_message="Audiobook has been updated successfully.";	
		}
		return $set_message;
	}
}

if( !function_exists( 'update_language' ) ) {
	function update_language()
	{
		global $wpdb;
		
		$settings = get_option( 'pub-assistant' );
		$languages = $settings[ 'languages' ];
		
		$dataToSave = array();
		$set_message ='';
		if(!empty($languages))
		{	
			extract($_POST);
			$order = 1;
			foreach($real_value as $key => $value)
			{
				if (isset($real_value[$key])) {
					$data['real_value'] = $real_value[$key];
					$data['display'] = (isset($record_array[$key]))? 1 : 0; 
					$data['order'] = $order++; 
					$dataToSave[$key] = $data;
				}
			}
			
			
			if(get_post_meta($website_id, 'website_languages', true))
				update_post_meta($website_id, 'website_languages' , $dataToSave);
			else
				add_post_meta($website_id, 'website_languages', $dataToSave);
			
			$set_message="Language has been updated successfully.";		
		}
		return $set_message;
	}
}
?>