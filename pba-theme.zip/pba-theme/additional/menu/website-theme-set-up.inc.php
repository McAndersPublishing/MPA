<?php
/**
 * Main menu page.
 */
if( !function_exists( 'pba_register_website_theme_setup_menu' ) ) {
	add_action( 'admin_menu', 'pba_register_website_theme_setup_menu', 18, 0 );
	/**
	 * Registers the menu page.
	 */
	function pba_register_website_theme_setup_menu() {
		global $wpdb;
		$website_theme_setup = 'Website Theme Setup';

		$query = "SELECT * FROM ".$wpdb->prefix ."author_theme";
		$websites = $wpdb->get_results( $query );
		
		$Initfunc = '';
		//add_submenu_page( 'pba_pub_assistant', 'Website Setup', 'Website Setup', 'manage_options',	'pba_new_website_setup', 'pba_new_website_setup' );		
		add_submenu_page( 'pba_pub_assistant', 'Website Setup', 'Website Setup', 'manage_options',	'pba_website_theme_set_up_1', 'pba_website_theme_set_up_1' );		
		/*
		$mpWeb = 1;
		
		foreach ( $websites as $w ) 
		{
			if ($w->author_id == '')
				$website_theme_setup = 'New Website';
			else{
				$aids = explode (',',$w->author_id);
				if (count($aids) == 1){
					$authorInfo = get_post($w->author_id);
					$website_theme_setup = 'Website '.$authorInfo->post_title;
				}else{
					$website_theme_setup = 'Website Mulitple '.$mpWeb++;
				}
			}
			$Initfunc = '
			function pba_display_website_theme_setup_menu_'.$w->id.'(){
				pba_display_website_theme_setup_menu('.$w->id.') ;
			}';
			eval($Initfunc);
			add_submenu_page( 'pba_pub_assistant', $website_theme_setup, $website_theme_setup, 'manage_options',
			'pba_website_theme_set_up_'.$w->id, 'pba_display_website_theme_setup_menu_'.$w->id);		
		}*/
	}
}

function pba_website_theme_set_up_1(){
	pba_display_website_theme_setup_menu('1');
}

if( !function_exists( 'pba_new_website_setup' ) ) {
	/**
	 * Displays the menu page for "Website Setp".
	 */
	function pba_new_website_setup() {
		echo '
			<div class="wpbody">
				<img src="'. get_template_directory_uri().'/images/new_website.jpg" style="float:left;margin : 1px;"/>
				<h2 style="line-height:32px; ">Create a new website</h2> <br />';
				
				if(isset($_GET['action']) && ($_GET['action'] == '1'))	 {
					//// create new website with no author yet selected
					global $wpdb;
					$author_theme_table = $wpdb->prefix . "author_theme";

					$data = array('author_id'=> '');
					$format = array('%s');
					$wpdb->insert( $author_theme_table, $data, $format );
					$websiteId = $wpdb->insert_id;
					$url= '?page=pba_new_website_setup&added=1&id='.$websiteId;
					echo '<script type="text/javascript">window.location = "'.$url.'"</script>';					
				}elseif(isset($_GET['added']) && ($_GET['added'] == '1')) {
					echo "New Website has been created. Please manage the website setting from the new tab  <a href= '?page=pba_website_theme_set_up_".$_GET['id']."' >New Website</a> in menu.";
				}else{
					echo '<a href="?page=pba_new_website_setup&action=1"><input type="button" value="Create" title="Create New Website" class="button button-primary pba-button" name="pba_webisteSetup_createnew" id="pba_webisteSetup_createnew"></a>';
				}
			echo '</div>
			<div class="clear"></div>
		';
	}
}
	
if( !function_exists( 'pba_display_website_theme_setup_menu' ) ) {
	/**
	 * Displays the menu page.
	 */
	function pba_display_website_theme_setup_menu($website_id) 
	{
		
		$authorIDs = displayHeading($website_id, 'Website Theme Setup');
		
		if( array_key_exists( 'pba', $_POST ) ) {
			$input = $_POST[ 'pba' ];
		} else {
			$input = array();
		}
		
		if ($authorIDs[0] == ''){
			$menu_items = array(
				'authors' 		=> array(
					'href'				=> 'admin.php?page=author-list&website_id='.$website_id,
					'title'				=> 'Choose an Author',
					'description'	    => 'Choose an author to display on this website.',
				),
			);
		}else {
			$menu_items = array(
				'authors' 		=> array(
					'href'				=> 'admin.php?page=author-list&website_id='.$website_id,
					'title'				=> 'Choose an Author',
					'description'	    => 'Choose an author to display on this website.',
				),
				'categories'			=> array(
					'href'				=> 'admin.php?page=language	list&website_id='.$website_id,
					'title'				=> 'Categories',
					'description'	    => 'Languages that are set up for the chosen author.',
				),
				'Vendors'				=> array(
					'href'				=> 'admin.php?page=vendor-list&website_id='.$website_id,
					'title'				=> 'Vendors',
					'description'	    =>  'Manage Vendors.',
				),
				'book_previews'	=> array(
					'href'				=> 'admin.php?page=book-previews&website_id='.$website_id,
					'title'				=> 'Book Previews',
					'description'	    => 'Book Previews.',
				),
				'latest_releases'	    => array(
					'href'				=> 'admin.php?page=latest-releases&website_id='.$website_id,
					'title'				=> 'Latest Releases',
					'description'	    => 'Latest Releases.',
				),
				'special_offers'		=> array(
					'href'				=> 'admin.php?page=special-offers&website_id='.$website_id,
					'title'				=> 'Special Offers',
					'description'	    => 'Special Offers.',
				),
				'website_theme_appearance'=> array(
					'href'				=> 'admin.php?page=website-theme&website_id='.$website_id,
					'title'				=> 'Website Theme Appearance',
					'description'	    => 'Website Theme Appearance',
				),
				'google_analytics'      =>array(
					'href'				=> 'admin.php?page=google-analytics&website_id='.$website_id,
					'title'				=> 'Google Analytics',
					'description'	    => 'Google Analytics.',
				)   
			);
		}
		
		$menu_items = apply_filters( 'pba_set_up_menu_items', $menu_items );

		//echo '<h3>Book Listing Short Code:    [PBA_BOOKLISTS websiteid='.$website_id.'] <span> Use this shortcode in the page editor</span></h3>';
		echo '<ul>';
		
		foreach( $menu_items as $menu_item ) {
			echo '<li><a href="', $menu_item[ 'href' ], '" title="', $menu_item[ 'title' ], '">', $menu_item[ 'title' ], '</a> - <span>', $menu_item[ 'description' ], '</span></li>';	
		}
	
		echo '</ul>';
	
		echo '</div><div class="clear"></div>';		
	}
}

add_action('admin_print_scripts-languagelist' , 'my_plugin_admin_scripts');

function admin_load_js($hook){

	if ('admin_page_languagelist' != $hook)
		return;
	
//	wp_enqueue_script( 'pba_jquery_min', PBA_PLUGIN_URL. 'scripts/jquery.min.js', array('jquery') );
	wp_enqueue_script( 'pba_jquery_ui_min', PBA_PLUGIN_URL. 'scripts/jquery-ui.min.js', array('jquery') );	
}

add_action('admin_enqueue_scripts', 'admin_load_js');

?>