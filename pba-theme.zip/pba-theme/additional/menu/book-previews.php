<?php
//ini_set('display_errors',1);
//print_r($_REQUEST);
if( !function_exists( 'website_theme_register_book_previews_menu' ) ) {
	add_action( 'admin_menu', 'website_theme_register_book_previews_menu');
	/**
	 * Registers the menu page.
	 */
	function website_theme_register_book_previews_menu() {
		add_submenu_page(null, 'Book Previews', 'Book Previews', 'manage_options', 'book-previews', 'display_book_preview_setting' );
	}
}
if( !function_exists( 'display_book_preview_setting' ) ) {

	function display_book_preview_setting()
	{
		global $wpdb;
        
		$book_preview_set_message ='';
		if(isset($_POST['Preview']) && !empty($_POST['Preview']))
		{
			$website_id = $_REQUEST[website_id];
			if(get_option('preview_percentage'))
				update_option('preview_percentage' , $_POST['preview_percentage']);
			else
				add_option('preview_percentage', $_POST['preview_percentage']);
				
			$book_preview_set_message="Book preview setting has been updated successfully.";		
			
		}

		/// Display Page Heading
        $selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
        $selectedAuthor = displayHeading($selectedwebsite, 'Previews related Setting'); 
		
		if ($selectedwebsite) 
		{
			$str     = '';

			$preview_percentage = get_option('preview_percentage'); // fetching Author related language information
            if ( !$preview_percentage ) $preview_percentage = 15;
			
			$str .='<form action="" method="post" id="frmLogPreview" name="frmLogPreview" onsubmit="return checkBookPreviewFormValidity()">
			<input type="hidden" name="website_id" id="website_id" value="'.$selectedwebsite.'">';
			$str .='<table cellspacing="0" cellpadding="2" border="0" width="100%"><tbody>';

			if(!empty($book_preview_set_message))
			{
				$str .='<tr align="left"><td height="1" style="padding: 8px;color:green" class="successmsg_12" colspan="4" align="center">'.$book_preview_set_message.'</td></tr>';
			}
				
			$str .='<tr>';
			$str .='<td class="smallclassnew" valign="top" align="left" width="16%"><b>Book Preview Setting:</b></td>';
			$str .='<td class="smallclassnew" valign="top" align="left" width="7%" style="font-size:11px"><input type="text" name="preview_percentage" id="preview_percentage" value="'.$preview_percentage.'" style="width:40px;">%</td>';
			$str .='<td class="smallclassnew" valign="top" align="left" width="77%" style="font-size:11px;">';
			$str .='<input type="submit" name="Preview" value="Save" class="button button-primary save">';
			$str .='</td>';
			$str .='</tr>';

			$str .='<tr align="center">';
			$str .='<td height="1" style="padding: 8px;" colspan="3"></td>';
			$str .='</tr>';
			$str .='</tbody>';
			$str .='</table>';
			$str .='</form>';
			$str .='<script>
			function checkBookPreviewFormValidity(){
				if(document.getElementById(\'preview_percentage\').value==\'\')
				{ 
					alert(\'Percentage value can`t be null.\');
					return false; 
				}
				return true;
			}
			</script>';
			echo $str; 
		} 
        
        /*****************************************************/
        
        if(isset($_POST['btn_update']) && $_POST['btn_update']=='1')
        {
            $languageTable = $wpdb->prefix . "language";
            //$set_message = update_language($languageTable);
            $url= 'admin.php?page=book-previews&sucuss='.$set_message.'&website_id='.$_REQUEST['website_id'];
            wp_redirect($url);
        }
        
        $author_preview_setting_table = $wpdb->prefix . "author_preview_setting";
        $default_preview_table = $wpdb->prefix . "default_preview_setting";
        $author_preview_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
        $settings = get_option( 'pub-assistant' );
        $previews = $settings[ 'previews' ];
        $media = $settings[ 'media' ];
        $media_defaults = $settings[ 'media-defaults' ];
        $image_path = wp_upload_dir();
        
        $message = '';
        
        
        // save audiobook setting for a particular author
        if(isset($_POST['Preview']) && !empty($_POST['Preview']))
        {
            $preview_set_message = update_preview_setting($author_preview_setting_table);
            $url= 'admin.php?page=book-previews&previewsucuss='.$preview_set_message.'&website_id='.$_REQUEST['website_id'];
            wp_redirect($url);
        }
        if(isset($_POST['PreviewAudiobook']) && !empty($_POST['PreviewAudiobook']))
        {
            $preview_audiobook_set_message = update_preview_audiobook_setting($author_preview_audiobook_setting_table);
            $url= 'admin.php?page=book-previews&previewaudiobooksucuss='.$preview_audiobook_set_message.'&website_id='.$_REQUEST['website_id'];
            wp_redirect($url);
        }
        
        if ($selectedwebsite) 
        {
            save_preview_setting($previews,$selectedwebsite);
            save_preview_audiobook_setting($previews,$selectedwebsite);
            
            include_once(dirname(__FILE__).'/includes/preview.inc.php');
        } 
        /******************************************************/     
	} 
}

function save_preview_audio($id,$lang,$slug)
{
    global $wpdb;
    $author_preview_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
    
    $image_path = wp_upload_dir();
    
    if(!empty($id))
    {    
            $preview_name = $slug;
            $display_text_button = $_POST['pba_audio']['new_link'][$slug];

            $btnstatus=1;
            
            if(!empty($_FILES['preview_audioimage_'.$slug]["name"]))
            {
                if(!file_exists($image_path['basedir'].'/pub_upload')){
                    $old = umask(0);
                    mkdir($image_path['basedir'].'/pub_upload',0777);
                    mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
                    umask($old);
                } else if (!file_exists($image_path['basedir'].'/pub_upload/preview_ebook')) {
                    $old = umask(0);
                    mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
                    umask($old);
                }
                $filupTot1= array();
                $pic_f =$_FILES['preview_audioimage_'.$slug]["name"];
                $ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
                $pic_f = rand().time().'.'.$ext; #setting unique name to a pic
                $filupTot1 = move_uploaded_file ($_FILES['preview_audioimage_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/preview_audio/'.$pic_f);
                $preview_img='preview_audio/'.$pic_f;
                $btnstatus=2;
                
            }    
            
            
            $website_id = $_REQUEST['website_id'];
            
            if(isset($_POST['preview_audiodisplay_'.$slug]) && $_POST['preview_audiodisplay_'.$slug]==1){
            $display=1;
            }else{
            $display=0;
            } 
            
            if ($display_text_button == "Preview" && empty($preview_img) && $_REQUEST['pba_audio']['new_language']['prelisten'] == $lang) {
                $author_preview_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
                $query = "SELECT * FROM $author_preview_audiobook_setting_table WHERE preview_name='$preview_name' AND lang='en'";
                $result = $wpdb->get_row( $query );
                $display_text_button = $result->display_text_button;
                $preview_img = $result->image;
                $btnstatus = $result->btnstatus;
            }               
            
            $data = array('preview_name'=>$preview_name,'display_text_button'=>$display_text_button,'image'=>$preview_img,'lang'=>$lang,'author_id'=>$id,'display'=>$display,'order'=>$num,'btnstatus'=>$btnstatus);
            $format = array('%s','%s','%s','%s','%d','%d','%d','%d');
           
            $wpdb->insert($author_preview_audiobook_setting_table, $data, $format );
            
            $set_message="Preview setting has been updated successfully.";        
        
    }
    return $set_message;
}
function update_preview_audio($id,$lang,$slug)
{
    
    global $wpdb;
    $author_preview_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
    $image_path = wp_upload_dir();
    
        
    if(!empty($id))
    {    
        
            $preview_name = $slug;
            
            if($_POST['preview_audioimageup_'.$lang.'_'.$slug]!='' && empty($_FILES['preview_audioimage_'.$lang.'_'.$slug]['name'])){
            $preview_img=$_POST['preview_audioimageup_'.$lang.'_'.$slug];
            }else{
            $preview_img='';
            }
            
            
            if(!empty($_FILES['preview_audioimage_'.$lang.'_'.$slug]["name"])){
            
            if(!file_exists($image_path['basedir'].'/pub_upload')){
            $old = umask(0);
            mkdir($image_path['basedir'].'/pub_upload',0777);
            mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
            mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
            mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
            mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
            umask($old);
            } else if (!file_exists($image_path['basedir'].'/pub_upload/preview_ebook')) {
                $old = umask(0);
                mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
                mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
                umask($old);
            }
            
            $filupTot1= array();
            
            $pic_f =$_FILES['preview_audioimage_'.$lang.'_'.$slug]["name"];
            $ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
            $pic_f = rand().time().'.'.$ext; #setting unique name to a pic
            $filupTot1 = move_uploaded_file ($_FILES['preview_audioimage_'.$lang.'_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/preview_audio/'.$pic_f);
            $preview_img='preview_audio/'.$pic_f;
            }    
            
            
            $display_text_button = $_POST['pba_audio']['links'][$slug][$lang];
                        
            $website_id = $_REQUEST['website_id'];
            $btnbookstatus=0;
            
            if(isset($_POST['buttonselect_'.$lang.'_'.$slug])){
                if($_POST['buttonselect_'.$lang.'_'.$slug]=='btext_'.$lang.'_'.$slug){
                $btnbookstatus = 1;
                }elseif($_POST['buttonselect_'.$lang.'_'.$slug]=='bimage_'.$lang.'_'.$slug){
                $btnbookstatus = 2;
                }
            }
            
            if(isset($_POST['preview_audiodisplay_'.$lang.'_'.$slug]) && $_POST['preview_audiodisplay_'.$lang.'_'.$slug]==1){
            $display=1;
            }else{
            $display=0;
            }
            
            if ($display_text_button == "Preview" && empty($preview_img) && $_REQUEST['pba_audio']['new_language']['prelisten'] == $lang) {
                $author_preview_audiobook_setting_table = $wpdb->prefix . "author_preview_audio_setting";
                $query = "SELECT * FROM $author_preview_audio_setting_table WHERE preview_name='$preview_name' AND lang='en'";
                $result = $wpdb->get_row( $query );
                $display_text_button = $result->display_text_button;
                $preview_img = $result->image;
                $btnstatus = $result->btnstatus;
            }
            
            $data = array('preview_name'=>$preview_name,'image'=>$preview_img,'display_text_button'=>$display_text_button,
                'author_id'=>$website_id,'display'=>$display,'btnstatus'=>$btnbookstatus);
                        
            $format = array('%s','%s','%s','%d','%d','%d');
            $where  = array('preview_name'=>$preview_name,'lang'=>$lang,'author_id'=>$website_id);
            $where_format = array('%s','%s','%d');
            
            $wpdb->update( $author_preview_audiobook_setting_table, $data, $where, $format , $where_format );
            
            $set_message="Preview setting has been updated successfully.";        
        
    }
    return $set_message;
}
function update_preview_setting($id,$lang,$slug)
{
    global $wpdb;
    $author_preview_setting_table = $wpdb->prefix . "author_preview_setting";
    $preview_record_array = explode(',',$_POST['preview_record_array']);
    $image_path = wp_upload_dir();
    
    if(!empty($id))
    {    
            $preview_name = $slug;
            
            if($_POST['preview_imageup_'.$lang.'_'.$slug]!='' && empty($_FILES['preview_image_'.$lang.'_'.$slug]['name'])){
                $preview_img=$_POST['preview_imageup_'.$lang.'_'.$slug];
            }else{
                $preview_img='';
            }            
            
            if(!empty($_FILES['preview_image_'.$lang.'_'.$slug]["name"])){
                if(!file_exists($image_path['basedir'].'/pub_upload')){
                    $old = umask(0);
                    mkdir($image_path['basedir'].'/pub_upload',0777);
                    mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
                    umask($old);
                } else if (!file_exists($image_path['basedir'].'/pub_upload/preview_ebook')) {
                    $old = umask(0);
                    mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
                    mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
                    umask($old);
                }
                
                $filupTot1= array();
                
                //pr ($_FILES['vendor_image_'.$lang.'_'.$slug]);
                $pic_f =$_FILES['preview_image_'.$lang.'_'.$slug]["name"];
                $ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
                $pic_f = rand().time().'.'.$ext; #setting unique name to a pic
                // $image_path['basedir'].'/pub_upload/ebook/'.$pic_f;
                 $filupTot1 = move_uploaded_file ($_FILES['preview_image_'.$lang.'_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/preview_ebook/'.$pic_f);
                
                //var_dump($filupTot1);
                $preview_img='preview_ebook/'.$pic_f;
            }    
            
            
            $display_text_button = $_POST['pba']['links'][$slug][$lang];
            
            
            
            $website_id = $_REQUEST['website_id'];
            $btnbookstatus=0;
            
            if(isset($_POST['buttonselectbook_'.$lang.'_'.$slug])){
                if($_POST['buttonselectbook_'.$lang.'_'.$slug]=='bookbtext_'.$lang.'_'.$slug){
                $btnbookstatus = 1;
                }elseif($_POST['buttonselectbook_'.$lang.'_'.$slug]=='bookbimage_'.$lang.'_'.$slug){
                $btnbookstatus = 2;
                }
            }
            
            if(isset($_POST['preview_display_'.$lang.'_'.$slug]) && $_POST['preview_display_'.$lang.'_'.$slug]==1){
            $display=1;
            }else{
            $display=0;
            }
            
//            print_r($_POST);
            
            if ($display_text_button == "Preview" && empty($preview_img) && $_REQUEST['pba']['new_language']['preview'] == $lang) {
                $author_preview_setting_table = $wpdb->prefix . "author_preview_setting";
                $query = "SELECT * FROM $author_preview_setting_table WHERE preview_name='$preview_name' AND lang='en'";
                $result = $wpdb->get_row( $query );
                $display_text_button = $result->display_text_button;
                $preview_img = $result->image;
                $btnstatus = $result->btnstatus;
            }
                        
            $data = array('preview_name'=>$preview_name,'image'=>$preview_img,'display_text_button'=>$display_text_button,
                'author_id'=>$website_id,'display'=>$display,'btnstatus'=>$btnbookstatus);
            
                        
            $format = array('%s','%s','%s','%d','%d','%d');
            $where  = array('preview_name'=>$preview_name,'lang'=>$lang,'author_id'=>$website_id);
            $where_format = array('%s','%s','%d');
            
            $wpdb->update( $author_preview_setting_table, $data, $where, $format , $where_format );
            
            $set_message="Preview setting has been updated successfully.";        
        
    }
    return $set_message;
}
function save_preview($id,$lang,$slug)
{         
    global $wpdb;
    $author_preview_setting_table = $wpdb->prefix . "author_preview_setting";
    $preview_record_array = explode(',',$_POST['preview_record_array']);
    $image_path = wp_upload_dir();
    
    
    if(!empty($id))
    {    
        
            $preview_name = $slug;
            $display_text_button = $_POST['pba']['new_link'][$slug];
            $btnstatus=1;
            
            if(!empty($_FILES['preview_image_'.$slug]["name"])){
            
            if(!file_exists($image_path['basedir'].'/pub_upload')){
            $old = umask(0);
            mkdir($image_path['basedir'].'/pub_upload',0777);
            mkdir($image_path['basedir'].'/pub_upload/audio/',0777);
            mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
            mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
            mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
            umask($old);
            } else if (!file_exists($image_path['basedir'].'/pub_upload/preview_ebook')) {
                $old = umask(0);
                mkdir($image_path['basedir'].'/pub_upload/preview_audio/',0777);
                mkdir($image_path['basedir'].'/pub_upload/preview_ebook/',0777);
                umask($old);
            }
            
            $filupTot1= array();
            
            $pic_f =$_FILES['preview_image_'.$slug]["name"];
            $ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
            $pic_f = rand().time().'.'.$ext; #setting unique name to a pic
            $filupTot1 = move_uploaded_file ($_FILES['preview_image_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/preview_ebook/'.$pic_f);
            $preview_img='preview_ebook/'.$pic_f;
            $btnstatus=2;
            }    
            
            
            
            $website_id = $_REQUEST['website_id'];
            
            if(isset($_POST['preview_display_'.$slug]) && $_POST['preview_display_'.$slug]==1){
            $display=1;
            }else{
            $display=0;
            }
            
            if ($display_text_button == "Preview" && empty($preview_img) && $_REQUEST['pba']['new_language']['preview'] == $lang) {
                $author_preview_setting_table = $wpdb->prefix . "author_preview_setting";
                $query = "SELECT * FROM $author_preview_setting_table WHERE preview_name='$preview_name' AND lang='en'";
                $result = $wpdb->get_row( $query );
                $display_text_button = $result->display_text_button;
                $preview_img = $result->image;
                $btnstatus = $result->btnstatus;
            }    
            
            $data = array('preview_name'=>$preview_name,'display_text_button'=>$display_text_button,'image'=>$preview_img,'lang'=>$lang,'author_id'=>$id,'display'=>$display,'order'=>$num,'btnstatus'=>$btnstatus);
            $format = array('%s','%s','%s','%s','%d','%d','%d','%d');
            
                        
            $wpdb->insert( $author_preview_setting_table, $data, $format );
            
            $set_message="Preview setting has been updated successfully.";        
        
    }
    return $set_message;
}

if (isset($_POST['preview_record_array']) || isset($_REQUEST['preview_update'])) {
if(isset($_POST['savebook']) || isset($_POST['pba']['add_link']) || isset($_POST['pba']['remove_link'])){
if( !function_exists( 'save_preview_meta' ) ) {
    add_action( 'save_post_audio', 'save_preview_meta', 10, 1 );
    /**
     * Saves post meta.
     *
     * @param int $website_id Post ID.
     */
    function save_preview_meta( $website_id ) {
        
        if( !array_key_exists( 'pba', $_POST ) ) {
            return;
        }
        
        $input = $_POST[ 'pba' ];
       
        if( !array_key_exists( 'links', $input ) ) {
            $input[ 'links' ] = array();
        }                                                 
        
        $settings = get_option( 'pub-assistant' );
        $vendors = $settings[ 'previews' ];
        $links = $input[ 'links' ];
        $languages = array_keys( $settings[ 'languages' ] );
        
        foreach( $vendors as $vendor ) {
            $slug = $vendor[ 'slug' ];
            
            if( !array_key_exists( $slug, $links ) ) {
                continue;
            }
            
            $sites = $links[ $slug ];

            foreach( $languages as $language ) {
                if( array_key_exists( $language, $sites ) ) {

                    $vendor_set_message = update_preview_setting($website_id,$language,$slug,'');     
                }
            }
        }
        
        if( array_key_exists( 'remove_link', $input ) ) {
            $slug = key( $input[ 'remove_link' ] );
            $language = key( $input[ 'remove_link' ][ $slug ] );
            
            
            $vendor_set_message = delete_preview_book($website_id,$language,$slug);
            
        } else if( array_key_exists( 'add_link', $input ) ) {

            $new_links = $input[ 'new_link' ];
            $new_languages = $input[ 'new_language' ];
             
            if (is_array($new_links)) {                 
                foreach( $new_links as $slug => $new_link ) {
                    $new_link = trim( $new_link );
                    $new_link = 'default'; 
                    $language = $new_languages[ $slug ];
                    
                    
                    if( ($new_link && $language) || ($_FILES['preview_image_'.$slug]['name']!='' && $language) ) {
                        $vendor_set_message = save_preview($website_id,$language,$slug);
                        
                        
                    }
                }
            } 
        }
    }
}
save_preview_meta($_REQUEST['website_id']);
}

if(isset($_POST['saveaudio']) || isset($_POST['pba_audio']['add_link']) || isset($_POST['pba_audio']['remove_link'])){
    
if( !function_exists( 'save_preview_meta_audio' ) ) {
    add_action( 'save_post_audio', 'save_preview_meta_audio', 10, 1 );
    /**
     * Saves post meta.
     *
     * @param int $website_id Post ID.
     */
    function save_preview_meta_audio( $website_id ) {

        if( !array_key_exists( 'pba_audio', $_POST ) ) {
            return;
        }
        
        $input = $_POST[ 'pba_audio' ];
                        
        if( !array_key_exists( 'links', $input ) ) {
            $input[ 'links' ] = array();
        }
        
        if( array_key_exists( 'first_name', $input ) ) {
            $first_name = $input[ 'first_name' ];
        } else {
            $first_name = '';
        }
        update_post_meta( $website_id, '_pba_first_name', $first_name );
        
        
        if( array_key_exists( 'last_name', $input ) ) {
            $last_name = $input[ 'last_name' ];
        } else {
            $last_name = '';
        }
        
        update_post_meta( $website_id, '_pba_last_name', $last_name );
        
            
        
        $settings = get_option( 'pub-assistant' );
        $vendors = $settings[ 'previews' ];
        $links = $input[ 'links' ];
        
        $languages = array_keys( $settings[ 'languages' ] );
        
        foreach( $vendors as $vendor ) {
            $slug = $vendor[ 'slug' ];
                    
            if( !array_key_exists( $slug, $links ) ) {
                continue;
            }
            
            
            $sites = $links[ $slug ];
            
            foreach( $languages as $language ) {
                if( array_key_exists( $language, $sites ) ) {
                    
                    $vendor_set_message = update_preview_audio($website_id,$language,$slug,'');        
                    
                }
            }
        }
        
        if( array_key_exists( 'remove_link', $input ) ) {
            $slug = key( $input[ 'remove_link' ] );
            $language = key( $input[ 'remove_link' ][ $slug ] );
            
            //delete_post_meta( $website_id, '_pba_links_' . $slug . '_' . $language );
            $vendor_set_message = delete_preview_audio($website_id,$language,$slug);
            
        } else if (array_key_exists( 'add_link', $input )) {
            $new_links = $input[ 'new_link' ];
            
            $new_languages = $input[ 'new_language' ];
            
            
            foreach( $new_links as $slug => $new_link ) {
                $new_link = trim( $new_link );
                $language = $new_languages[ $slug ];
                
                
                if( ($language) || ($_FILES['preview_audioimage_'.$slug]['name']!='' && $language) ) {
                     
                    $vendor_set_message = save_preview_audio($website_id,$language,$slug);
                    
                }
            }
        }
        
        
    }
}
save_preview_meta_audio($_REQUEST['website_id']);
}

if(isset($_REQUEST['action'] ) && $_REQUEST['action']=='deleteimgaudio'){
    $image_path = wp_upload_dir();
    $website_ids = $_REQUEST['id'];
    if($website_ids!='')
    {
        global $wpdb;
        $preview_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
        $query = "SELECT image FROM $preview_audiobook_setting_table WHERE id='".$website_ids."'";
        $result = $wpdb->get_col( $query );
        
        $wpdb->get_results("SELECT image FROM $preview_audiobook_setting_table WHERE img='".$result[0]."'");
        if ($wpdb->num_rows == 1)
            @unlink($image_path['basedir'].'/pub_upload/'.$result[0]);
                                                                  
        $data = array('image'=>'', 'btnstatus' => 1);
                $format = array('%s', '%d');
                $where  = array('id'=>$website_ids);
                $where_format = array('%d');            
                $wpdb->update($preview_audiobook_setting_table, $data, $where, $format , $where_format );
        
        $url= 'admin.php?page=book-previews&website_id='.$_REQUEST['website_id'];
        wp_redirect($url);                  
    }
}

if(isset($_REQUEST['action'] )&& $_REQUEST['action']=='deleteimgebook')
{
    $image_path = wp_upload_dir();
    $website_ids = $_REQUEST['id'];
    if($website_ids!=''){
        global $wpdb;
        $preview_setting_table = $wpdb->prefix . "author_preview_setting";
        $query = "SELECT image FROM $preview_setting_table WHERE id='".$website_ids."'";
        $result = $wpdb->get_col( $query );
        
        $wpdb->get_results("SELECT image FROM $preview_setting_table WHERE img='".$result[0]."'");
        if ($wpdb->num_rows == 1)
            @unlink($image_path['basedir'].'/pub_upload/'.$result[0]);

        $data = array('image'=>'', 'btnstatus' => 1);
                $format = array('%s', '%d');
                $where  = array('id'=>$website_ids);
                $where_format = array('%d');            
                $wpdb->update($preview_setting_table, $data, $where, $format , $where_format );
        
        $url= 'admin.php?page=book-previews&website_id='.$_REQUEST['website_id'];
        wp_redirect($url);
    }
}
}
function delete_preview_audio($website_id,$language,$slug)
{
    if($website_id!=''){
        global $wpdb;
        $author_vendor_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
        
                $where  = array('author_id'=>$website_id,'lang'=>$language,'preview_name'=>$slug);
                $author_vendor_audiobook_setting_table;
                $wpdb->delete($author_vendor_audiobook_setting_table,$where);
                
    }
}
function delete_preview_book($website_id,$language,$slug)
{
    if($website_id!=''){
        global $wpdb;
        $author_vendor_setting_table = $wpdb->prefix . "author_preview_setting";
        
                $where  = array('author_id'=>$website_id,'lang'=>$language,'preview_name'=>$slug);
                $author_vendor_audiobook_setting_table;
                $wpdb->delete($author_vendor_setting_table,$where);
                
    }
}

function save_preview_setting($vendors,$website_id)
{
    global $wpdb;
    $author_vendor_setting_table = $wpdb->prefix . "author_preview_setting";

    if(!empty($vendors))
    {    
        $num = 0;       
        foreach($vendors as $key => $value){
        
            $query = "SELECT id FROM $author_vendor_setting_table WHERE preview_name='".$value['slug']."' AND author_id=$website_id";
            $result = $wpdb->get_col( $query );
                        
            if(count($result)==0){
                if(in_array('e-book',$value['media'])){
                    $data = array('preview_name'=>$value['slug'],'display_text_button'=>$value['name'],
                        'author_id'=>$website_id,'display'=>1,'order'=>$num, 'lang' => 'en'
                    );
                    $format = array('%s','%s','%d','%d','%d', '%s');
					$wpdb->insert( $author_vendor_setting_table, $data, $format );
                    $num++;
                    $set_message="Preview setting has been updated successfully.";    
                }
            }else{
                if(in_array('e-book',$value['media'])){
                
                }else{
                    $where=array('id'=>$result[0]);
                    $wpdb->delete($author_vendor_setting_table,$where);
                }
            }
        }
    }
    return $set_message;
}

function save_preview_audiobook_setting($vendors,$website_id)
{
    global $wpdb;
    $author_vendor_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
    if(!empty($vendors))
    {
        $num = 0;
        foreach($vendors as $key => $value){
            
            $query = "SELECT id FROM $author_vendor_audiobook_setting_table WHERE preview_name='".$value['slug']."' AND author_id=$website_id";
            $result = $wpdb->get_col( $query );
            if(count($result)==0){
                if(in_array('audiobook',$value['media'])){
                    $data = array('preview_name'=>$value['slug'], 'display_text_button'=>$value['name'], 'lang' => 'en', 'author_id'=>$website_id,'display'=>1,'order'=>$num);
                    $format = array('%s', '%s', '%s','%d','%d','%d');
                    $wpdb->insert( $author_vendor_audiobook_setting_table, $data, $format );
                    $set_message="Previews that display for audiobooks setting has been updated successfully.";    
                    $num++;
                }
            }else{
                if(in_array('audiobook',$value['media'])){
                }else{
                $where=array('id'=>$result[0]);
                $wpdb->delete($author_vendor_audiobook_setting_table,$where);
                }            
            }
        }
    }
    return $set_message;
}
function update_preview_audiobook_setting($author_vendor_audiobook_setting_table)
{
    global $wpdb;
    $vendor_audio_record_array = explode(',',$_POST['preview_audio_record_array']);
    
    if(!empty($vendor_audio_record_array))
    {    
        $website_id = $_REQUEST['website_id'];
        foreach($vendor_audio_record_array as $key => $value)
        {
            $display_text_button = $_POST['display_text_'.$value];
            
            if($_POST['preview_audioimageup_'.$value] && empty($_FILES['preview_audioimage_'.$value]['name'])){
                $vendor_img=$_POST['preview_audioimageup_'.$value];
            }else{
                $vendor_img='';
            }
            
            if(!empty($_FILES['preview_audioimage_'.$value]['name'])){
                $filupTot1= array();
                $pic_f = $_FILES['preview_audioimage_'.$value]["name"];
                $ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
                $pic_f = rand().time().'.'.$ext; #setting unique name to a pic
                $filupTot1 = move_uploaded_file ($_FILES['preview_audioimage_'.$value]['tmp_name'], dirname(__FILE__).'/preview_audio/'.$pic_f);
                $vendor_img='preview_audio/'.$pic_f;
            }
            
            if(isset($_POST['record_array']) && !empty($_POST['record_array'])){
                if(in_array($value,$_POST['record_array'])){
                    $display = 1;
                }
                else{
                    $display = 0;
                }
            }
            else {
                $display = 0;
            }
            $btnstatus=0;
            if(isset($_POST['buttonselect_'.$value]) && !empty($_POST['buttonselect_'.$value])){
                if($_POST['buttonselect_'.$value]=='btext_'.$value){
                $btnstatus=1;
                }elseif($_POST['buttonselect_'.$value]=='bimage_'.$value){
                $btnstatus=2;
                }
            }
            $data = array('display_text_button'=>$display_text_button,'image'=>$vendor_img,'display'=>$display,'btnstatus'=>$btnstatus);
            $format = array('%s','%s','%d','%d');
            $where  = array('id'=>$value,'author_id'=>$website_id);
            $where_format = array('%d','%d');
            $wpdb->update( $author_vendor_audiobook_setting_table, $data, $where, $format , $where_format );
            $set_message="Choose the previews that display for audiobooks setting has been updated successfully.";        
        }
    }
    return $set_message;
}
        
/*********************************************************************************/        

?>