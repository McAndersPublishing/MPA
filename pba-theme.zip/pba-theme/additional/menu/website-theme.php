<?php
ini_set('display_errors',1);
if( !function_exists( 'pba_register_author_website_theme' ) ) {
	add_action( 'admin_menu', 'pba_register_author_website_theme' );
	/**
	 * Registers the menu page.
	 */
	function pba_register_author_website_theme() {
		add_submenu_page( null, 'Website Theme Appearance', 
			'Website Theme Appearance', 'manage_options', 'website-theme', 
			'display_added_all_author_list', get_template_directory_uri() . '/images/logo-9-16.jpg', 3.01 );
	}
}
if( !function_exists( 'display_added_all_author_list' ) ) {
	global $wpdb;
	function display_added_all_author_list(){
		//ini_set('display_errors',1);
		global $wpdb;
		
		if(isset($_POST['save_theme']) && !empty($_POST['save_theme']))
		{
			$theme_site_title    			= trim($_POST['theme_site_title']);
			$theme_tagline  				= trim($_POST['theme_tagline']);
			$theme_display_header   = trim($_POST['theme_display_header']);
			$website_id 						= $_REQUEST[website_id];
			
			$theme_data = array(
										'theme_site_title'   => $theme_site_title, 
										'theme_tagline' => $theme_tagline,
										'theme_display_header'   => $theme_display_header
									);
			
			if(get_post_meta($website_id, 'theme_data_setting', true))
				update_post_meta($website_id, 'theme_data_setting' , $theme_data);
			else
				add_post_meta($website_id, 'theme_data_setting', $theme_data);

			$message = 'Theme Settings has been updated.';
		}
		/// Display Page Heading
		$selectedwebsite = (isset($_REQUEST[website_id])) ? $_REQUEST[website_id] : 0;  // selected Author ID
		displayHeading($selectedwebsite, 'Theme Settings'); 
		
		if ($selectedwebsite) 
		{
			$theme_data_setting = get_post_meta($selectedwebsite, 'theme_data_setting', true);
			$theme_display_header	= ($theme_data_setting['theme_display_header']) ? "checked='checked'": '';
			$str='';
			if(isset($message) && !empty($message)){
				$str .='<div style=""><p style="color:green;text-align:left;">'.$message.'</p></div>';
			}
			$str .='<div style="color:red;padding:0px 0px 2px 0px;"></div>';
			$str .='<form action="" method="post" id="frmTheme" name="frmTheme">
					<input type="hidden" name="website_id"  value="'.$_REQUEST['website_id'].'">';

			$str .='<table cellspacing="0" cellpadding="5" border="0" width="100%" id="test-list">
					<tbody>';
				
			$str .='<tr style="background:#D9D9D9;height:30px;">
						<td width="100%" colspan="2" style="font-size:11px;" valign="top"><b>Site Title & Tagline.</b></td>
					</tr>';
			$str .='<tr>
						<td width="25%" valign="top">Site Title</td>
						<td width="75%" valign="top"><input type="text" name="theme_site_title" value="'.$theme_data_setting['theme_site_title'].'"></td>
					</tr>';
			$str .='<tr>
						<td width="25%" valign="top">TagLine</td>
						<td width="75%" valign="top"><input type="text" name="theme_tagline" value="'.$theme_data_setting['theme_tagline'].'"></td>
					</tr>';
			$str .='<tr>
						<td width="25%" valign="top">Display Header Text </td>
						<td width="75%" valign="top"><input type="checkbox" name="theme_display_header" value="1" '.$theme_display_header.'></td>
					</tr>';
			$str .='<tr class="smallclassnew">
					<td align="left" class="smallclassnew" colspan="4" style="border-top:1px solid #cfcfcf;">
					<input type="submit" name="save_theme" value="Save" style="margin-bottom:-3px;padding-bottom:0px;"></td>	
					</tr>';

			$str .='<tr align="center">
								<td height="1" style="padding: 8px;" colspan="4"></td>
							</tr>
				</tbody>
			</table>
			</form>';
		}
		echo $str; 
	} 
}
?>