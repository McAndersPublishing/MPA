<?php
ini_set('display_errors',1);
if( !function_exists( 'pba_register_author_list_menu' ) ) {
	add_action( 'admin_menu', 'pba_register_author_list_menu' );
	/**
	 * Registers the menu page.
	 */
	function pba_register_author_list_menu() {
		add_submenu_page( null, 'Choose an Author', 
			'Choose an Author', 'manage_options', 'author-list', 
			'display_added_author_list', get_template_directory_uri() . '/images/logo-9-16.jpg', 3.01 );
	}
}
if( !function_exists( 'display_added_author_list' ) ) {
	global $wpdb;
	function display_added_author_list()
	{
	    global $wpdb;
		$author_theme_table = $wpdb->prefix . "author_theme";
		if( array_key_exists( 'action', $_POST ) ) {
			$action = $_POST[ 'action' ];
			
			
			$res = $wpdb->update( $author_theme_table, 
				array( 
					'author_id' => implode (',',$_POST['author_id'])	 
				), 
				array( 'id' => $_GET['website_id']), 
				array( 
					'%s',	
				), 
				array( '%s' ) 
            );	
			
			if ($res === 0){
				$data = array('id' => 1, 'author_id'=> implode (',',$_POST['author_id']));
				$format = array('%d', '%s');
				$wpdb->insert( $author_theme_table, $data, $format );
				$websiteId = $wpdb->insert_id;
			}
			
			
			$message = 'Selected Authors has been saved.';
			
			/// create/Update frontend Page for webiste
			//pba_websitePage($_GET['website_id']);
			
		}
		$webisteAuthorQuery = $wpdb->prepare ("
													SELECT author_id FROM 
													$author_theme_table 
													WHERE id = %d
													", 
													$_GET['website_id']
												);
		$selectedAuthor = $wpdb->get_col( $webisteAuthorQuery );
		$str='
		<div class="wpbody">
			<h1 style="line-height:32px; ">Choose the author or authors to display on your new website: </h1> <br />';
			
		if(isset($message) && !empty($message)){
		
			$str .='<div style=""><p style="color:green;text-align:left;">'.$message.'</p></div>';
		}
		$authorHtml = AuthorSelectBox($selectedAuthor[0]);
		$str .='
			<form action="" method="post" id="frmLog" name="frmLog" onsubmit="return checkFormValidity()">
				<div style="padding-bottom:20px;">
					'.$authorHtml.'
					<input type="submit" name="action" id="theme_author" value="Save" class="button button-primary save">
					<a href="?page=pba_website_theme_set_up_'.$_GET['website_id'].'"><input type="button" name="back" id="back" value="Next" class="button button-primary save"></a>
					</p>
				</div>
			</form>
		</div>';
		echo $str; 
	} 
	
	function pba_websitePage($website_id){
		global $wpdb;
		$query = $wpdb->prepare ("SELECT author_id , page_id FROM ".$wpdb->prefix ."author_theme where id = %d", $website_id);
		$author_ids = $wpdb->get_row( $query , ARRAY_N)	;
		$aids = $author_id = $author_ids[0];
		
		$AuthorNameArr = array();
		if (is_int($author_id)){
			$authorInfo = get_post($author_id);
			$AuthorName = $authorInfo->post_title;
			$pageTitle = 'Website '.$authorInfo->post_title;
		}else{
			$aids = explode (',',$author_id);
			
			if (count($aids) == 1){
				$authorInfo = get_post($author_id);
				$pageTitle = 'Website '.$authorInfo->post_title;
			}else{
				$pageTitle = 'Website Multiple ';
			}
		}		
		
		if ($author_ids[1] == 0){
			// Create page object
			$my_post = array(
			  'post_title'    => $pageTitle,
			  'post_content'  => ' [PBA_BOOKLISTS websiteid='.$website_id.']',
			  'post_status'   => 'publish',
			  'post_type'   => 'page',
			  'post_author'   => get_current_user_id( ),
			);

			// Insert the post into the database
			echo "PageId:".$pageId = wp_insert_post( $my_post );		
			
			$query = $wpdb->prepare ("update ".$wpdb->prefix ."author_theme set page_id = %d where id = %d", $pageId, $website_id);
			$wpdb->query( $query );
			
			/// create menu in Pba Menu
		
			$mymenu = wp_get_nav_menu_object('PbaMenu');
			if($mymenu){			
				$menuID = (int) $mymenu->term_id; 
				
				$itemData_2 =  array(	
					'menu-item-object-id' => $pageId	,
					'menu-item-parent-id' => 0,
					'menu-item-object' => 'page',
					'menu-item-type'      => 'post_type',
					'menu-item-status'    => 'publish'
				);
				
				wp_update_nav_menu_item($menuID, 0, $itemData_2); 				
			}
			
		}else{
			$my_post = array(
				  'ID'           => $author_ids[1],
				  'post_title' => $pageTitle
			);

			// Update the post into the database
			wp_update_post( $my_post );
		}
	}
}
?>