<?php

function save_vendor_setting_for_paperback($vendors,$website_id)
{
	global $wpdb;
	$author_vendor_paperback_setting_table = $wpdb->prefix . "author_vendor_paperback_setting";
	if(!empty($vendors))
	{
		$num = 0;
		foreach($vendors as $key => $value){
			
			$query = "SELECT id FROM $author_vendor_paperback_setting_table WHERE vendor_name='".$value['slug']."' AND author_id=$website_id";
			$result = $wpdb->get_col( $query );
			if(count($result)==0){
				if(in_array('paperback',$value['media'])){
					$data = array('vendor_name'=>$value['slug'], 'display_text_button'=>$value['slug'], 'lang' => 'en', 'author_id'=>$website_id,'display'=>1,'order'=>$num);
					$format = array('%s', '%s', '%s','%d','%d','%d');
					$wpdb->insert( $author_vendor_paperback_setting_table, $data, $format );
					$set_message="Vendors that display for Paperback setting has been updated successfully.";	
					$num++;
				}
			}else{
				if(in_array('paperback',$value['media'])){
				}else{
				$where=array('id'=>$result[0]);
				$wpdb->delete($author_vendor_paperback_setting_table,$where);
				}			
			}
		}
	}
	return $set_message;
}

function update_vendor_paperback_setting($author_vendor_paperback_setting_table)
{
	global $wpdb;
	$vendor_paperback_record_array = explode(',',$_POST['vendor_paperback_record_array']);
	
	if(!empty($vendor_paperback_record_array))
	{	
		$website_id = $_REQUEST['website_id'];
		foreach($vendor_paperback_record_array as $key => $value)
		{
			$display_text_button = $_POST['display_text_'.$value];
			
			if($_POST['vendor_paperbackimageup_'.$value] && empty($_FILES['vendor_paperbackimage_'.$value]['name'])){
				$vendor_img=$_POST['vendor_paperbackimageup_'.$value];
			}else{
				$vendor_img='';
			}
			
			if(!empty($_FILES['vendor_paperbackimage_'.$value]['name'])){
				$filupTot1= array();
				$pic_f = $_FILES['vendor_paperbackimage_'.$value]["name"];
				$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
				$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
				$filupTot1 = move_uploaded_file ($_FILES['vendor_paperbackimage_'.$value]['tmp_name'], dirname(__FILE__).'/paperback/'.$pic_f);
				$vendor_img='paperback/'.$pic_f;
			}
			
			if(isset($_POST['record_array']) && !empty($_POST['record_array'])){
				if(in_array($value,$_POST['record_array'])){
					$display = 1;
				}
				else{
					$display = 0;
				}
			}
			else {
				$display = 0;
			}
			$btnstatus=0;
			if(isset($_POST['buttonselect_'.$value]) && !empty($_POST['buttonselect_'.$value])){
				if($_POST['buttonselect_'.$value]=='btext_'.$value){
				$btnstatus=1;
				}elseif($_POST['buttonselect_'.$value]=='bimage_'.$value){
				$btnstatus=2;
				}
			}
			$data = array('display_text_button'=>$display_text_button,'image'=>$vendor_img,'display'=>$display,'btnstatus'=>$btnstatus);
			$format = array('%s','%s','%d','%d');
			$where  = array('id'=>$value,'author_id'=>$website_id);
			$where_format = array('%d','%d');
			$wpdb->update( $author_vendor_paperback_setting_table, $data, $where, $format , $where_format );
			$set_message="Choose the vendors that display for Paperback setting has been updated successfully.";		
		}
	}
	return $set_message;
}

function delete_vendor_paperback($website_id,$language,$slug)
{
	if($website_id!=''){
		global $wpdb;
		$author_vendor_paperback_setting_table = $wpdb->prefix . "author_vendor_paperback_setting";

		$where  = array('author_id'=>$website_id,'lang'=>$language,'vendor_name'=>$slug);
		$author_vendor_paperback_setting_table;
		$wpdb->delete($author_vendor_paperback_setting_table,$where);
	}
}

if(isset($_POST['savepaperback']) || isset($_POST['pba_paperback']['add_link']) || isset($_POST['pba_paperback']['remove_link'])) {
	if( !function_exists( 'save_author_meta_paperback' ) ) {
		//add_action( 'save_post_audio', 'save_author_meta_paperback', 10, 1 );
		/**
		 * Saves post meta.
		 *
		 * @param int $website_id Post ID.
		 */
		function save_author_meta_paperback( $website_id ) {
			if( !array_key_exists( 'pba_paperback', $_POST ) ) {
				return;
			}
            
			$input = $_POST[ 'pba_paperback' ];
							
			if( !array_key_exists( 'links', $input ) ) {
				$input[ 'links' ] = array();
			}
			if( array_key_exists( 'first_name', $input ) ) {
				$first_name = $input[ 'first_name' ];
			} else {
				$first_name = '';
			}
			update_post_meta( $website_id, '_pba_first_name', $first_name );
			
			if( array_key_exists( 'last_name', $input ) ) {
				$last_name = $input[ 'last_name' ];
			} else {
				$last_name = '';
			}
			
			update_post_meta( $website_id, '_pba_last_name', $last_name );
			
			$settings = get_option( 'pub-assistant' );
			$vendors = $settings[ 'vendors' ];
			$links = $input[ 'links' ];
			$languages = array_keys( $settings[ 'languages' ] );
			
			foreach( $vendors as $vendor ) {
				$slug = $vendor[ 'slug' ];
						
				if( !array_key_exists( $slug, $links ) ) {
					continue;
				}
				$sites = $links[ $slug ];
				
				foreach( $languages as $language ) {
					if( array_key_exists( $language, $sites ) ) {
						$vendor_set_message = update_vendor_paperback($website_id,$language,$slug,'');		
					}
				}
			}
            
            if( array_key_exists( 'remove_link', $input ) ) {
                $slug = key( $input[ 'remove_link' ] );
                $language = key( $input[ 'remove_link' ][ $slug ] );
                //delete_post_meta( $website_id, '_pba_links_' . $slug . '_' . $language );
                $vendor_set_message = delete_vendor_paperback($website_id,$language,$slug);
            } else if (array_key_exists( 'add_link', $input )) {
            	
                
			    $new_links = $input[ 'add_link' ];
			    
			    $new_languages = $input[ 'new_language' ];
			    
                if (is_array($new_links)) {

			        foreach( $new_links as $slug => $new_link ) {
				        $new_link = trim( $new_link );
				        $language = $new_languages[ $slug ];
				        
				        if( ($language) || ($_FILES['vendor_paperbackimage_'.$slug]['name']!='' && $language) ) {
                            $vendor_set_message = save_vendor_paperback($website_id,$language,$slug);
				        }
			        }
                }
            }
		}
	}
	save_author_meta_paperback($_REQUEST['website_id']);
}

if(isset($_REQUEST['action'] ) && $_REQUEST['action']=='deleteimgpaperback'){

	$image_path = wp_upload_dir();
	$website_ids = $_REQUEST['id'];
	if($website_ids!='')
	{
		global $wpdb;
		$author_vendor_paperback_setting_table = $wpdb->prefix . "author_vendor_paperback_setting";
		$query = "SELECT image FROM $author_vendor_paperback_setting_table WHERE id='".$website_ids."'";
		$result = $wpdb->get_col( $query );
        $wpdb->get_results("SELECT image FROM $author_vendor_paperback_setting_table WHERE img='".$result[0]."'");
        if ($wpdb->num_rows == 1)
            @unlink($image_path['basedir'].'/pub_upload/'.$result[0]);
            
		$data = array('image'=>'', 'btnstatus'=>1);
		$format = array('%s', '%d');
		$where  = array('id'=>$website_ids);
		$where_format = array('%d');			
		$wpdb->update($author_vendor_paperback_setting_table, $data, $where, $format , $where_format );
		
		$url= 'admin.php?page=vendor-list&website_id='.$_REQUEST['website_id'];
		wp_redirect($url);	 
	}
}

function update_vendor_paperback($id,$lang,$slug)
{
	global $wpdb;
	$author_vendor_paperback_setting_table = $wpdb->prefix . "author_vendor_paperback_setting";
	$image_path = wp_upload_dir();
	
	if(!empty($id))
	{	
		$vendor_name = $slug;
		
		if($_POST['vendor_paperbackimageup_'.$lang.'_'.$slug]!='' && empty($_FILES['vendor_paperbackimage_'.$lang.'_'.$slug]['name'])){
			$vendor_img=$_POST['vendor_paperbackimageup_'.$lang.'_'.$slug];
			}else{
			$vendor_img='';
		}
		if(!empty($_FILES['vendor_paperbackimage_'.$lang.'_'.$slug]["name"])){
			if(!file_exists($image_path['basedir'].'/pub_upload')){
				$old = umask(0);
				mkdir($image_path['basedir'].'/pub_upload',0777);
				mkdir($image_path['basedir'].'/pub_upload/paperback/',0777);
				mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
				umask($old);
			} else if (!file_exists($image_path['basedir'].'/pub_upload/paperback')) {
                $old = umask(0);
                mkdir($image_path['basedir'].'/pub_upload/paperback/',0777);
                umask($old);
            }
			
			$filupTot1= array();
			
			$pic_f =$_FILES['vendor_paperbackimage_'.$lang.'_'.$slug]["name"];
			$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
			$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
			$filupTot1 = move_uploaded_file ($_FILES['vendor_paperbackimage_'.$lang.'_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/paperback/'.$pic_f);
			$vendor_img='paperback/'.$pic_f;
		}	
			
		$display_text_button = $_POST['pba_paperback']['links'][$slug][$lang];
					
		$website_id = $_REQUEST['website_id'];
		$btnbookstatus=0;
		
		if(isset($_POST['buttonselect_'.$lang.'_'.$slug])){
			if($_POST['buttonselect_'.$lang.'_'.$slug]=='btext_'.$lang.'_'.$slug){
			$btnbookstatus = 1;
			}elseif($_POST['buttonselect_'.$lang.'_'.$slug]=='bimage_'.$lang.'_'.$slug){
			$btnbookstatus = 2;
			}
		}
			
		if(isset($_POST['vendor_paperbackdisplay_'.$lang.'_'.$slug]) && $_POST['vendor_paperbackdisplay_'.$lang.'_'.$slug]==1){
			$display=1;
		}else{
			$display=0;
		}
        
        if (empty($display_text_button) && empty($vendor_img) && isset($_REQUEST['pba_paperback']['add_link'])) {
            $query = "SELECT * FROM $author_vendor_paperback_setting_table WHERE vendor_name='$vendor_name' AND lang='en'";
            $result = $wpdb->get_row( $query );
            $display_text_button = $result->display_text_button;
            $vendor_img = $result->image;
            $btnstatus = $result->btnstatus;
        }
            
		$data = array('vendor_name'=>$vendor_name,'image'=>$vendor_img,'display_text_button'=>$display_text_button,
			'author_id'=>$website_id,'display'=>$display,'btnstatus'=>$btnbookstatus);
					
		$format = array('%s','%s','%s','%d','%d','%d');
		$where  = array('vendor_name'=>$vendor_name,'lang'=>$lang,'author_id'=>$website_id);
		$where_format = array('%s','%s','%d');
		
		$wpdb->update( $author_vendor_paperback_setting_table, $data, $where, $format , $where_format );
		
		$set_message="Vendor setting has been updated successfully.";		
		
	}
	return $set_message;
}

		
function save_vendor_paperback($id,$lang,$slug)
{
	global $wpdb;
	$author_vendor_paperback_setting_table = $wpdb->prefix . "author_vendor_paperback_setting";
	
	$image_path = wp_upload_dir();
	
	if(!empty($id))
	{	
			$vendor_name = $slug;
			$display_text_button = $_POST['pba_paperback']['new_link'][$slug];
			$btnstatus=1;
			
			if(!empty($_FILES['vendor_paperbackimage_'.$slug]["name"]))
			{
				if(!file_exists($image_path['basedir'].'/pub_upload')){
					$old = umask(0);
					mkdir($image_path['basedir'].'/pub_upload',0777);
					mkdir($image_path['basedir'].'/pub_upload/paperback/',0777);
					mkdir($image_path['basedir'].'/pub_upload/ebook/',0777);
					umask($old);
				} else if (!file_exists($image_path['basedir'].'/pub_upload/paperback')) {
                    $old = umask(0);
                    mkdir($image_path['basedir'].'/pub_upload/paperback/',0777);
                    umask($old);
                }
				$filupTot1= array();
				$pic_f =$_FILES['vendor_paperbackimage_'.$slug]["name"];
				$ext = substr(strrchr($pic_f, "."), 1); #getting the pic extension
				$pic_f = rand().time().'.'.$ext; #setting unique name to a pic
				$filupTot1 = move_uploaded_file ($_FILES['vendor_paperbackimage_'.$slug]['tmp_name'], $image_path['basedir'].'/pub_upload/paperback/'.$pic_f);
				$vendor_img='paperback/'.$pic_f;
				$btnstatus=2;
				
			}	
			
			
			$website_id = $_REQUEST['website_id'];
			
			if(isset($_POST['vendor_paperbackdisplay_'.$slug]) && $_POST['vendor_paperbackdisplay_'.$slug]==1){
			$display=1;
			}else{
			$display=0;
			}
            
            if (empty($display_text_button) && empty($vendor_img)) {
                $query = "SELECT * FROM $author_vendor_paperback_setting_table WHERE vendor_name='$vendor_name' AND lang='en'";
                $result = $wpdb->get_row( $query );
                $display_text_button = $result->display_text_button;
                $vendor_img = $result->image;
                $btnstatus = $result->btnstatus;
            }				
			
			$data = array('vendor_name'=>$vendor_name,'display_text_button'=>$display_text_button,'image'=>$vendor_img,'lang'=>$lang,'author_id'=>$id,'display'=>$display,'order'=>$num,'btnstatus'=>$btnstatus);
			$format = array('%s','%s','%s','%s','%d','%d','%d','%d');
			
			
			$wpdb->insert($author_vendor_paperback_setting_table, $data, $format );
			
			$set_message="Vendor setting has been updated successfully.";		
		
	}
	return $set_message;
}

?>