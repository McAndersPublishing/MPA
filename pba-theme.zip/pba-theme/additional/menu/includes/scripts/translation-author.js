/**
 * Toggles translations on author pages.
 */
jQuery(document).ready(function() {
    jQuery("#pba_show_translations").change(function() {
        if(jQuery("#pba_show_translations").attr("checked")) {
            pba_set_translation_visibility(true);
        } else {
            pba_set_translation_visibility(false);        
        }
    });
});

/**
 * Toggles visiblity of translation elements.
 */
function pba_set_translation_visibility(visibility) {
    var selector = 
        ".pba-item:has(option[value!='" + pba.language + "']:selected), " +
        ".pba-item:has(label[for^='pba_links']):not(:has(label[for$='" + pba.language + "'])), " +
        "select[name*='[new_language]'], " +
        "label[for$='" + pba.language + "']";
    
    if(visibility) {
        jQuery(selector).show()
    } else {
        jQuery(selector).hide();
    }
}