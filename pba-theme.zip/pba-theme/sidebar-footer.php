<div id="sidebar-footer">
   <ul>
      <?php
      if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-sidebar') ) :
      endif; ?>
   </ul>
</div>
<div class="clear"></div>