<?php
add_action( 'after_setup_theme', 'phptheme_setup' );
function phptheme_setup(){
    global $wp_rewrite;
	add_option('PBA_THEME_ADDITIONAL_FEATURE', true); 
	add_option('PBA_THEME_SETUP_DATE', date_timestamp_get(new DateTime('now')));
    if (get_option('permalink_structure') != '') {
        $wp_rewrite->set_permalink_structure( '' );    
    }
}
    
add_action( 'switch_theme', 'phptheme_switch' );
function phptheme_switch($style){
    delete_option('PBA_THEME_ADDITIONAL_FEATURE');        
	delete_option('PBA_THEME_SETUP_DATE');		
}

if( !function_exists( 'pr' ) ) {
    function pr($arr){
	    echo "<pre>";print_r($arr);echo "</pre>";
    }
}

add_filter( 'template_include', 'audio_export_display' );
function audio_export_display( $template ){
    
    if (!empty($_REQUEST['audio_export_id'])) {
        $new_template = locate_template( array( 'additional/audio_export.php' ) );
        if ( '' != $new_template ) {
            return $new_template ;
        }
    }
    return $template;
}

if (!function_exists('globalSettings'))
{
	add_filter('pba_book_listing', 'globalSettings');
	function globalSettings($websiteid=0){
		global $wpdb, $global_settings, $pub_assistantsettings ;
		$global_settings = array();
		
		$author_vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
		$author_vendor_audiobook_setting_table = $wpdb->prefix . "author_vendor_audiobook_setting";
		$author_vendor_paperback_setting_table = $wpdb->prefix . "author_vendor_paperback_setting";
        $author_vendor_hardcover_setting_table = $wpdb->prefix . "author_vendor_hardcover_setting";
        $author_preview_setting_table = $wpdb->prefix . "author_preview_setting";
		$author_preview_audiobook_setting_table = $wpdb->prefix . "author_preview_audiobook_setting";
				
		// fetch ALL vendor list and button name in default language
		$global_settings['themeAuthorID'] = $websiteid;
		
		$lang 			= (get_query_var('lang')) ? get_query_var('lang') : 'en'; 
		$global_settings['lang'] = $lang;
		$global_settings['book_type'] 			= (get_query_var('book_type')) ? get_query_var('book_type') : 'ebook'; 
		 		
		$vendorquery = "SELECT * FROM $author_vendor_setting_table 
								WHERE author_id = $websiteid and lang = '".$global_settings['lang']."' ORDER BY `order` ASC";
		$vendotBtnInfo = $wpdb->get_results($vendorquery,ARRAY_A);
		
		$audioquery = "SELECT * FROM $author_vendor_audiobook_setting_table 
								WHERE author_id = $websiteid and lang = '".$global_settings['lang']."' ORDER BY `order` ASC";
		$audioBtnInfo = $wpdb->get_results($audioquery,ARRAY_A);
		
		$paperbackquery = "SELECT * FROM $author_vendor_paperback_setting_table 
                                WHERE author_id = $websiteid and lang = '".$global_settings['lang']."' ORDER BY `order` ASC";
        $paperbackBtnInfo = $wpdb->get_results($paperbackquery,ARRAY_A);        
        
        $hardcoverquery = "SELECT * FROM $author_vendor_hardcover_setting_table 
                                WHERE author_id = $websiteid and lang = '".$global_settings['lang']."' ORDER BY `order` ASC";
        $hardcoverBtnInfo = $wpdb->get_results($hardcoverquery,ARRAY_A);        
        
        $previewQuery = "SELECT * FROM $author_preview_setting_table 
								WHERE author_id = $websiteid and lang = '".$global_settings['lang']."' ORDER BY `order` ASC";
		$previewBtnInfo = $wpdb->get_results($previewQuery,ARRAY_A);		
		
		$previewAudiobookQuery = "SELECT * FROM $author_preview_audiobook_setting_table 
								WHERE author_id = $websiteid and lang = '".$global_settings['lang']."' ORDER BY `order` ASC";
		$previewAudiobookBtnInfo = $wpdb->get_results($previewAudiobookQuery,ARRAY_A);		
		
		
		$global_settings['vendotBtnInfo'][$global_settings['lang']]= $vendotBtnInfo;
		$global_settings['paperbackBtnInfo'][$global_settings['lang']]= $paperbackBtnInfo;
		$global_settings['hardcoverBtnInfo'][$global_settings['lang']]= $hardcoverBtnInfo;
        $global_settings['audioBtnInfo'][$global_settings['lang']] = $audioBtnInfo;        
        $global_settings['previewBtnInfo'][$global_settings['lang']] = $previewBtnInfo;        
		$global_settings['previewAudioBtnInfo'][$global_settings['lang']] = $previewAudiobookBtnInfo;		
		
		$pub_assistantsettings = get_option( 'pub-assistant' );
	}
	//add_action("template_redirect", "globalSettings");
}

if (!function_exists('vendorButtonToshow'))
{
    function vendorButtonToshow($bookId, $book_type, $lang){
        if ($book_type == 'ebook') 
            $book_type = 'e-book';
        
        global $wpdb, $global_settings, $pub_assistantsettings;
        
        $metaval = 'pba_'. $book_type .'_metavendors_display';
        $book_vendor_display = get_post_meta($bookId, $metaval, true);   

        $language = $lang = $global_settings['lang'];        
 
        if($book_type=='e-book'){
            $vendotBtnInfo[$language] = $global_settings['vendotBtnInfo'][$language];
            $paperbackBtnInfo[$language] = $global_settings['paperbackBtnInfo'][$language];
            $hardcoverBtnInfo[$language] = $global_settings['hardcoverBtnInfo'][$language];
            $previewBtnInfo[$language] = $global_settings['previewBtnInfo'][$language];
        }elseif($book_type=='audiobook'){
            $vendotBtnInfo[$language] = $global_settings['audioBtnInfo'][$language];
            $previewBtnInfo[$language] = $global_settings['previewAudioBtnInfo'][$language];
        }

        $websiteid = $global_settings['themeAuthorID'];
        
        echo "<div class='button-container'>";

        if (count($vendotBtnInfo[$language]))
        {
            
            foreach ($vendotBtnInfo[$language]  as $vendor)
            {
                $filters = array();
                
                $filters['text'] = $vendor['display_text_button'];
                if (!$filters['text']) $filters['text'] = $vendor['vendor_name'];
                $filters['vendor_name'] = $vendor['vendor_name'];
                $filters['link'] = '';
                $filters['bookId'] = $bookId;

                $filters = apply_filters ("pba_vendor_btn", $filters, $language, $book_type);
                if ($book_vendor_display == '' or array_key_exists($vendor['vendor_name'], $book_vendor_display)){
                    if ($vendor['display'] == 1 && $filters['link'] != '' && $vendor['image'] && $vendor['btnstatus']==2){
                        echo '
                            <a href="'.fix_url($filters['link']).'" target="_blank">
                                <img src="'.WP_CONTENT_URL.'/uploads/pub_upload/'.$vendor['image'].'">
                            </a>
                        ';
                    }elseif($vendor['display'] == 1 && $filters['link'] != '' ){
                        echo '<div class="buy_now_button"><a href="'.fix_url($filters['link']).'" target="_blank">'.$filters['text'] .'</a></div>';
                    }
                }                    
            }
        }
            
        if (isset($paperbackBtnInfo) and count($paperbackBtnInfo[$language]))
        {
            $book_type = 'paperback';    
            $metaval = 'pba_paperback_metavendors_display';
            $book_vendor_display = get_post_meta($bookId, $metaval, true);    
            
            
            foreach ($paperbackBtnInfo[$language]  as $vendor)
            {
                $filters = array();
                
                $filters['text'] = $vendor['display_text_button'];
                $filters['vendor_name'] = $vendor['vendor_name'];
                $filters['link'] = '';
                $filters['bookId'] = $bookId;
                
                $filters = apply_filters ("pba_vendor_btn", $filters, $language, $book_type);
                
                if (is_array($book_vendor_display) && array_key_exists($vendor['vendor_name'], $book_vendor_display)){
                    if ($vendor['display'] == 1 && $filters['link'] != '' && $vendor['image'] && $vendor['btnstatus']==2){
                        echo '
                            <a href="'.fix_url($filters['link']).'" target="_blank">
                                <img src="'.WP_CONTENT_URL.'/uploads/pub_upload/'.$vendor['image'].'">
                            </a>
                        ';
                    }elseif($vendor['display'] == 1 && $filters['link'] != '' ){
                        echo '<div class="buy_now_button"><a href="'.fix_url($filters['link']).'" target="_blank">'.$filters['text'] .'</a></div>';
                    }
                }
            }
        }
            
        if (isset($hardcoverBtnInfo) and count($hardcoverBtnInfo[$language]))
        {
            $book_type = 'hardcover';
            $metaval = 'pba_hardcover_metavendors_display';
            $book_vendor_display = get_post_meta($bookId, $metaval, true);    
            
            
            foreach ($hardcoverBtnInfo[$language]  as $vendor)
            {
                $filters = array();
                
                $filters['text'] = $vendor['display_text_button'];
                $filters['vendor_name'] = $vendor['vendor_name'];
                $filters['link'] = '';
                $filters['bookId'] = $bookId;
                
                $filters = apply_filters ("pba_vendor_btn", $filters, $language, $book_type);
                
                if (is_array($book_vendor_display) && array_key_exists($vendor['vendor_name'], $book_vendor_display)){
                    if ($vendor['display'] == 1 && $filters['link'] != '' && $vendor['image'] && $vendor['btnstatus']==2){
                        echo '
                            <a href="'.fix_url($filters['link']).'" target="_blank">
                                <img src="'.WP_CONTENT_URL.'/uploads/pub_upload/'.$vendor['image'].'">
                            </a>
                        ';
                    }elseif($vendor['display'] == 1 && $filters['link'] != '' ){
                        echo '<div class="buy_now_button"><a href="'.fix_url($filters['link']).'" target="_blank">'.$filters['text'] .'</a></div>';
                    }
                }
            }
        }
        
        if (count($previewBtnInfo[$language]))
        {   
            foreach ($previewBtnInfo[$language]  as $vendor)
            {
                $filters = array();
                
                $filters['text'] = $vendor['display_text_button'];
                $filters['preview_name'] = $vendor['preview_name'];
                $filters['link'] = '';
                $filters['bookId'] = $bookId;
                $filters = apply_filters ("pba_preview_btn", $filters, $language, $book_type);

                if ($book_type=='audiobook'){ 
                    if (get_post_meta($bookId, 'audiobook_sample', true)) {
                        $filters['link'] = get_bloginfo('siteurl')."?audio_export_id=$bookId";

                        if ($vendor['display'] == 1 && /*$filters['link'] != '' &&*/ $vendor['image'] && $vendor['btnstatus']==2){
                            echo '
                                <a class="preview_button" href="'.$filters['link'].'" title="Preview for &laquo;'.get_the_title($bookId).'&raquo;" target="_blank">
                                    <img src="'.WP_CONTENT_URL.'/uploads/pub_upload/'.$vendor['image'].'">
                                </a>
                            ';
                        }elseif($vendor['display'] == 1 /*&& $filters['link'] != ''*/ ){
                            echo '<div class="buy_now_button preview_button"><a href="'.$filters['link'].'" title="Preview for &laquo;'.get_the_title($bookId).'&raquo;" target="_blank">'.$filters['text'] .'</a></div>';
                        }
                    }
                } else {
                    
                    if (defined('PBA_PLUGIN_URL')) {
                        $filters['link'] = PBA_PLUGIN_URL . "export.php?book=$bookId&type=preview&layout=0&size=1&preview=1&amp;preview_iframe=1&amp;TB_iframe=true&amp;themeAuthorID=".$global_settings['themeAuthorID'];                       
                    } else {
                        $filters['link'] = get_bloginfo('siteurl')."/wp-content/plugins/pub-assistant/export.php?book=$bookId&type=preview&layout=0&size=1&preview=1&amp;preview_iframe=1&amp;TB_iframe=true&amp;themeAuthorID=".$global_settings['themeAuthorID'];    
                    }
                    
                    $preview_book = get_post($bookId);
                    if (!empty($preview_book->post_content)) {
                        if ($vendor['display'] == 1 && /*$filters['link'] != '' &&*/ $vendor['image'] && $vendor['btnstatus']==2){
                            echo '
                                <a class="preview_button thickbox thickbox-preview" href="'.$filters['link'].'" title="Preview for &laquo;'.get_the_title($bookId).'&raquo;">
                                    <img src="'.WP_CONTENT_URL.'/uploads/pub_upload/'.$vendor['image'].'">
                                </a>
                            ';
                        }elseif($vendor['display'] == 1 /*&& $filters['link'] != ''*/ ){
                            echo '<div class="buy_now_button preview_button"><a class="thickbox thickbox-preview" href="'.$filters['link'].'" title="Preview for &laquo;'.get_the_title($bookId).'&raquo;">'.$filters['text'] .'</a></div>';
                        }
                    }
                }
//                }                    
            }
        }
        echo "</div>";
    }
}

if( !function_exists( 'pba_vendor_btnText' ) ) {
    add_filter( 'pba_vendor_btn', 'pba_vendor_btnText', 10, 3 );
    /**
     * Generates definitions for book filter options.
     * @param array $filters Existing filter definitions.
     * @param string $button text, language and book type.
     * @return array Modified filter definitions.
     */
    function pba_vendor_btnText( $filters, $lang, $book_type ) {
        /*if( 'paperback' == trim($book_type) or 'hardcover' == trim($book_type)) {
            return $filters;
        }*/    
        if( '' != trim($filters['text']) ) {
            return $filters;
        }
        if( 'en' == trim($lang) ) {
            return $filters;
        }
        
        global $wpdb, $global_settings;        
        $websiteid = $global_settings['themeAuthorID'];
        
        if($book_type=='ebook')
            $vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
        else
            $vendor_setting_table_1 = $wpdb->prefix . "author_vendor_".$book_type."_setting";
            
        $alternatequery = "SELECT * FROM $vendor_setting_table_1 
                        WHERE author_id = $websiteid and 
                        lang = 'en' and
                        vendor_name = '".$filters['vendor_name']."'
                        ORDER BY `order` ASC";
        $alternateInfo = $wpdb->get_row($alternatequery,ARRAY_A);
        
        if (trim ($alternateInfo['display_text_button'] ) == ''){
            $vendor_setting_table = $wpdb->prefix . "author_vendor_setting";
            $alternatequery = "SELECT * FROM $vendor_setting_table 
                        WHERE author_id = $websiteid and 
                        lang = 'en' and
                        vendor_name = '".$filters['vendor_name']."'
                        ORDER BY `order` ASC";
            $alternateInfo = $wpdb->get_row($alternatequery,ARRAY_A);
        }
        
        $filters['text'] = $alternateInfo['display_text_button'];
        return $filters;
    }
}

if( !function_exists( 'pba_vendor_btnLink' ) ) {
    add_filter( 'pba_vendor_btn', 'pba_vendor_btnLink', 10, 3 );
    /**
     * Generates definitions for book filter options.
     * @param array $filters Existing filter definitions.
     * @param string $button  language and book type.
     * @return array Modified filter definitions.
     */
    function pba_vendor_btnLink( $filters, $lang, $book_type ) {
        if( '' != trim($filters['link']) ) {
            return $filters;
        }
        if( '' == $filters['bookId'] ) {
            return $filters;
        }
        
        global $wpdb, $global_settings;        
        $websiteid = $global_settings['themeAuthorID'];
        
        $bookPubLink = get_post_meta( $filters['bookId'], '_pba_link_'.$filters['vendor_name'] .'_'.$book_type, true);
//        if ($bookPubLink == '') {
//            $primaryAuthorid = get_post_meta($filters['bookId'], '_pba_author_1', true);
//            $bookPubLink = get_post_meta( $primaryAuthorid, '_pba_links_' . $filters['vendor_name'] . '_' . $lang, true );
//        }
        
        $filters['link'] = $bookPubLink;
        return $filters;
    }
}

if (!function_exists('showPromotionalLinks'))
{
	function showPromotionalLinks($bookid, $book_type = 'ebook'){

        if ($book_type == 'ebook') {
            $meta_key = 'ebook_promotional';
            $ebook_promotional_display_check = get_post_meta($bookid, 'ebook_promotional_display', true);
        }
        else {
            $meta_key = 'audiobook_promotional_link';
            $ebook_promotional_display_check = get_post_meta($bookid, 'display_audiobook_promotional', true);
        }
		if(isset($ebook_promotional_display_check) && $ebook_promotional_display_check=='on') {
			$ebook_promotional_links = get_post_meta($bookid, $meta_key, true);

			if(count($ebook_promotional_links)>0) {
				echo '<ul class="promotional">';
				foreach($ebook_promotional_links as $key=>$promotionallinks){
					foreach($promotionallinks as $key=>$value){
						echo '<li><a href="'.fix_url($value['link']).'" target="_blank">'.$value['title'].'</a></li>';
					}
				}
				echo '</ul>';
			}
		}
	}
}

if (!function_exists('showBookBlock'))
{
	function showBookBlock($pba_book, $isSeries= false){
        global $global_settings;
        $book_type = $global_settings['book_type'];
        $lang      = $global_settings['lang'];
		?>
		<div class="templatemo_product_box">
			<?php if (!$isSeries) { ?>
				<h1>
					<span id="btAsinTitle3"><strong>
						<?php echo $pba_book->book_title; ?> 
					</strong></span>
				</h1>
			<?php } ?>
			
			<div class="product_info"><?php
				echo get_the_post_thumbnail($pba_book->book_id, array( 160, 200 ));
				if ($isSeries) { ?>
					<h2>
						<span id="btAsinTitle3"><strong>
							<?php echo $pba_book->book_title; ?> 
						</strong></span>
					</h2>
				<?php } 
				$description = $pba_book->book_description;
                $description = preg_replace('/<p[^>]*>(.+?)<\/p>/', "$1<br clear=\"none\" />", $description);       
				for ($i=0; $i< 100; $i++) {
                    if (strpos($description, '<!--')<=0) break;
                    $temp1_arr = explode('<!--', $description);
                    $temp2_arr = explode('-->', $temp1_arr[1]);
                    $description = $temp1_arr[0].$temp2_arr[1];
                }               
				preg_match_all('/(.+?)<br clear="none"[^>]*>/', $description, $P_desc ); 
				
				$firstPDesc = $P_desc[0]; 
//				print_r($P_desc);
				if(count($firstPDesc)>1){
					echo ' 	
						<p class="bookDescP bookShortDescP">'.$firstPDesc[0].'
						<a href="javascript:void(0);" class ="seemoredesc" id="hidetext'.$bookId.'_show" >...See More</a></p>
						<p style="display:none;" class="bookDescP  bookFullDescP">'.$description.'
						 <a href="javascript:void(0);" class ="seemoredesc" id="hidetext'.$bookId.'_hide" >...Hide</a></p>';
						
				}
				else {
					echo '<p class="bookDescP ">'.$description.'</p>';
				}
					showPromotionalLinks($pba_book->book_id, $book_type);
					vendorButtonToshow($pba_book->book_id, $book_type, $lang);
			   ?>
			</div>
		</div><?php
	}
}

function fix_url($url) {
    if ( strpos($url, 'http://') === false ) {
        $url = 'http://'.$url;
    }
    return $url;
}

function gen_string($string,$max)	
{
	$tok=strtok($string,' ');
	$string='';
	while($tok!==false && strlen($string)<$max)
	{
		if (strlen($string)+strlen($tok)<=$max) $string.=$tok.' '; else break;
		$tok=strtok(' ');
	}
	return trim($string).'...';
}  

if (!function_exists('pba_booklists')) {
	function pba_booklists ($attrs){   
		global $wpdb, $global_settings, $post, $current_genre_books, $pub_assistantsettings;
		
        extract(shortcode_atts(array(  
			'websiteid' => 0,  	
		), $attrs)); 
		
		$website_id = $websiteid;

		///////////
		$book_type 	= (get_query_var('book_type')) ? get_query_var('book_type') : 'ebook'; 
		$lang = $global_settings['lang'];
		//print_r($global_settings); 
		echo '
		<div class="templatemo-tabmain">
			<div class="tab-link"><!--tabs li -->
				<ul id="tabs">';
				$k = 0;
				$allGenreBooks = array();
                
                foreach ( $global_settings['category_genres'] as $cat_genre ) {
                    $active_genre = '';
                    if ( $cat_genre['slug'] == $global_settings['current_genre']['slug'] ) {
                        $active_genre = 'active';
                    }
                    echo '<li class="'.$active_genre.'"><a href="'.get_categoryURL($lang, $book_type, $cat_genre['slug']).'">'.$cat_genre['name'].'</a></li>';
                }
		echo '
				</ul>
				<!--close tabs-->
			</div>
		</div>
		<div class="tab-content">';
		    ?>
             <div class="contab">
                 <div id="templatemo_content_right">
                    <div id="content" role="main">
                    <?php
                    $series_arr = array();
                    
                    foreach ( $global_settings['current_books'] as $book ) {
                        if ( array_key_exists($book->book_series_id, $series_arr) ) {
                            $series = &$series_arr[$book->book_series_id];
                            $series->add_book( $book );
                        } else {
                            $new_series = new PBA_series();
                            $new_series->add_book( $book );
                            $s_postidvalue = $new_series->series_id;
                            $s_slug = $global_settings['current_genre']['slug'];
                            $s_lang = $global_settings['lang'];
                            $s_is_book = (get_query_var('book_type')=='audiobook') ? false : true;
                            $new_series->series_date = get_book_order_publish_date($s_postidvalue, $s_slug, $s_lang, $s_is_book);
                            $series_arr[$new_series->series_id] = $new_series;
                        }
                    }    
                        
                    uasort( $series_arr, 'series_order_by_pub_date_callback' );
                    
                    $fixed_series_array = array();
                    $temp_array = array();
                    $one_count = 0;
                    
//                    print_r($series_arr); exit;
                    
                    foreach($series_arr as $series_key=>$each_series_array) {
                        if ( count($each_series_array->series_books) == 1 && $one_count == 0 ) {
                            if (count($temp_array)) {
                                foreach ($temp_array as $t_key => $t_value) {
                                    $fixed_series_array[$t_key] = $t_value;        
                                }
                                $temp_array = array();
                            }
                            $fixed_series_array[$series_key] = $each_series_array;
                            $one_count = 1; continue; 
                        } else if ( count($each_series_array->series_books) == 1 && $one_count == 1 ) {
                            $fixed_series_array[$series_key] = $each_series_array;
                            $one_count = 0; continue; 
                        } else if ( count($each_series_array->series_books) > 1 && $one_count == 0 ) {
                            if (count($temp_array)) {
                                foreach ($temp_array as $t_key => $t_value) {
                                    $fixed_series_array[$t_key] = $t_value;        
                                }
                                $temp_array = array();
                            }
                            $fixed_series_array[$series_key] = $each_series_array;
                            $one_count = 0; continue; 
                        } else if ( count($each_series_array->series_books) >1 && $one_count == 1 ) {
                            $temp_array[$series_key] = $each_series_array;
                            $one_count = 1; continue; 
                        }
                    }
                    if (count($temp_array)) {
                        foreach ($temp_array as $t_key => $t_value) {
                            $fixed_series_array[$t_key] = $t_value;        
                        }
                        $temp_array = array();
                    }
                         
                    $spc = 0;
                    foreach ( $fixed_series_array as $series_book ) {
                        if ( count($series_book->series_books)>1 ) {
                            $min = 9999999999999999999;
                            $min_id = -1;
                            $is_volume = false;
                            $is_volume1 = false;
                            $series_book_arr = $series_book->series_books;
                            for ( $i = 0; $i < count($series_book_arr); $i++ ) {
                                $ret_book = $series_book_arr[$i];
                                $date = new DateTime($ret_book->book_date);
                                if ( $date->getTimestamp() < $min ) {
                                    $min = $date->getTimestamp();
                                    $min_id = $i;
                                }
                                if ( $ret_book->series_volume ) {
                                    $is_volume = true;
                                }
                                if ( $ret_book->series_volume == 1 ) {
                                    $is_volume1 = true;
                                }
                            }
                            if ( !$is_volume && !$is_volume1 ) {
                                $temp = $series_book_arr[$min_id];
                                if (!$temp->book_series_volume)
                                    $temp->book_series_volume = 1;
                                $series_book_arr[$min_id] = $temp;
                                $series_book->series_books = $series_book_arr;
                            }
                    ?>
                            <div class="inner-for-group">
                            <h1><?php echo $series_book->series_title;?></h1>
                                <?php
                                $series_book->sort_series();
                                $mpc = 0;
                                foreach ($series_book->series_books as $volume_book)
                                {    
                                    /*Show Book Block*/
                                    showBookBlock($volume_book, true);
                                    /*Show Book Block*/
                                    $mpc++;
                                    if($mpc%2==0) { echo "<div class='clear'></div>"; }
                                }?>
                            </div>    
                        <?php 
                        } else { 
                            //Show Book Block
                            $volume_book = $series_book->series_books;
                            showBookBlock($volume_book[0]);
                            /*Show Book Block*/    
                            $spc++;
                            if($spc%2==0) { echo "<div class='clear'></div>"; }
                        }
                    }
                    ?>
                    <style>
                        .bookDescP{
                            padding: 0px;
                        }
                    </style>
                    </div><!-- #content -->
                <div class="cleaner_with_height">&nbsp;</div> 
            </div>
            <div class="clrdiv"></div>
            </div> <!-- end of content right --> 
		</div> <!-- tab-content -->
	<!--close start the tab section -->	                                                                                                              
	<script>
		$('document').ready(function(){
			$('a.seemoredesc').prev().remove();
			$('a.seemoredesc').click(function(){
				if ($(this).parent().parent().parent().hasClass('templatemo_product_box')) {
                    $(this).parent().parent().find("p.bookShortDescP").toggle();
                    $(this).parent().parent().find("p.bookFullDescP").toggle();
                } else {
                    $(this).parent().parent().parent().find("p.bookShortDescP").toggle();
                    $(this).parent().parent().parent().find("p.bookFullDescP").toggle();
                }
                
			});                                                                                                                                       
		});
		function htmlspecialchars_decode (string, quote_style) {
			var optTemp = 0,
			i = 0,
			noquotes = false;
			if (typeof quote_style === 'undefined') {
				quote_style = 2;
			}
			string = string.toString().replace(/&lt;/g, '<').replace(/&gt;/g, '>');
			var OPTS = {
				'ENT_NOQUOTES': 0,
				'ENT_HTML_QUOTE_SINGLE': 1,
				'ENT_HTML_QUOTE_DOUBLE': 2,
				'ENT_COMPAT': 2,
				'ENT_QUOTES': 3,
				'ENT_IGNORE': 4
			};
			if (quote_style === 0) {
				noquotes = true;
			}
			if (typeof quote_style !== 'number') { // Allow for a single string or an array of string flags
				quote_style = [].concat(quote_style);
				for (i = 0; i < quote_style.length; i++) {
					// Resolve string input to bitwise e.g. 'PATHINFO_EXTENSION' becomes 4
					if (OPTS[quote_style[i]] === 0) {
						noquotes = true;
					} else if (OPTS[quote_style[i]]) {
						optTemp = optTemp | OPTS[quote_style[i]];
					}
				}
				quote_style = optTemp;
			}
			if (quote_style & OPTS.ENT_HTML_QUOTE_SINGLE) {
				string = string.replace(/&#0*39;/g, "'"); // PHP doesn't currently escape if more than one 0, but it should
				// string = string.replace(/&apos;|&#x0*27;/g, "'"); // This would also be useful here, but not a part of PHP
			}
			if (!noquotes) {
				string = string.replace(/&quot;/g, '"');
			}
			// Put this in last place to avoid escape being double-decoded
			string = string.replace(/&amp;/g, '&');
			return string;
		}
	</script>
	<?php	
	}
	add_shortcode ('PBA_BOOKLISTS', 'pba_booklists');
}

function series_order_by_pub_date_callback( $series_a, $series_b ) {
    
    $a = $series_a->series_date;
    $b = $series_b->series_date;
    
    if ( $a == $b )
        return 0;

    return ( $a > $b ) ? -1 : 1;
}

add_action ('init', 'SetImageSize');
function SetImageSize(){
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'custom-preview', 199, 300 );
}

#############################
function add_query_vars_filter( $vars ){
  $vars[] = "genre";
  $vars[] = "lang";
  $vars[] = "book_type";
  return $vars;
}
add_filter( 'query_vars', 'add_query_vars_filter' );

//function add_rewrite_rules($aRules) {
//    $aNewRules = array(
//                                    'ebook/([^/]+)/([0-9]{1,})/?$' => '/?book_type=ebook&lang=$matches[1]&genre=$matches[2]',
//                                    'audiobook/([^/]+)/([0-9]{1,})/?$' => '/?book_type=audiobook&lang=$matches[1]&genre=$matches[2]'
//                                );
//    $aRules = $aNewRules + $aRules;
//    return $aRules;
//}

//add_filter('rewrite_rules_array', 'add_rewrite_rules');

function get_categoryURL($lang, $book_type, $genre = 0){

//    global $wp_rewrite;

//if ($wp_rewrite->permalink_structure == '')
//        $url = get_home_url()."?lang=".$lang."&book_type=".$book_type."&genre=".$genre;//we are using ?page_id
//    else
//        $url = get_home_url()."/".$book_type."/".$lang."/".$genre."/"; //        
    
    $url = add_query_arg('book_type', $book_type, get_home_url());
    $url = add_query_arg('lang', $lang, $url);
    $url = add_query_arg('genre', $genre, $url);
        
    return $url;
}
################################
if (!function_exists('pba_func_sidebar_langlist'))
{
	add_action ('pba_sidebar_langlist', 'pba_func_sidebar_langlist', 10, 1);
	
	function pba_func_sidebar_langlist(){
		echo "<div class='pha_langlist' id='pha_langlist'>";
        echo pba_html_sidebar_langlist();
		echo "</div>";		
	}
	
	function pba_html_sidebar_langlist(){
        global $global_settings, $wpdb;
        
        $website_id = $global_settings['themeAuthorID'];
        //print_r($global_settings);
        $languages = get_post_meta($website_id, 'website_languages', true);
        $audiobooklinks = get_post_meta($website_id, 'website_aud_languages', true);
        
        $sidebarHtml=  "<h1>Categories</h1>";
        $sidebarHtml .= "<ul>";
        
        foreach( $languages as $lang_key => $language ) {    
            
            $lang_results = $wpdb->get_results("SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_pba_language' AND meta_value = '$lang_key'");
            
//            print_r($lang_results);
            if ( count($lang_results) > 0 ) {
                
                if ($language['display']) 
                {
                    $flag = false;
                    foreach ($lang_results as $lang_r) {
                         if ( get_post_meta($lang_r->post_id, 'ebook_publish', true) == 'on' && get_post_status($lang_r->post_id) == 'publish' ) {
                             $flag = true;
                             break;
                         }
                    }
                    if ($flag) {
                        if($global_settings['lang'] == $lang_key && $global_settings['book_type']=='ebook')
                            $current = "class='current'";
                        else
                            $current = '';
                        $sidebarHtml .= "<li><a href='".get_categoryURL($lang_key, 'ebook')."' ".$current.">".$language['real_value']."</a></li>";
                    }
                }  
                ////// for audiobook
                if($audiobooklinks[$lang_key]['display'] )
                {
//                    print_r($lang_results);
                    $flag = false;
                    foreach ($lang_results as $lang_r) {
//                        echo get_post_meta($lang_r->post_id, 'book_publish', true)."::".$lang_r->post_id."<br>";
                         if ( get_post_meta($lang_r->post_id, 'book_publish', true) == 'on' && get_post_status($lang_r->post_id) == 'publish') {
                             $flag = true;
                             break;
                         }
                    }
                    if ($flag) {
                        if($global_settings['lang'] == $lang_key && $global_settings['book_type']=='audiobook')
                            $current = "class='current'";
                        else
                            $current = '';

                        $sidebarHtml .= "<li><a href='".get_categoryURL($lang_key, 'audiobook')."' ".$current.">".$audiobooklinks[$lang_key]['real_value']."</a></li>";
                    }
                }
            }
        }
        $sidebarHtml .= "</ul>";
        return $sidebarHtml;    
    }	
}

function pba_html_specialOffers(){
	global $global_settings;
	$websiteid = $global_settings['themeAuthorID'];
    $lang      = $global_settings['lang'];
    $book_type = $global_settings['book_type'];
	
	$specialOffers = get_post_meta($websiteid, '_auth_special_offer', true);
    if ($specialOffers) {
	    $specialOffers = $specialOffers[$lang.'_'.$book_type];
	    
	    $heading = ($specialOffers['heading'] != '') ? $specialOffers['heading'] : 'Special Offers';
	    
	    if($specialOffers['display'] == 1)
		    echo "<h3>".$heading."</h3>".$specialOffers['special_offers'];
	    else
		    echo "<h3>".$heading."</h3>";
    }
}

function pba_html_latestBooks() {
    
    global $wpdb, $global_settings;
    
    $website_id = $global_settings['themeAuthorID'];
    $lang       = $global_settings['lang'];
    $book_type  = $global_settings['book_type'];

    $latestreleaseMeta = get_post_meta($website_id, '_auth_latest_release', true);
    
    if ($latestreleaseMeta) {
        $latestrelease = $latestreleaseMeta[$lang.'_'.$book_type];

	    if($latestrelease['display'] == 1){

            $allbooks = pba_get_last_release_books($book_type, $lang);
            
		    $latestreleaseHtml ="<h3>".$latestrelease['headline']. "</h3><ul>";
            $count = ($latestrelease['no_of_titles'] > count($allbooks)?count($allbooks):$latestrelease['no_of_titles']);
		    for ($i = 0; $i< $count;$i++){
                if (!$allbooks[$i]) break;
                $genre_id = (int)get_post_meta($allbooks[$i], '_pba_genre', true);
                $url = get_categoryURL($lang, $book_type, $genre_id)."#book_".$allbooks[$i];
			    $latestreleaseHtml .="<li><a href='$url'>".get_the_title($allbooks[$i])."</a></li>";
		    }
		    $latestreleaseHtml .="</ul>";
	    
		    echo $latestreleaseHtml;
	    }else
		    echo '';
    }
}

function pba_site_title() {
    $site_title = get_post_meta(1, 'theme_data_setting', true);
    if (!($site_title['theme_site_title'] && $site_title['theme_display_header'] == 1)) {
        bloginfo( 'name' );
        return;
    }
    echo $site_title['theme_site_title'];
}

function pba_site_tagline() {
    $site_title = get_post_meta(1, 'theme_data_setting', true);
    if (!($site_title['theme_tagline'] && $site_title['theme_display_header'] == 1)) {
        bloginfo( 'name' );
        return;
    }
    echo $site_title['theme_tagline'];
}

$menu_exists = wp_get_nav_menu_object('PbaMenu');
if(!$menu_exists){
	wp_create_nav_menu( "PbaMenu" );
	$mymenu=wp_get_nav_menu_object('PbaMenu');
	$menuID = (int) $mymenu->term_id; 
	$itemData_1 = array(
	    'menu-item-title' =>  __('Home'),
        'menu-item-classes' => 'home',
		'menu-item-object' => 'Custom',
        'menu-item-url' => home_url( '/' ), 
        'menu-item-status' => 'publish'
		);
	
	wp_update_nav_menu_item($menuID, 0, $itemData_1); 	
		
	$page = get_page_by_title( 'Blog' );
	
	$itemData_2 =  array(	
		'menu-item-object-id' => $page->ID	,
		'menu-item-parent-id' => 0,
		'menu-item-position'  => 2,
		'menu-item-object' => 'page',
		'menu-item-type'      => 'post_type',
		'menu-item-status'    => 'publish'
	  );
	
	wp_update_nav_menu_item($menuID, 0, $itemData_2); 	
}	
?>