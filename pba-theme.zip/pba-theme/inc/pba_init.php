<?php
/**
* define main display process flows
* 
* @package pba_theme
* @author XianA
*/

/**
* process init load data from query
* 
* @author XianA
*/
add_action( 'template_redirect', 'pba_init', 1 );
function pba_init() {
    global $pub_assistantsettings, $global_settings, $current_genre_books;
    
    apply_filters( 'pba_book_listing', 1 );
    
    $query_type          = (get_query_var('book_type')) ? get_query_var('book_type') : 'ebook';
    $query_lang          = (get_query_var('lang')) ? get_query_var('lang') : 'en';
    
    $category_genres     = pba_get_genres($query_lang);   
                    
    $query_genre         = (int)(get_query_var('genre')) ? get_query_var('genre') : 0;
    
    $current_genre       = $category_genres[$query_genre];
    if (!$current_genre) {
        foreach ($category_genres as $key => $c_genre) {
            $current_genre = $c_genre;
            break;
        }
    }
    
    $global_settings['category_genres'] = $category_genres;
    $global_settings['current_genre']   = $current_genre;
    
    $current_genre_books = pba_get_genre_books($query_type, $query_lang, $current_genre);
    $global_settings['current_books']   = $current_genre_books;
}

/**
* get genres of this page
* 
* @param string $lang
* 
* @return array genres of current page
*/
function pba_get_genres($lang) {
    global $pub_assistantsettings, $wpdb, $global_settings;

    $all_genres = $pub_assistantsettings['look-ups'][ 'genres' ]['values'];
    $ret_genres = array();
    
    $key_name = 'ebook_publish';
    if ($global_settings['book_type']!='ebook') $key_name = 'book_publish';
    
    $theme_date = get_option('PBA_THEME_SETUP_DATE');
        
    foreach( $all_genres as $slug => $genre ) {
        if(!isset($genre[$lang])){
            $genre[$lang] = $genre['en'];   
        }
        $genre_books = $wpdb->get_results("SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_pba_genre' AND meta_value = '$slug'");
        foreach ( $genre_books as $genre_book ) {
            if ( get_post_status($genre_book->post_id) == 'publish' && get_post_meta( $genre_book->post_id, '_pba_language', true ) == $lang ) {
                $book_meta = get_post_meta( $genre_book->post_id, $key_name, true );
                if( $book_meta == 'off' || (!$book_meta && (get_post_time('U', true, $genre_book->post_id) > $theme_date))) continue;
                $ret_genres[$slug] = array('slug' => $slug, 'name' => $genre[$lang]);
                break;
            }
        }
    }                                                            
    return $ret_genres;
}

/**
* load all books that will display
* 
* @param string $type
* @param string $lang
* @param array $current_genre
* 
* @return array books of current genre
*/
function pba_get_genre_books($type, $lang, $current_genre) {
    global $pub_assistantsettings, $wpdb;

    $ret_books = array();
    $theme_date = get_option('PBA_THEME_SETUP_DATE');
    
    $genre_books = $wpdb->get_results("SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_pba_genre' AND meta_value = '{$current_genre['slug']}'");
    foreach ( $genre_books as $genre_book ) {
        if ( get_post_meta( $genre_book->post_id, '_pba_language', true ) == $lang ) {
            $book_post = get_post( $genre_book->post_id );
            if ( $book_post->post_type == 'pba_book' && $book_post->post_status == 'publish' ) {
                $pub_date = '';
                if ( $type != 'audiobook' ) {
                    $pub_date = 'ebook_publish_date';                                                          
                    $book_meta = get_post_meta( $genre_book->post_id, 'ebook_publish', true );                                                                            
                    if ( $book_meta == 'off' || (!$book_meta && (get_post_time('U', true, $genre_book->post_id) > $theme_date))) {
                        continue;
                    }
                        
                } else {
                    $pub_date = 'audiobook_publish_date';
                    $book_meta = get_post_meta( $genre_book->post_id, 'book_publish', true );

                    if ( $book_meta == 'off' || (!$book_meta && (get_post_time('U', true, $genre_book->post_id) > $theme_date))) {
                        continue;
                    }    
                }   
                $ret_books[] = new PBA_book(
                                    $book_post->ID, 
                                    $book_post->post_title, 
                                    $book_post->post_date, 
                                    get_post_meta($genre_book->post_id, '_pba_series_name', true),
                                    get_post_meta($genre_book->post_id, '_pba_series_volume', true),
                                    get_post_meta($genre_book->post_id, '_pba_description', true),
                                    get_post_meta($genre_book->post_id, $pub_date, true),
                                    get_post_meta($genre_book->post_id, 'Date1', true),
                                    get_post_meta($genre_book->post_id, 'Date2', true),
                                    get_post_meta($genre_book->post_id, '_pba_author_1', true),
                                    get_post_meta($genre_book->post_id, '_pba_author_2', true),
                                    get_post_meta($genre_book->post_id, '_thumbnail_id', true)
                );
            }
        }
    }
    
    return $ret_books;
}

/**
* load all books that new released
* 
* @param string $type
* @param string $lang
* 
* @return array books of new released
*/
function pba_get_last_release_books($type, $lang) {
    global $pub_assistantsettings, $wpdb;
    
    $ret_books = array();
    $ret_books_date = array();
    
    $is_ebook = ($type=='audiobook'?false:true);
    
    $lang_books = $wpdb->get_results("SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_pba_language' AND meta_value = '$lang'");
    
    foreach ( $lang_books as $lang_book ) {
        if ( get_post_status( $lang_book->post_id ) == 'publish' && get_post_type( $lang_book->post_id ) == 'pba_book' && get_post_meta($lang_book->post_id, '_pba_genre', true) != -1 ) {
            
            $pub_date = '';
            if ( $type != 'audiobook' ) {
                $pub_date = 'ebook_publish_date';
                if ( get_post_meta( $lang_book->post_id, 'ebook_publish', true ) != 'on' ) {
                    continue;
                }    
            } else {
                $pub_date = 'audiobook_publish_date';
                if ( get_post_meta( $lang_book->post_id, 'book_publish', true ) != 'on' ) {
                    continue;
                }    
            }   
            $ret_books[] = $lang_book->post_id;
            $ret_books_date[] = get_book_date1($lang_book->post_id, $is_ebook);
        }
    }
    
    @array_multisort($ret_books_date, SORT_DESC, $ret_books );
    
    return $ret_books;
}
?>