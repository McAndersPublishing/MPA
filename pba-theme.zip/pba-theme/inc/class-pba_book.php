<?php
/**
 * PBA BOOKS MODEL.
 *
 * Contains the PBA_book class.
 *
 * @package WordPress
 * @author  XianA
 */

/**
 * PBA Books class.
 *
 * This class is a model of the books that will display in current page.
 *
 * @package WordPress
 * @since 1.9.1
 */
class PBA_book {
    
    var $book_id;
    var $book_title;
    var $book_date;
    var $book_series_id;
    var $book_series_volume;
    var $book_description;
    var $book_pub_date;
    var $book_date1;
    var $book_date2;
    var $book_author1;
    var $book_author2;
    var $book_thumbnail;
    
    /**
     * Constructor - Sets up class member vars.
     *
     * All parameters are required.
     *
     * @since 1.9.0
     *
     * @param int $id
     * @param string $title
     * @param int $series_id
     * @param int $series_volume
     * @param string $description
     * @param date $pub_date
     * @param date $date1
     * @param date $date2
     * @param int $author1
     * @param int $author2
     * @param int $thumbnail
     * @return PBA_book
     */
    function PBA_book( $id, $title, $date, $series_id, $series_volume, $description, $pub_date, $date1, $date2, $author1, $author2, $thumbnail ) {
        $this->book_id =            $id;
        $this->book_title =         $title;    
        $this->book_date =          $date;
        $this->book_series_id =     $series_id;
        $this->book_series_volume = $series_volume;
        $this->book_description =   $description;
        $this->book_pub_date =      $pub_date;
        $this->book_date1 =         $date1;
        $this->book_date2 =         $date2;
        $this->book_author1 =       $author1;
        $this->book_author2 =       $author2;
        $this->book_thumbnail =     $thumbnail;
    }
}

class PBA_series {
    
    var $series_id;
    var $series_title;
    var $series_date;
    var $series_books = array();
    
    function add_book( $pba_book ) {
        global $pub_assistantsettings, $global_settings;
        
        if ( !$this->series_id ) {
            $this->series_id = $pba_book->book_series_id;
            $this->series_title = $pub_assistantsettings['look-ups']['series_names']['values'][$this->series_id][$global_settings['lang']];
            $this->series_books[] = $pba_book;
            return null;
        } else {
            if ( $this->series_id == $pba_book->book_series_id ) {
                $this->series_books[] = $pba_book;
                // date sort                                                                                                               
                return null;
            } else {
                $new_series = new PBA_series();
                $new_series->add_book($pba_book);
                return $new_series;
            }
        }
    }
    
    function sort_series() {
        uasort( $this->series_books, array( $this, '_order_by_title_callback' ) );             
        uasort( $this->series_books, array( $this, '_order_by_volume_callback' ) );                                                                           
    }
    
    function _order_by_title_callback( $book1, $book2 ) {
        
        $a = $book1->book_title;
        $b = $book2->book_title;
        
        if ( $a == $b )
            return 0;

        return ( $a > $b ) ? 1 : -1;
    }
    
    function _order_by_volume_callback( $book1, $book2 ) {
        
        if ( !$book1->book_series_volume && !$book2->book_series_volume ) {
            $a = get_post_time('U', true, $book1->book_id);
            $b = get_post_time('U', true, $book2->book_id);
            
            if ( $a == $b )
            return 0;

            return ( $a > $b ) ? 1 : -1;
        } else if ( !$book1->book_series_volume && $book2->book_series_volume ) {
            return 1;
        } else if ( $book1->book_series_volume && !$book2->book_series_volume ) {
            return -1;
        } else {
            $a = (int)preg_replace('[\D]', '', $book1->book_series_volume);
            $b = (int)preg_replace('[\D]', '', $book2->book_series_volume);   
            
            if ( $a == $b )
            return 0;

            return ( $a > $b ) ? 1 : -1;
        }
    }
    
}
?>